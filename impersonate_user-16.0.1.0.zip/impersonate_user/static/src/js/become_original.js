/** @odoo-module **/

import SystrayMenu from 'web.SystrayMenu';
import { registry } from "@web/core/registry";
import session from 'web.session';
const { Component } = owl;

class BecomeOriginalMenu extends Component {
    setup() {
        super.setup();
        this.is_impersonating = false;
        if (session.original_user != undefined && $.isNumeric(session.original_user)) {
            this.is_impersonating = true;
        }
    }
}
BecomeOriginalMenu.template = "impersonate_user.BecomeOriginalMenu";
export const systrayItem = {
    Component: BecomeOriginalMenu,
};
registry.category("systray").add("impersonate_menu", systrayItem, { sequence: 5 });
