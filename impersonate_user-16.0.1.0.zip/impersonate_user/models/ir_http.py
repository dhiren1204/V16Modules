# -*- coding: utf-8 -*-
##############################################################################
#                                                                            #
# Part of Caret IT Solutions Pvt. Ltd. (Website: www.caretit.com).           #
# See LICENSE file for full copyright and licensing details.                 #
#                                                                            #
##############################################################################

from odoo import  models
from odoo.http import request


class HttpImpersonate(models.AbstractModel):
    _inherit = 'ir.http'

    def session_info(self):
        res = super(HttpImpersonate, self).session_info()
        if request.session.original_user:
            res.update({'original_user': request.session.original_user})
        return res
