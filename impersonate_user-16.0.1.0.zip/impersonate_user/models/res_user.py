# -*- coding: utf-8 -*-
##############################################################################
#                                                                            #
# Part of Caret IT Solutions Pvt. Ltd. (Website: www.caretit.com).           #
# See LICENSE file for full copyright and licensing details.                 #
#                                                                            #
##############################################################################

import random
import string
import logging
from odoo.http import request
from odoo import api, fields, models, _
from odoo.exceptions import AccessDenied, UserError, ValidationError
_logger = logging.getLogger(__name__)


class ImpersonateUser(models.Model):
    _inherit = 'res.users'

    impersonated_user_id = fields.Many2one(
        'res.users', string='Impersonated User',
        help='User currently impersonated the user selected on this field.')
    impersonated_by_id = fields.Many2one(
        'res.users', compute='_compute_impersonated_by',
        string='Impersonated By',
        help='User currently impersonated by the user selected on this field.')
    restrict_impersonatating = fields.Boolean(string='Restrict Impersonating')
    access_token = fields.Char("Access Token")
    # check_wrong_hit = fields.Integer("Wrong Hit URL", store=True, default=0)

    def set_token_vals(self):
        letters = string.ascii_uppercase + string.digits + string.ascii_lowercase
        result_str = ''.join(random.choice(letters) for i in range(0,8))
        return result_str
        
    def generate_token(self):
        for res in self.search([]):
            res.access_token = res.set_token_vals()

    @api.model_create_multi
    def create(self, vals_list):
        res_ids = super().create(vals_list)
        for res in res_ids:
            res.access_token = res.set_token_vals()
        return res_ids


    def _compute_impersonated_by(self):
        sessionBy = False
        if request.session.original_user:
            sessionBy = self.browse(request.session.original_user)
        for user in self:
            user.impersonated_by_id = sessionBy

    def can_be_impersonated(self):
        '''Returns True if the user is allowed to be impersonated.'''
        self.ensure_one()
        if self._is_superuser() or \
        self.restrict_impersonatating:
            return False
        return True

    def allow_impersonate(self):
        '''Returns True if impersonate featured is allowed for the user.'''
        if self.has_group('impersonate_user.impersonate_admin_group') or \
        self.has_group('impersonate_user.impersonate_user_group'):
            return True
        return False

    @api.constrains('impersonated_user_id')
    def _check_allow_impersonate(self):
        if not self.impersonated_user_id:
            return

        # Check does current user have enough rights to impersonate user.
        if not (self == self.env.user and self.allow_impersonate()):
            raise AccessDenied(_('You are not allowed to use this feature. '
                                 'Please contact your system administrator.'))

        if not self.impersonated_user_id.can_be_impersonated():
            if not self.has_group('impersonate_user.impersonate_admin_group'):
                raise ValidationError(
                    _('Impersonate not allowed for this user.'))

    def become_user(self, to_be_user):
        self.ensure_one()
        if not (to_be_user and len(to_be_user) == 1):
            raise UserError(_('Become User given parameter not as expected.'))

        if request.session.original_user:
            raise UserError(_('Nested impersonate not allowed.'))
        else:
            if self.impersonated_user_id:
                self.impersonated_user_id = False
        if to_be_user._name == 'res.users':
            self.impersonated_user_id = to_be_user
            to_be_user.impersonated_by_id = self
            return True
        raise UserError(_('Become User is not used properly.'))

    def become_original(self, to_be_user):
        self.ensure_one()
        if not (to_be_user and len(to_be_user) == 1):
            raise UserError(_('Become User given parameter not as expected.'))
        if not to_be_user.impersonated_user_id:
            # ToDo: Log INFO Warning
            # 'Detect Wrong Impersonate User Behavior (Become original found empty impersonated.).'
            _logger.warning('Detect Wrong Impersonate User Behavior. Become Original User Found Empty Impersonated.')
            pass
        if to_be_user.impersonated_user_id.id != to_be_user.id:
            # ToDo: Log INFO Warning
            # 'Detect Wrong Impersonate User Behavior (Become original found different impersonated.).'
            _logger.warning('Detect Wrong Impersonate User Behavior. Become Original User Found Different Impersonated.')
            pass
        if to_be_user._name == 'res.users':
            to_be_user.impersonated_user_id = False
            self.impersonated_by_id = False
            return True
        raise UserError(_('Become User is not used properly.'))
 
    def btn_impersonate_user(self):
        if not self.access_token:
            raise UserError(_('%s Access Token is missing'% self.name))

        return {'type': 'ir.actions.act_url',
                'name': 'Impersonate User',
                'target': 'self',
                'url': '/become/%s' % self.access_token}
