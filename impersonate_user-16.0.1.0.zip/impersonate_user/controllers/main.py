# -*- coding: utf-8 -*-
##############################################################################
#                                                                            #
# Part of Caret IT Solutions Pvt. Ltd. (Website: www.caretit.com).           #
# See LICENSE file for full copyright and licensing details.                 #
#                                                                            #
##############################################################################

from odoo import http
from werkzeug.exceptions import BadRequest
from odoo.http import request
from odoo.service import security
from odoo.tools.translate import _
from odoo.exceptions import UserError


class ImpersonateUser(http.Controller):

    def _login_redirect(self, uid, redirect=None):
        return redirect if redirect else '/web'

    def session_common_code(self):
        request.env['res.users'].clear_caches()
        request.session.session_token = security.compute_session_token(
            request.session, request.env)
        request.session.original_user = request.env['res.users'].browse(
            request.uid).id

    @http.route('/become/<string:access_token>', auth='user', type='http', website=False)
    def switch_user(self, access_token, **kw):
        curr_user = request.env['res.users'].browse(request.uid)
        # session_id = request.session.sid
        request.session.logout(keep_db=True)
        # to_be_user = request.env['res.users'].with_user(curr_user).browse(user_id)
        to_be_user = request.env['res.users'].with_user(curr_user).search([('access_token','=', access_token)])

        request.session.uid = to_be_user.id
        if to_be_user.has_group('base.group_portal'):
            if request.session.original_user:
                raise UserError(_('Nested impersonate not allowed.'))
            self.session_common_code()
            return request.redirect_query(self._login_redirect(to_be_user.id,'/my'))
        else:
            if to_be_user and len(to_be_user) == 1:
                allow = False
            if request.session.original_user:
                raise UserError(_('Nested impersonate not allowed.'))
            else:
                allow = curr_user.become_user(to_be_user)
            if allow:
                self.session_common_code()
            return request.redirect_query(self._login_redirect(to_be_user.id))
        raise BadRequest()

    @http.route('/become/original', type='http', auth="user", website=False)
    def switch_back(self, **arg):
        if request.session.original_user:
            user = request.env['res.users'].sudo().browse(request.uid)
            to_be_original = request.env['res.users'].sudo().browse(
                request.session.original_user)
            request.session.logout(keep_db=True)
            if to_be_original and len(to_be_original) == 1:
                allow = user.become_original(to_be_original)
                if allow:
                    uid = request.session.uid = to_be_original.id
                    request.env['res.users'].clear_caches()
                    request.session.session_token = security.compute_session_token(
                        request.session, request.env)
                    request.session.original_user = False
                return request.redirect_query(self._login_redirect(uid))
        raise BadRequest()
