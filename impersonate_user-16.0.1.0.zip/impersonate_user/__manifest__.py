# -*- coding: utf-8 -*-
##############################################################################
#                                                                            #
# Part of Caret IT Solutions Pvt. Ltd. (Website: www.caretit.com).           #
# See LICENSE file for full copyright and licensing details.                 #
#                                                                            #
##############################################################################

{
    'name': 'Impersonate User',
    'version': '16.0.1.0',
    'license': 'OPL-1',
    'category': 'Extra Tools',
    'summary': '''
        Impersonate User, Login as impersonate another user, Login As Other Users,
        Admin Users, Administrator, Super User.
    ''',
    'description': '''
        This module allows you to change user quickly and test or do your steps as
        the user and come back to your original user role. So it eliminates login
        procedure. You can allow this feature to specific user in your team.
    ''',
    'company': 'Caret IT Solutions Pvt. Ltd.',
    'author': 'Caret IT Solutions Pvt. Ltd.',
    'maintainer': 'Caret IT Solutions Pvt. Ltd.',
    'website': 'https://www.caretit.com',
    'depends': ['base', 'web'],
    'data': [
        'security/impersonate_group.xml',
        'data/access_token_cron.xml',
        'views/res_users.xml',
    ],
    'images': ['static/description/banner.gif'],
    'price': 49.00,
    'currency': 'EUR',
    'assets': {
        'web.assets_backend': [
            'impersonate_user/static/src/js/become_original.js',
            ('include', 'impersonate_user.assets_frontend'),
            
        ],
        'impersonate_user.assets_frontend': [
            ('include', 'web._assets_helpers'),
            'impersonate_user/static/src/xml/**/*',
        ],
    }
}
