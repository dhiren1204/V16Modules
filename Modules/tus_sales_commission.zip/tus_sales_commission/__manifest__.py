{
    'name': 'Sales Commission',
    'version': '16.1.0.0.1',
    'summary': 'The Commision module is a useful tool that calculates commissions'
               ' for sales reps. Thanks to its many functions, you can react in'
               ' a flexible way if a situation in your company changes.'
               ' You can change the commission value in relation to the sales value,'
               ' type of products and services, or commitment of sales reps.',
    'description': 'This module adds the function to calculate commissions in sales orders.'
                   ' Commission lines assigned to sales order lines will be passed'
                   ' to the corresponding invoice lines.',
    'category': 'operating expenses or selling, general, and administrative expenses',
    'author': 'Riyasat Mirza',
    'depends': ['sale', 'tus_crm_extended', 'account'],
    'data': [
        'security/ir.model.access.csv',
        'wizard/sales_commission.xml',
        'views/sales_commission_menu.xml',
        'views/commission_report.xml',
        'views/commission_config.xml',
    ],
    'installable': True,
    'auto_install': False,
}
