from odoo import fields, models, api, _
from odoo.exceptions import UserError
from datetime import datetime
# from psycopg2 import sql


class SalesCommission(models.TransientModel):
    _name = 'sales.commission'
    _description = 'sales commission'

    name = fields.Char()
    from_date = fields.Date(string='From Date')
    to_date = fields.Date(string='To Date')
    sales_manager_id = fields.Many2one(comodel_name='res.users', string='Sales Manager')
    brand_product_cate_id = fields.Many2one(comodel_name='brand.product.category', string='Category')

    @api.constrains('from_date', 'to_date')
    def _check_dates(self):
        for rec in self:
            if rec.to_date and rec.from_date > rec.to_date:
                raise UserError(_(
                    'End date (%(end)s) must be greater than Start date (%(start)s).',
                    start=rec.from_date, end=rec.to_date,
                ))


    def generate_commission(self):
        moves = self.env['account.move'].sudo().search([
            ('account_manager_id', '=', self.sales_manager_id.id),
            ('state', '=', 'posted'),
            ('payment_state', '=', 'paid'),
            ('move_type', '=', 'out_invoice'),
            ('invoice_date', '>=', self.from_date),
            ('invoice_date', '<=', self.to_date),
        ])
        if moves:
            move_lines = self.env['account.move.line'].sudo().search([
                ('move_id', 'in', moves.ids),
                ('brand_product_cate_id', '=', self.brand_product_cate_id.id),
                ('purchase_currency_id', '!=', False),
                ('already_commission', '=', False),
                ('cost', '!=', 0),
                ('price_unit', '!=', 0),
                ('quantity', '!=', 0),
            ])
            if move_lines:
                list_of_purchase_price = 0
                list_of_sale_price = 0

                # Purchase Price logic

                for each_cur_purchase_lines in [{x.id: sum(self.env['account.move.line'].sudo().search([
                    ('id', 'in', move_lines.ids),
                    ('purchase_currency_id', '=', x.id),
                ]).mapped('cost')) * sum(self.env['account.move.line'].sudo().search([
                    ('id', 'in', move_lines.ids),
                    ('purchase_currency_id', '=', x.id),
                ]).mapped('quantity'))} for x in move_lines.mapped('purchase_currency_id')]:
                    # this for loop are the multy currency lines to convart lost of dict and ,
                    # key value prepar for key as currency and value are each purchase currency sum of ammount * sum of qty
                    cur_purchase_price = self.env['res.currency'].sudo().browse(list(each_cur_purchase_lines.keys()))._convert(
                        list(each_cur_purchase_lines.values())[0],
                        self.env.company.currency_id, # convart currency obj
                        self.env.company,
                        datetime.today().date(),
                    )
                    if cur_purchase_price:
                        list_of_purchase_price+=cur_purchase_price

                # Sale Price logic

                for each_cur_lines in [{x.id: sum(self.env['account.move.line'].sudo().search([
                    ('id', 'in', move_lines.ids),
                    ('currency_id', '=', x.id),
                ]).mapped('price_unit')) * sum(self.env['account.move.line'].sudo().search([
                    ('id', 'in', move_lines.ids),
                    ('currency_id', '=', x.id),
                ]).mapped('quantity'))} for x in move_lines.mapped('currency_id')]:
                    # this for loop are the multy currency lines to convart lost of dict and ,
                    # key value prepar for key as currency and value are each sale currency sum of ammount * sum of qty
                    cur_cost_price = self.env['res.currency'].sudo().browse(list(each_cur_lines.keys()))._convert(
                        list(each_cur_lines.values())[0],
                        self.env.company.currency_id, # convart currency obj
                        self.env.company,
                        datetime.today().date(),
                    )
                    if cur_cost_price:
                        list_of_sale_price+=cur_cost_price
                if list_of_purchase_price and list_of_sale_price:
                    total_line = self.env['account.move.line'].sudo().search([
                        ('move_id', 'in', moves.ids),
                        ('brand_product_cate_id', '=', self.brand_product_cate_id.id),
                        ('purchase_currency_id', '!=', False),
                        ('quantity', '!=', 0),
                        ('cost', '!=', 0),
                        ('price_unit', '!=', 0),
                        ('already_commission', '=', False),
                    ])

                    # fing commission config

                    commission_config = self.env['commission.config'].search([
                        ('name', '=', self.sales_manager_id and self.sales_manager_id.id),
                        ('brand_product_cate_id', '=', self.brand_product_cate_id and self.brand_product_cate_id.id)
                    ])
                    target = commission_config.target
                    profit = list_of_sale_price - list_of_purchase_price
                    percentage_profit = (profit * 100) / target
                    commission = 0.0
                    for line in (commission_config.commission_config_line.
                            filtered(lambda x: (x.name <= percentage_profit and x.to >= percentage_profit)
                                               or x.name <= percentage_profit)):
                        commission = line.commission_amount


                    # create commission report

                    record = self.env['commission.report'].sudo().create({
                        'purchase_price': list_of_purchase_price,
                        'sale_price': list_of_sale_price,
                        'commission': commission,
                        'currency_id': self.env.company.currency_id.id,
                        'manager_id': self.sales_manager_id.id,
                        'category_id': self.brand_product_cate_id.id,
                        'from_date': self.from_date,
                        'to_date': self.to_date,
                        'line_ids': total_line.ids,
                    })
                    record.move_in_ids = [(6, 0, total_line.move_id.ids)]
                    return True

                    # update already_commission field in move lines

                    # if record:
                    #     query = ("""
                    #                 UPDATE account_move_line
                    #                 SET already_commission = TRUE
                    #                 WHERE id IN %(move_line_ids)s
                    #             """)
                    #     self.env.cr.execute(query, {'move_line_ids': tuple(total_line.ids)})
                    #     return self.env.cr.commit()
                else:
                    raise UserError(_(' - Record not found.\n - Record already exists.'))

            else:
                raise UserError(_(' - Record not found.\n - Record already exists.'))
        else:
            raise UserError(_('Record not found.'))
