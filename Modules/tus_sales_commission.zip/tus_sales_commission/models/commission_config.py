from odoo import api, fields, models, _
from odoo.exceptions import UserError

class CommissionConfig(models.Model):
    _name = 'commission.config'


    name = fields.Many2one(comodel_name='res.users', string='Sales Manager')
    commission_config_line = fields.One2many(
        comodel_name='commission.config.line',
        inverse_name='commission_config_id',
        string='Commission Config Line',
        )
    target = fields.Float(string='Target')
    brand_product_cate_id = fields.Many2one(comodel_name='brand.product.category', string='Category')





class CommissionConfigLine(models.Model):
    _name = 'commission.config.line'
    _description = 'Commission Config Line'

    name = fields.Float(string="From (Above) (%)", required=True)
    to = fields.Float(string="To (Below) (%)", required=True)
    commission = fields.Float(string='Commission (%)')
    commission_config_id = fields.Many2one(comodel_name='commission.config',string='Commission Config')
    commission_amount = fields.Float(string='Commission Amount', compute='_get_commission_amount', store=True)

    @api.depends('name', 'to', 'commission', 'commission_config_id.target')
    def _get_commission_amount(self):
        list_of_commission_amount = []
        target = self.commission_config_id.target
        is_check = False
        old_val = 0
        for rec in self.env['commission.config.line'].search([('commission_config_id', '=', self.commission_config_id.id)], order='to ASC'):
            if rec.to:
                amount = (target * rec.to) / 100
                if is_check:
                    amount = amount - old_val
                old_val += amount
                list_of_commission_amount.append((amount * rec.commission) / 100)
                rec.commission_amount = sum(list_of_commission_amount)
                is_check = True


    @api.onchange('name', 'to')
    def _onchange_exists_value(self):
        if self._context.get('to') == 'to' or self._context.get('name') == 'name':
            to_changes = self.commission_config_id.commission_config_line.filtered(lambda x: x == self)
            if to_changes.name == to_changes.to:
                raise UserError(_('Range is already exists'))
        if self._context.get('to') == 'to':
            to_changes = self.commission_config_id.commission_config_line.filtered(lambda x: x.id != self.id and x._origin)
            if to_changes.filtered(lambda x: (x.name <= self.to <= x.to)):
                raise UserError(_('Range is already exists'))
        if self._context.get('name') == 'name':
            to_changes = self.commission_config_id.commission_config_line.filtered(lambda x: x.id != self.id and x._origin)
            if to_changes.filtered(lambda x: (x.name <= self.name <= x.to)):
                raise UserError(_('Range is already exists'))


        # if self._context.get('new_line') != 'new':
        #     if self._context.get('to'):
        #         check_rec = self.commission_config_id.commission_config_line.filtered(
        #             lambda x: x.name >= self.to and x.to <= self.to and x != self)
        #         if check_rec:
        #             raise UserError(_('Range is already exists'))
        #     else:
        #         check_rec = self.commission_config_id.commission_config_line.filtered(lambda x: x.name <= self.name and x.to >= self.name and x != self)
        #         if check_rec:
        #             raise UserError(_('Range is already exists'))


