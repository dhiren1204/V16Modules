from odoo import api, fields, models
import json

class CommissionReport(models.Model):
    _name = 'commission.report'

    name = fields.Char()
    purchase_price = fields.Float(string='Purchase Price')
    sale_price = fields.Float(string='Sale Price')
    manager_id = fields.Many2one(comodel_name='res.users', string='Manager')
    move_in_ids = fields.Many2many(comodel_name='account.move', string='Moves', store=True)
    currency_id = fields.Many2one(comodel_name='res.currency', string='Currency')
    category_id = fields.Many2one(comodel_name='brand.product.category', string='Category')
    from_date = fields.Date(string='From Date')
    to_date = fields.Date(string='To Date')
    line_ids = fields.Char(string='')
    is_commission = fields.Boolean(string='Commission')
    commission = fields.Float(string='Commission Amount')


    def commission_approve(self):
        move_lines = []
        for rec in self:
            move_lines += json.loads(rec.line_ids)
            rec.is_commission = True
        move_lines = list(set(move_lines))
        if move_lines:
            query = ("""
                        UPDATE account_move_line
                        SET already_commission = TRUE
                        WHERE id IN %(move_line_ids)s
                    """)
            self.env.cr.execute(query, {'move_line_ids': tuple(move_lines)})
            return self.env.cr.commit()

    def unlink(self):
        move_lines = []
        for rec in self:
            move_lines += json.loads(rec.line_ids)
        move_lines = list(set(move_lines))
        rec = super().unlink()
        if rec and move_lines:
            query = ("""
                    UPDATE account_move_line
                    SET already_commission = FALSE
                    WHERE id IN %(move_line_ids)s
                """)
            self.env.cr.execute(query, {'move_line_ids': tuple(move_lines)})
            self.env.cr.commit()
        return rec



class MoveLineCommission(models.Model):
    _inherit = 'account.move.line'

    already_commission = fields.Boolean(string='Already Commission')
