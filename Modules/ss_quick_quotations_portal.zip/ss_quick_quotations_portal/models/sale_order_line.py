# -*- coding: utf-8 -*-
from odoo import api, fields, models, _
class SaleOrderLine(models.Model):
    # Private attributes
    _inherit = 'sale.order.line'

    _sql_constraints = [
        ('accountable_required_fields', 'Check(1=1)',
         'Missing required fields on accountable sale order line.')
    ]

    @api.depends('product_id')
    def _compute_name(self):
        for line in self:
            if line.name:
                line.name = line.name
            else:
                super()._compute_name()