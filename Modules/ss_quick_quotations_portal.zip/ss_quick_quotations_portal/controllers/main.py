# -*- coding: utf-8 -*-
# Part of Odoo. See COPYRIGHT & LICENSE files for full copyright and licensing details.

import base64
from operator import itemgetter
from odoo import http, tools, fields, _
from odoo.http import request
from odoo.osv.expression import OR
from odoo.exceptions import ValidationError
from odoo.tools import groupby as groupbyelem
from odoo.addons.portal.controllers.portal import CustomerPortal, pager as portal_pager, get_records_pager
from odoo import Command
from odoo.exceptions import UserError


class CustomController(CustomerPortal):
    def slicedict(self, d, s):
        return {k: v for k, v in d.items() if k.startswith(s)}

    @http.route(['/create/quotations','/create/quotations/<int:quotation>'], type='http', auth="user", website=True)
    def quick_create_quotations(self, quotation=False, **kwargs):
        quotation_sudo = request.env['sale.order'].sudo().search([('id','=',quotation)])
        if quotation_sudo:
            return http.request.render("ss_quick_quotations_portal.quick_update_quotations", {
                'page_name': 'quotation_update',
                'quotation_sudo': quotation_sudo,
            })
        return http.request.render("ss_quick_quotations_portal.quick_create_quotations",{
            'page_name': 'quotation_create',
            'quotation_sudo': quotation_sudo,
        })

    def update_quotation(self, quotation):
        quot_obj = request.env['sale.order'].sudo()
        quotation_id = quot_obj.browse(int(quotation['quotation']))

        if quotation.get('remove_line'):
            remove_so = quotation.get('remove_line').split(',')
            so_lines = request.env['sale.order.line'].sudo().search([('id','in',remove_so)])
            so_lines.unlink()

        so_line = []
        for item in self.slicedict(quotation, 'name_').keys():
            rec = int(item.split('_')[-1])
            so_line_dict = {}
            if quotation.get('name_{}'.format(rec)):
                so_line_dict.update({'name': quotation.get('name_{}'.format(rec))})
            if quotation.get('product_uom_qty_{}'.format(rec)):
                so_line_dict.update({'product_uom_qty': quotation.get('product_uom_qty_{}'.format(rec))})

            if quotation.get('so_line_id_{}'.format(rec)):
                order_line = request.env['sale.order.line'].sudo().search([('id','=',int(quotation.get('so_line_id_{}'.format(rec))))])
                order_line.write(so_line_dict)

            if so_line_dict and not quotation.get('so_line_id_{}'.format(rec)):
                so_line.append(Command.create(so_line_dict))

        quotation_id.write(
            {'partner_id': int(quotation.get("partner_id")) if quotation.get("partner_id") else False,
             'partner_invoice_id': int(quotation.get("partner_invoice_id")) if quotation.get(
                 "partner_invoice_id") else False,
             'partner_shipping_id': int(quotation.get("partner_shipping_id")) if quotation.get(
                 "partner_shipping_id") else False,
             'completion_date': quotation.get("completion_date"),
             'order_line': so_line,
             })
        return quotation

    def create_quotation(self, quotation):
        so_obj = request.env['sale.order'].sudo()
        so_line = []
        for item in self.slicedict(quotation, 'name_').keys():
            rec = int(item.split('_')[-1])
            so_line_dict = {}
            if quotation.get('name_{}'.format(rec)):
                so_line_dict.update({'name': quotation.get('name_{}'.format(rec))})
            if quotation.get('product_uom_qty_{}'.format(rec)):
                so_line_dict.update({'product_uom_qty': quotation.get('product_uom_qty_{}'.format(rec))})
            if so_line_dict:
                so_line.append(Command.create(so_line_dict))

        quotation = so_obj.create(
            {'partner_id': int(quotation.get("partner_id")) if quotation.get("partner_id") else False,
             'partner_invoice_id': int(quotation.get("partner_invoice_id")) if quotation.get("partner_invoice_id") else False,
             'partner_shipping_id': int(quotation.get("partner_shipping_id")) if quotation.get("partner_shipping_id") else False,
             'completion_date': quotation.get("completion_date"),
             'order_line':so_line,
             })
        return quotation

    def _prepare_quotations_domain(self, partner):
        return [
            ('message_partner_ids', 'child_of', [partner.commercial_partner_id.id]),
            ('state', 'in', ['sent','draft'])
        ]

    @http.route('/quotation/request', type='http', auth='public', website=True, csrf=False)
    def expense_request(self, **post):
        print(post)
        quotation_id = False
        quot_obj = request.env['sale.order'].sudo()
        if post.get('quotation'):
            quotation_id = quot_obj.browse(int(post['quotation']))
        if quotation_id:
            if len(post) > 1:
                post = self.update_quotation(post)
                return request.render("ss_quick_quotations_portal.thankyou_quotation")
        else:
            post = self.create_quotation(post)
            return request.render("ss_quick_quotations_portal.thankyou_quotation_submitted")
        # try:
            # expense_obj = request.env['hr.expense.sheet'].with_user(request.env.uid).sudo()
            # if post.get('expense'):
            #     expense_id = expense_obj.browse(int(post['expense']))
            # if expense_id:
            #     if len(post) > 1:
            #         post = self.update_expense_sheet(post)
            #         if post.get('save'):
            #             return request.render("portal_hr_expense.thankyou_expense")
            #         else:
            #             return request.render("portal_hr_expense.thankyou_expense_submitted")
            # else:
            #     if len(post) > 1:

        # if post.get('save'):
        #     return request.render("portal_hr_expense.thankyou_expense")
        # else:


        # except Exception as e:
        #     request.env.cr.rollback()
        #     if not expense_id:
        #         return request.redirect("/create/expense/request?error=%s" % e.args[0])
        #     else:
        #         return request.redirect("/my/expense/%s?error=%s" % (expense_id.id, e.args[0]))
        # 5/0
        # if not post.get('type'):
        #     return request.redirect("/create/expense/request")
        # expense_id = False
        # try:
        #     expense_obj = request.env['hr.expense.sheet'].with_user(request.env.uid).sudo()
        #     if post.get('expense'):
        #         expense_id = expense_obj.browse(int(post['expense']))
        #     if expense_id:
        #         if len(post) > 1:
        #             post = self.update_expense_sheet(post)
        #             if post.get('save'):
        #                 return request.render("portal_hr_expense.thankyou_expense")
        #             else:
        #                 return request.render("portal_hr_expense.thankyou_expense_submitted")
        #     else:
        #         if len(post) > 1:
        #             post = self.create_expense_sheet(post)
        #             if post.get('save'):
        #                 return request.render("portal_hr_expense.thankyou_expense")
        #             else:
        #                 return request.render("portal_hr_expense.thankyou_expense_submitted")
        #
        # except Exception as e:
        #     request.env.cr.rollback()
        #     if not expense_id:
        #         return request.redirect("/create/expense/request?error=%s" % e.args[0])
        #     else:
        #         return request.redirect("/my/expense/%s?error=%s" % (expense_id.id, e.args[0]))