# -*- coding: utf-8 -*-
{
    'name': "Portal Quick Quatations Create",
    'summary': """ Portal Employee can create the quatations. """,
    'description': """Portal users can create their quatations by website portal without any interaction with backend side.""",
    'author': 'TechUltra Solution',
    'website': 'https://www.techultrasolutions.com',
    'category': 'Website',
    'version': '1.2',
    'depends': ['portal', 'sale', 'project','base_ss'],
    'data': [
        "views/quatations_from_template.xml",
        "views/create_new_quatations.xml",
    ],
    'assets': {
        'web.assets_frontend': [
            "/ss_quick_quotations_portal/static/src/xml/table_template.xml",
            "/ss_quick_quotations_portal/static/src/js/portal_quotation_create.js",
        ],
    },
    'images': ['static/description/main_screen.png'],
    'license': 'OPL-1',
    'currency': 'EUR',
    'installable': True,
    'application': True,
    'auto_install': False,
}
