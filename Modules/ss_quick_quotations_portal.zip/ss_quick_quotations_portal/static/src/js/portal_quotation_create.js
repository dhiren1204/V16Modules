/** @odoo-module **/

import publicWidget from "@web/legacy/js/public/public_widget";
import { renderToElement } from "@web/core/utils/render";

publicWidget.registry.QuotationRequest = publicWidget.Widget.extend({
    selector: '.o_quot_request',
    events: {
        'click .oncreate':'_oncreate',
        'click .edit':'_onedit',
        'click .delete':'_ondelete',
    },
    init() {
        this._super(...arguments);
        this.rpc = this.bindService("rpc");
    },
    _ondelete(ev){
         var line_id = $(ev.currentTarget).data('line_id');
         $(ev.currentTarget).closest('tr').remove();
         var remove_line_ids = $('#remove_line_id').val()
         if(remove_line_ids != ''){
            remove_line_ids = remove_line_ids+ ','+line_id
         }
         else{
            remove_line_ids = line_id
         }
         $('#remove_line_id').val(remove_line_ids)
    },
    _onedit(ev){
        var row_number = $(ev.currentTarget).data('row_number');
        var name1 = $('input[name="name_'+row_number+'"]').val()
        var product_uom_qty2 = $('input[name="product_uom_qty_'+row_number+'"]').val()


        $('#solinepopup').find('input.name').val(name1);
        $('#solinepopup').find('#product_uom_qty').val(product_uom_qty2);
        $('#row_number').val(row_number);
        $('#solinepopup').modal('show');
    },
    _oncreate(){
         debugger;

         var row = $('#row_number').val()
         if(row != ''){
            var value1 = $('input.name').val()
            var value2 = $("#product_uom_qty").val()

            var name1 = $('input[name="name_'+row+'"]').val(value1)
            var product_uom_qty2 = $('input[name="product_uom_qty_'+row+'"]').val(value2)

            $("#solinepopup").modal('hide');;
            $("input.name").val('')
            $("#product_uom_qty").val('')
            $('#row_number').val('')
         }
         else{
             var value1 = $('input.name').val()
             var value2 = $("#product_uom_qty").val()

    //         value9 = $('#purpose_transfer_operational').val()
              var fields = [
                {value: value1, name: 'Description'},
                {value: value2, name: 'Quantity'},
            ];
            // Check if any field is empty
            var emptyFields = fields.filter(function(field) {
                return field.value === '';
            });

             if (emptyFields.length > 0) {
                var emptyFieldNames = emptyFields.map(function(field) {
                    return field.name;
                }).join(', ');

                alert('Please enter the following required fields: ' + emptyFieldNames);
            }else{
                var Solinerow = $(renderToElement("ss_quick_quotations_portal.soline_row", {'row_no': ($('.ipc_soline_row').length + 1),"name": value1,"product_uom_qty": value2}))

                 $(".form_detail").find("tbody").append(Solinerow);
                                   $(Solinerow).on('click', '.edit', function() {
                                        debugger;
                                        var row_number = $(this).data('row_number');
                                        var name1 = $('input[name="name_'+row_number+'"]').val()
                                        var product_uom_qty2 = $('input[name="product_uom_qty_'+row_number+'"]').val()


                                        $('#solinepopup').find('input.name').val(name1);
                                        $('#solinepopup').find('#product_uom_qty').val(product_uom_qty2);
                                        $('#row_number').val(row_number);
                                        $('#solinepopup').modal('show');


                                   });
                                   $(Solinerow).on('click', '.delete', function() {
                                        $(this).closest('tr').remove();
                                    });
                $("#solinepopup").modal('hide');;
                 $("input.name").val('')
                $("#product_uom_qty").val('')
                $('#row_number').val('')
            }
        }
     },


});