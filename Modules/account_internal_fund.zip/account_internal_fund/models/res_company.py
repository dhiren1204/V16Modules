from odoo import api, fields, models, _


class ResCompany(models.Model):
    _inherit = 'res.company'

    transfer_journal_id = fields.Many2one("account.journal", string='Transfer Journal')
