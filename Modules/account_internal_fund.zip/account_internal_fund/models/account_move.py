from odoo import api, fields, models


class AccountMove(models.Model):
    _inherit = 'account.move'

    is_current_rate = fields.Boolean(string='Is Current Rate')
