from lxml import etree

from odoo import models, fields, api, _
from datetime import datetime
from odoo.exceptions import UserError, ValidationError, Warning


class InternalFund(models.Model):
    _name = "internal.fund"
    _inherit = ["mail.thread", "mail.activity.mixin"]
    _description = "Internal Fund"
    _rec_name = "name"

    name = fields.Char('Name', copy=False, readonly=True, default=lambda x: _('New'))
    move_ids = fields.Many2many(
        comodel_name="account.move",
        string="Journal Entry",
        copy=False,
    )
    company_id = fields.Many2one(
        "res.company", "Company", default=lambda self: self.env.company.id, copy=False
    )
    transfer_journal_id = fields.Many2one(
        "account.journal",
        string="Transfer Journal",
        related="company_id.transfer_journal_id",
        readonly=False,
    )
    journal_id = fields.Many2one(
        "account.journal",
        string="From Bank",
        domain="[('type', 'in', ('bank', 'cash')), ('company_id', '=', company_id)]",
    )
    company_currency_id = fields.Many2one('res.currency', string="Currency", default=lambda self: self.env.company.currency_id.id)
    delivered_amount = fields.Monetary(currency_field="currency_id")
    received_amount = fields.Monetary(currency_field="to_currency_id")
    currency_id = fields.Many2one("res.currency", "From Currency", required=True, compute='_compute_currency_id')
    to_currency_id = fields.Many2one("res.currency", "To Currency", required=True, compute='_compute_to_currency_id')
    from_current_currency_rate = fields.Float(
        "From exchange rate",
        compute="_compute_from_current_currency_rate",
        readonly=False,
        compute_sudo=True,
        store=True,
    )
    to_current_currency_rate = fields.Float(
        "To exchange rate",
        compute="_compute_to_current_currency_rate",
        readonly=False,
        compute_sudo=True,
        store=True,
    )
    from_current_currency_without_company_rate = fields.Float(
        "From exchange rate",
        compute="_compute_from_current_currency_without_company_rate",
        readonly=False,
        compute_sudo=True,
        store=True,
    )
    to_current_currency_without_company_rate = fields.Float(
        "To exchange rate",
        compute="_compute_to_current_currency_without_company_rate",
        readonly=False,
        compute_sudo=True,
        store=True,
    )
    from_exchange_rate = fields.Float(
        "Exchange Rate",
        compute="_compute_from_exchange_rate",
        compute_sudo=True,
        store=True,
    )
    to_exchange_rate = fields.Float(
        "Exchange Rate",
        compute="_compute_to_exchange_rate",
        compute_sudo=True,
        store=True,
    )
    destination_journal_id = fields.Many2one(
        "account.journal",
        string="To Bank",
        domain="[('type', 'in', ('bank', 'cash')), ('company_id', '=', company_id)]",
    )
    date = fields.Date(string="Date", required=True)
    from_received_amount = fields.Monetary(
        string="From Received Amount",
        readonly=True,
        compute="_compute_from_received_amount",
        store=True,
        currency_field='company_currency_id'
    )
    to_received_amount = fields.Monetary(
        string="To Received Amount",
        readonly=True,
        compute="_compute_to_received_amount",
        store=True,
        currency_field='company_currency_id'
    )
    state = fields.Selection(
        [("draft", "Draft"), ("posted", "Posted")],
        string="State",
        readonly=True,
        default="draft",
    )
    operating_unit_id = fields.Many2one('operating.unit', string='Branch')
    analytic_account_id = fields.Many2one('account.analytic.account', 'Analytic Account', check_company=True)
    check_num = fields.Char(string='Check No./Wire Transfer No.', readonly=False)
    # == Payment methods fields ==
    payment_method_id = fields.Many2one('account.payment.method', string='Payment Method',
                                        help="Manual: Get paid by cash, check or any other method outside of Odoo.\n" \
                                             "Electronic: Get paid automatically through a payment acquirer by requesting a transaction on a card saved by the customer when buying or subscribing online (payment token).\n" \
                                             "Check: Pay bill by check and print it from Odoo.\n" \
                                             "Batch Deposit: Encase several customer checks at once by generating a batch deposit to submit to your bank. When encoding the bank statement in Odoo, you are suggested to reconcile the transaction with the batch deposit.To enable batch deposit, module account_batch_payment must be installed.\n" \
                                             "SEPA Credit Transfer: Pay bill from a SEPA Credit Transfer file you submit to your bank. To enable sepa credit transfer, module account_sepa must be installed ")

    @api.model
    def create(self, vals):
        if (not vals.get('name') or vals['name'] == _('New')):
            vals['name'] = self.env['ir.sequence'].next_by_code('internal.fund') or '/'
        return super().create(vals)

    @api.onchange('received_amount')
    def onchange_received_amount(self):
        if self.received_amount and self.delivered_amount:
            self.to_current_currency_without_company_rate = self.received_amount / self.delivered_amount

    @api.depends("date", "currency_id", "company_id", "company_id.currency_id")
    def _compute_from_current_currency_rate(self):
        for fund in self:
            if fund.company_id and fund.company_id.currency_id and fund.currency_id:
                rate = self.env["res.currency"]._get_conversion_rate(
                    fund.company_id.currency_id,
                    fund.currency_id,
                    fund.company_id,
                    fund.date or datetime.today(),
                )
                fund.from_current_currency_rate = 1.0 / rate
            else:
                fund.from_current_currency_rate = 1.0

    @api.depends("date", "currency_id", "to_currency_id")
    def _compute_from_current_currency_without_company_rate(self):
        for fund in self:
            if fund.currency_id and fund.to_currency_id:
                rate = self.env["res.currency"]._get_conversion_rate(
                    fund.currency_id,
                    fund.to_currency_id,
                    fund.company_id,
                    fund.date or datetime.today(),
                )
                fund.from_current_currency_without_company_rate = 1.0 / rate
            else:
                fund.from_current_currency_without_company_rate = 1.0

    @api.depends("from_current_currency_rate")
    def _compute_from_exchange_rate(self):
        for fund in self:
            fund.from_exchange_rate = fund.from_current_currency_rate or 1.0

    @api.depends("journal_id", "journal_id.currency_id")
    def _compute_currency_id(self):
        for fund in self:
            if fund.journal_id and fund.journal_id.currency_id:
                fund.currency_id = fund.journal_id.currency_id
            else:
                fund.currency_id = self.env.company.currency_id

    @api.depends("destination_journal_id", "destination_journal_id.currency_id")
    def _compute_to_currency_id(self):
        for fund in self:
            if fund.destination_journal_id and fund.destination_journal_id.currency_id:
                fund.to_currency_id = fund.destination_journal_id.currency_id
            else:
                fund.to_currency_id = self.env.company.currency_id

    @api.depends("date", "to_currency_id", "company_id", "company_id.currency_id", "from_received_amount", "received_amount")
    def _compute_to_current_currency_rate(self):
        for fund in self:
            fund.to_current_currency_rate = 0.0
            if fund.from_received_amount and fund.received_amount:
                fund.to_current_currency_rate = fund.from_received_amount / fund.received_amount
            # if fund.company_id and fund.company_id.currency_id and fund.to_currency_id:
            #     rate = self.env["res.currency"]._get_conversion_rate(
            #         fund.company_id.currency_id,
            #         fund.to_currency_id,
            #         fund.company_id,
            #         fund.date or datetime.today(),
            #     )
            #     fund.to_current_currency_rate = 1.0 / rate
            # else:
            #     fund.to_current_currency_rate = 1.0

    @api.depends("date", "to_currency_id", "currency_id")
    def _compute_to_current_currency_without_company_rate(self):
        for fund in self:
            if fund.to_currency_id and fund.currency_id:
                rate = self.env["res.currency"]._get_conversion_rate(
                    fund.to_currency_id,
                    fund.currency_id,
                    fund.company_id,
                    fund.date or datetime.today(),
                )
                fund.to_current_currency_without_company_rate = 1.0 / rate
            else:
                fund.to_current_currency_without_company_rate = 1.0

    @api.depends("to_current_currency_rate")
    def _compute_to_exchange_rate(self):
        for fund in self:
            fund.to_exchange_rate = fund.to_current_currency_rate or 1.0

    def write(self, values):
        res = super(InternalFund, self).write(values)
        for move in self.move_ids:
            if (values.get("delivered_amount") or values.get("from_exchange_rate") or values.get("to_exchange_rate") or values.get("from_current_currency_rate") or values.get("to_current_currency_rate") or values.get("currency_id") or values.get("to_currency_id")) and move.state == "draft":
                move.write(
                    {
                        "date": self.date,
                        "journal_id": self.transfer_journal_id.id,
                        "currency_id": self.currency_id.id,
                    }
                )
                for line in move.line_ids:
                    line.with_context(check_move_validity=False).write(
                        {
                            "amount_currency": (self.delivered_amount if line.currency_id == move.currency_id else self.received_amount) if line.debit > 0.0 else (-abs(self.delivered_amount) if line.currency_id == move.currency_id else -abs(self.received_amount)),
                            "debit": (self.from_received_amount if not move.is_current_rate else self.to_received_amount)
                            if line.debit > 0.0
                            else 0.0,
                            "credit": (self.from_received_amount if not move.is_current_rate else self.to_received_amount)
                            if line.credit > 0.0
                            else 0.0,
                            "currency_id": self.currency_id.id if line.currency_id == move.currency_id else self.to_currency_id.id,
                        }
                    )
        return res

    def action_post(self):
        """draft -> posted"""
        if self.env.company.currency_id.skip_internal_fund:
            raise ValidationError(
                _(
                    "Skipable %s currency in company, You can't confirm fund." % self.env.company.currency_id.name
                )
            )
        if not self.move_ids:
            move_vals = {
                "date": self.date,
                "journal_id": self.transfer_journal_id.id,
                "currency_id": self.currency_id.id,
                "move_type": "entry",
                "operating_unit_id": self.operating_unit_id.id,
            }
            self.create_account_journal_entry(move_vals=move_vals)
            self.create_account_journal_entry(move_vals=move_vals, currency_rate=True)
        self.write({"state": "posted"})

    def create_account_journal_entry(self, move_vals, currency_rate=False):
        to_write = {}
        to_write["line_ids"] = [
            (0, 0, line_vals)
            for line_vals in self.with_context(
                check_move_validity=False
            )._prepare_move_line_default_vals(currency_rate=currency_rate)
        ]
        move_vals.update({"is_current_rate": False if currency_rate else True})
        journal_id = self.env["account.move"].create(move_vals)
        if to_write:
            journal_id.write(to_write)
        self.move_ids = [(4, journal_id.id)]

    def action_draft(self):
        self.write({"state": "draft"})
        for move in self.move_ids:
            if move.state not in ["draft", "cancel"]:
                move.state = "draft"

    @api.depends(
        "currency_id", "company_id.currency_id", "delivered_amount", "from_current_currency_rate"
    )
    def _compute_from_received_amount(self):
        for fund in self:
            fund.from_received_amount = fund.delivered_amount * fund.from_current_currency_rate
            fund.received_amount = fund.delivered_amount * round(fund.to_current_currency_without_company_rate, 2)

    @api.depends(
        "to_currency_id", "company_id.currency_id", "received_amount", "to_current_currency_rate"
    )
    def _compute_to_received_amount(self):
        for fund in self:
            fund.to_received_amount = fund.received_amount * fund.to_current_currency_rate

    def button_open_journal_entry(self):
        """Redirect the user to this payment journal.
        :return:    An action on account.move.
        """
        self.ensure_one()
        action = {
            "name": _("Journal Entry"),
            "type": "ir.actions.act_window",
            "res_model": "account.move",
        }
        if len(self.move_ids.ids) == 1:
            action.update({
                'view_mode': 'form',
                'res_id': self.move_ids[0],
            })
        else:
            action.update({
                'domain': [('id', 'in', self.move_ids.ids)],
                'view_mode': 'tree,form',
            })
        return action

    def _prepare_move_line_default_vals(self, currency_rate=False):
        self.ensure_one()
        if not self.journal_id.payment_credit_account_id.id:
            raise ValidationError(
                _(
                    "Please configure Account in From Journal(%s)."
                    % self.journal_id.name
                )
            )
        line_vals_list = [
            {
                "name": self.company_id.transfer_account_id.name if currency_rate else self.journal_id.payment_credit_account_id.name,
                "date_maturity": self.date,
                "analytic_account_id": self.analytic_account_id.id,
                "check_ref": self.check_num,
                "amount_currency": -abs(self.delivered_amount),
                "currency_id": self.currency_id.id,
                "debit": 0.0,
                "credit": self.to_received_amount if currency_rate else self.from_received_amount,
                "account_id": self.company_id.transfer_account_id.id if currency_rate else self.journal_id.payment_credit_account_id.id,
            },
            {
                "name": self.destination_journal_id.payment_debit_account_id.name if currency_rate else self.company_id.transfer_account_id.name,
                "date_maturity": self.date,
                "analytic_account_id": self.analytic_account_id.id,
                "check_ref": self.check_num,
                "amount_currency": self.received_amount if currency_rate else self.delivered_amount,
                "currency_id": self.to_currency_id.id if currency_rate else self.currency_id.id,
                "debit": self.to_received_amount if currency_rate else self.from_received_amount,
                "credit": 0.0,
                "account_id": self.destination_journal_id.payment_debit_account_id.id if currency_rate else self.company_id.transfer_account_id.id,
            },
        ]
        if not self.destination_journal_id.payment_debit_account_id.id:
            raise ValidationError(
                _(
                    "Please configure Account in To Journal(%s)."
                    % self.destination_journal_id.name
                )
            )

        return line_vals_list
