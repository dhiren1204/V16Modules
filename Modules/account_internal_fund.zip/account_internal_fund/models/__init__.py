# -*- coding: utf-8 -*-

from . import internal_fund
from . import res_config_settings
from . import res_company
from . import res_currency
from . import account_move
