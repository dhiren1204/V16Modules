from odoo import api, fields, models, _


class ResCurrency(models.Model):
    _inherit = 'res.currency'

    skip_internal_fund = fields.Boolean(string='Skip Internal Fund')
