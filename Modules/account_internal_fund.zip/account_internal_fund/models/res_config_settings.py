from odoo import api, fields, models


class ResConfigSetting(models.TransientModel):
    _inherit = 'res.config.settings'

    transfer_journal_id = fields.Many2one("account.journal", related='company_id.transfer_journal_id', string='Transfer Journal', readonly=False)
