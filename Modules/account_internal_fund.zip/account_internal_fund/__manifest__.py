# -*- coding: utf-8 -*-
{
    'name': "Bank Internal Transfer",
    'summary': "",
    'description': """
        Internal Transfer between multiple bank
    """,
    'author': "TechUltra Solutions Pvt. Ltd.",
    'website': "https://www.techultrasolutions.com/",
    'category': 'Accounting',
    'version': '14.0.0.1.1',
    'depends': ['account'],
    'data': [
        'security/ir.model.access.csv',
        "data/sequence.xml",
        "views/internal_fund_view.xml",
        "views/res_config_setting.xml",
        "views/res_currency_views.xml",
    ],
    "external_dependencies": {
        "python": [],
        "bin": [],
    },
    'installable': True,
    'application': True,
}
