# -*- coding: utf-8 -*-
{
    'name': "Hr face recognition Attendance capture",
    'summary': """
        This module worked security perpose when employee Attendeance menually check in and check out time the employee image capture on display employee attendance line.
        """,

    'description': """
        Video streaming image capture.
        Face recognize
        Face Capture
        Attendance Face Capture
        Hr Attendance Face recognize
        Hr Attendance
        Hr attendance face recognition
        Face recognition 
        Employee
        Attendace
        Odoo Attendance 
    """,
    'images':['static/description/banner.jpg'],
    'author': 'TechUltra Solutions Private Limited',
    'category': 'Human Resources',
    'company': 'TechUltra Solutions Private Limited',
    'website': "https://www.techultrasolutions.com/",
    'version': '16.0.1.0.0',
    'license': 'AGPL-3',


    # any module necessary for this one to work correctly
    'depends': ['base', 'hr_attendance','hr_org_chart'],

    # always loaded
    'data': [
        # 'security/ir.model.access.csv',
        'views/hr_attendance_view.xml',
    ],
    'assets': {
        'web.assets_backend': [
            'tus_screenshort_by_attendence/static/src/xml/attendance_ss.xml',
            'tus_screenshort_by_attendence/static/src/js/my_attendance_ss.js',
            "tus_screenshort_by_attendence/static/src/css/style.css",
        ],
    },
    "images": [
        "static/description/main_screen.gif",
    ],
    'price': 21.9,
    'currency': 'USD'
}
