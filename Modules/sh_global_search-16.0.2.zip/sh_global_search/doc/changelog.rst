16.0.1 (26 Sept 2022)
------------------

- initial release

 (8th Nov 2022)
---------------------

- fixed multiple display issue

 (21 Nov 2023)
---------------------
- fixed global search backenda and spacing issues.