# Copyright (C) Softhealer Technologies.

from . import global_search
