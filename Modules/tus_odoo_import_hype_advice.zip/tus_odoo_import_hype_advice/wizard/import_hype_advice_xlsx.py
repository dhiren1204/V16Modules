import datetime
import io
from odoo import models, fields, _
from odoo.exceptions import ValidationError
from dateutil import parser
import xlrd
import base64
from io import BytesIO
from odoo.tools.misc import xlsxwriter
import logging

_logger = logging.getLogger('Import Hype Advise')

class ImportHypeAdvice(models.TransientModel):
    _name = 'import.hype.advice'
    _description = 'This models is for the importing of hype advise excel sheet'

    xls_file = fields.Binary(attachment=True, string='XLS File')
    sheet_name = fields.Char('Sheet Name')
    detail_file = fields.Binary("File")

    def read_xlx_file(self):
        file_data = self.xls_file
        if not file_data:
            raise ValidationError(_('Error!', "Please Select a File"))
        else:
            val = base64.decodebytes(file_data)
            tempfile = BytesIO()
            tempfile.write(val)
            work_book = xlrd.open_workbook(file_contents=tempfile.getvalue())
        return work_book

    def create_update_hype_advise_data(self):
        if self.xls_file:
            work_book = self.read_xlx_file()
            _logger.info("============= Import Hype Advise ================")
            sheet_list = work_book._sheet_list
            # for sheet in work_book._sheet_list:
            if self.sheet_name:
                if self.sheet_name.strip() not in list(map(lambda x:x.name, work_book._sheet_list)):
                    raise ValidationError("Enter correct Sheet Name!")
            sheet_index = [i for i, value in enumerate(list(map(lambda x:x.name, work_book._sheet_list))) if value == self.sheet_name.strip()]
            sheet = sheet_list[sheet_index[0]]
            if len(sheet.name) == 6:
                try:
                    sheet_date = datetime.datetime.strptime('{}:{}:{}'.format(sheet.name[:2], sheet.name[2:4], sheet.name[4:]),
                                           '%d:%m:%y')
                except Exception as e:
                    _logger.info("Exception occurs while coverting date from str to datetime object:{}".format(e))
                    raise ValidationError("Enter date in format ddmmyy")
            sheet_values = list(filter(lambda x:x[6] != '',sheet._cell_values))
            sheet_header = sheet_values[0]
            sheet_data = sheet_values[1:]
            _logger.info("total lines:{},sheet_data:{}".format(len(sheet_data),sheet_data))
            _logger.info("sheet_header:{}".format(sheet_header))
            policy_no_not_found = []
            for line in sheet_data:
                try:
                    policy_no = str(line[6]).strip()
                    if '.0' in policy_no:
                        policy_no = policy_no[:-2]
                    leads = self.env['crm.lead'].sudo().search(['|','|',('policy_reference','=',policy_no)
                                                                ,('policy_reference_2','=',policy_no)
                                                                ,('policy_reference_3','=',policy_no)])
                    _logger.info("Policy Number:{} => Leads:{}".format(policy_no,leads))
                    # commenthis this bcause now date come from the sheet name of xlsx file
                    # date = datetime.datetime.now()
                    # if type('') == type(line[2]):
                    #     date = parser.parse(line[2])
                    # if type(1.00) == type(line[2]):
                    #     date = datetime.datetime.utcfromtimestamp((line[2] - 25569) * 86400.0)
                    for lead in leads:
                        contract_commission_lines = lead.commission_reconcile_ids.filtered(lambda x:x.receipt_date == sheet_date.date() and
                                                                           x.receipt_reference == policy_no and
                                                                           x.com_amount == round(float(line[18]),2))
                        if contract_commission_lines:
                            _logger.info("Same line found in the record: id:{},name:{},same line found:{} -> sheet_line_data:{}".
                                         format(lead.id,lead.name,contract_commission_lines,line))
                        if not contract_commission_lines:
                            lead.write({'commission_reconcile_ids':[(0,0,{
                                'receipt_date':sheet_date.date(),
                                'receipt_reference':policy_no,
                                'com_amount':round(float(line[18]),2),
                                'user_id':self.env.user.id,
                                'retention':float(line[16]) and round(float(line[16]),2) or 0,
                            })]})
                            _logger.info("Line successfully imported:{}".format(line))
                            self.env.cr.commit()
                    if not leads:
                        policy_no_not_found.append(policy_no)
                except Exception as e:
                    _logger.info("Exception occurs while doing operation in this line:{} and exception:{}".format(line,e))
                    continue
            if policy_no_not_found:
                _logger.info('Policy numbers not found in the system -> policy_no_not_found:{}'.format(policy_no_not_found))
    #           export excel code for the policy numbers which are not found in the system.
                output = io.BytesIO()
                workbook = xlsxwriter.Workbook(output, {'in_memory': True})
                sheet = workbook.add_worksheet("{}".format(self.sheet_name))
                sheet.set_column(0, 0, 40)
                merge_super_col_style = workbook.add_format(
                    {'font_name': 'Arial', 'font_size': 11, 'bold': True, 'align': 'center', 'bg_color': '#FFFF00'})
                sheet.write(0, 0, 'Policy Numbers Not Found',merge_super_col_style)
                row = 1
                for p_number in policy_no_not_found:
                    sheet.write(row, 0, str(p_number), )
                    row += 1
                workbook.close()
                output.seek(0)
                output = base64.encodestring(output.read())
                self.write({'detail_file': output})
                filename = f"policy_numbers_not_found_{self.sheet_name}.xlsx"
                return {
                    'type': 'ir.actions.act_url',
                    'url': 'web/content/?model=import.hype.advice&field=detail_file&download=true&id=%s&filename=%s' % (
                        self.id, filename),
                    'target': 'new',
                    # 'close_on_report_download':True,
                }
