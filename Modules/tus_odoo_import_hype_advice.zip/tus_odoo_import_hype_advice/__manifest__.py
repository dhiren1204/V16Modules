# -*- coding: utf-8 -*-
{
    'name': 'Tus Odoo Import Hype Advice',
    'version': '15.0.0.1',
    'sequence': '10',
    'category': 'Extra Tools',
    'author' : 'Techultra Solutions',
    'maintainer': 'Techultra Solutions',
    'website': 'https://www.techultrasolutions.com',
    'summary': '',
    'images': [],
    'description': """ """,
    'depends': ['crm'],
    'data': [
        'security/ir.model.access.csv',

        'wizard/import_hype_advice_xlsx_views.xml',
    ],
    'installable': True,
    'application': True,
}
