import datetime

from odoo import conf, http, _
from odoo.http import request
from odoo.addons.portal.controllers import portal
from odoo.addons.portal.controllers.portal import pager as portal_pager
from odoo.tools import groupby as groupbyelem
from operator import itemgetter
from odoo.tools import DEFAULT_SERVER_DATE_FORMAT as DF
from datetime import datetime, timedelta


class TusPortalClientAccess(portal.CustomerPortal):



    def _prepare_home_portal_values(self, counters):
        values = super()._prepare_home_portal_values(counters)
        partner = request.env.user.partner_id
        aa = request.env['account.analytic.line']
        values['account_analytic_line_count'] = aa.sudo().search_count([]) \
            if aa.sudo().check_access_rights('read', raise_exception=False) else 0
        return values

    @http.route(['/my/portaluseraccess', '/my/portaluseraccess/page/<int:page>'], type='http', auth="user", website=True)
    def tus_portal_client_access(self, page=1, date_begin=None, date_end=None, sortby=None, filterby=None, search=None,
                                 search_in='all', groupby='none', **kw):
        values = {}
        Project = request.env['account.analytic.line']

        searchbar_sortings = self._prepare_searchbar_sortings()
        if not sortby or sortby not in searchbar_sortings:
            sortby = 'date'
        order = searchbar_sortings[sortby]['order']



        # projects count
        project_count = Project.search_count([])
        # pager
        pager = portal_pager(
            url="/my/portaluseraccess",
            url_args={'date_begin': date_begin},
            total=project_count,
            page=page,
            step=self._items_per_page
        )

        # content according to pager and archive selected
        projects = Project.search(domain=[], order=order, limit=10, offset=pager['offset'])

        values.update({
            'client_access': projects,
            'page_name': 'client_access',
            'default_url': '/my/portaluseraccess',
            'pager': pager,
            'searchbar_sortings': searchbar_sortings,
            'sortby': sortby
        })
        return request.render("tus_portal_client_access.tus_portal_client_access_tmp", values)
