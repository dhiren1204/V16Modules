{
    'name': 'test',
    'version': '',
    'summary': '',
    'description': '',
    'category': '',
    'author': '',
    'website': '',
    'license': '',
    'depends': ["portal","base","web"],
    'data': [
        'views/portal_templates.xml',
    ],

    'assets': {
        'web.assets_frontend': [
            'tus_portal_client_access/static/src/js/*',
        ],
    },

    'installable': True,
    'auto_install': False,
}