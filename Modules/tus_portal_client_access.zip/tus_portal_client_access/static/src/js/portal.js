odoo.define('tus_portal_client_access.clientaccessbuttontus', function (require) {
'use strict';

const publicWidget = require('web.public.widget');

publicWidget.registry.ClientAccessButton = publicWidget.Widget.extend({
    selector: '.testriyasat',
    events: {
    'click button.testriyasat': '_onClickClientAccess',
    },
    _onClickClientAccess: function () {
        debugger
    },
});