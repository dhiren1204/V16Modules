# -*- coding: utf-8 -*-
from odoo import fields, models

class StockPickingTypeInherit(models.Model):
    _inherit = 'stock.picking.type'

    is_ecommerce_platform_operation = fields.Boolean("Is Ecommerce Platform Operation ?", default=False)
