from odoo import models, fields, api

class LensPricelist(models.Model):
    _name = 'lens.pricelist'
    _rec_name = 'brand_id'

    brand_id = fields.Many2one('product.brand',string='Brand',copy=False)
    category_id = fields.Many2one('product.category',string='Category',copy=False)
    lens_pricelist_line_ids = fields.One2many('lens.pricelist.line','lens_pricelist_id',string='Lens Pricelist Lines')


class LensPricelistLine(models.Model):
    _name = 'lens.pricelist.line'

    lens_pricelist_id = fields.Many2one('lens.pricelist',string='Lens Pricelist ID',copy=False)
    material_id = fields.Many2one('product.attribute.value',string='Material',copy=False)
    coating_id = fields.Many2one('product.attribute.value',string='Coating',copy=False)
    coating_color_id = fields.Many2one('product.attribute.value',string='Coating Color',copy=False)
    index_id = fields.Many2one('product.attribute.value',string='Index',copy=False)
    lens_color_id = fields.Many2one('product.attribute.value',string='Lens Color',copy=False)
    power_range_id = fields.Many2one('product.attribute.value',string='Power Range',copy=False)
    diameter_id = fields.Many2one('product.attribute.value',string='Diameter',copy=False)
    price = fields.Float('Price',copy=False)

