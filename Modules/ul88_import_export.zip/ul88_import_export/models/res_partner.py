from odoo import models,fields

class ResPartnerInherit(models.Model):
    _inherit = 'res.partner'

    is_amazon_contact = fields.Boolean("Is Ecommerce Contact", copy=False, default=False)
    is_amazon_b2c_customer = fields.Boolean("Is Ecommerce B2C Customer", copy=False, default=False)
