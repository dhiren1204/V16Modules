# -*- coding: utf-8 -*-
import io
import base64
from datetime import datetime
from odoo import api, fields, models, _
from odoo.tools.misc import xlsxwriter

class AccountMove(models.Model):
    _inherit='account.move'

    detail_file = fields.Binary("File")
    is_amazon_contact = fields.Boolean(related="partner_id.is_amazon_contact" ,string="Is Ecommerce Contact")
    is_amazon_b2c_customer = fields.Boolean(related="partner_id.is_amazon_b2c_customer" ,string="Is Ecommerce B2C Customer")
    amazon_order = fields.Char('Ecommerce Order Id', copy=False)

    def export_invoice_xlsx_report(self):
        """
        generate xlsx report
        :return:
        """
        output = io.BytesIO()
        workbook = xlsxwriter.Workbook(output, {'in_memory': True})
        sheet = workbook.add_worksheet("invoice")
        self.prepare_invoice_xlsx_header(workbook, sheet)
        self.write_invoice_data_in_xlsx_sheet(sheet, workbook)
        workbook.close()
        output.seek(0)
        output = base64.encodestring(output.read())
        self.write({'detail_file': output})
        filename = "ul88_export_{}_{}.xlsx".format('invoice', datetime.now().strftime('%d_%m_%y-%H:%M:%S'))
        return {
            'type': 'ir.actions.act_url',
            'url': 'web/content/?model=account.move&field=detail_file&download=true&id=%s&filename=%s' % (self[0].id, filename),
            'target': 'new',
        }

    def write_invoice_data_in_xlsx_sheet(self, sheet, workbook):
        """
        Write Data in sheet
        :return:
        """
        row = 6
        for rec in self:
            row_data_style = workbook.add_format({'font_name': 'Arial'})
            invoice_date = ''
            if rec.invoice_date:
                invoice_date = str(rec.invoice_date.strftime('%d/%m/%Y'))
            for line in rec.invoice_line_ids:
                sheet.write(row, 0, invoice_date, row_data_style)
                sheet.write(row, 1, rec.name or '/', row_data_style)
                sheet.write(row, 2, rec.partner_id and rec.partner_id.name or '', row_data_style)
                sheet.write(row, 3, line.product_id and line.product_id.default_code or '', row_data_style)
                sheet.write(row, 4, line.product_id and line.product_id.spa_item_code or '', row_data_style)
                sheet.write(row, 5, line.product_id and line.product_id.upc_barcode or '', row_data_style)
                sheet.write(row, 6, line.product_id and line.product_id.l10n_in_hsn_code or '', row_data_style)
                sheet.write(row, 7, line.product_id and line.product_id.display_name or '', row_data_style)
                sheet.write(row, 8, line.quantity, row_data_style)
                sheet.write(row, 9, round(line.price_unit, 2), row_data_style)
                sheet.write(row, 10, line.discount, row_data_style)
                list_of_tax_name = [str(tax_name) for tax_name in set(line.tax_ids.mapped('name'))]
                joined_string = ",".join(list_of_tax_name)

                sheet.write(row, 11, joined_string, row_data_style)
                # tax_amount = price_total-price_subtotal
                sheet.write(row, 12, round(line.price_total - line.price_subtotal, 2), row_data_style)
                sheet.write(row, 13, round(line.price_subtotal, 2), row_data_style)
                sheet.write(row, 14, round(line.price_total, 2), row_data_style)
                color = ''
                box_size = ''
                color_data = line.product_id.product_template_attribute_value_ids.filtered(
                    lambda x: x.attribute_id.is_colour)
                color = color_data.mapped('product_attribute_value_id.name')[0] if len(
                    color_data.mapped('product_attribute_value_id.name')) else ''
                size_data = line.product_id.product_template_attribute_value_ids.filtered(
                    lambda x: x.attribute_id.is_size)
                box_size = size_data.mapped('product_attribute_value_id.name')[0] if len(
                    size_data.mapped('product_attribute_value_id.name')) else ''
                # if len(color_box) == 2:
                #     color = color_box[0]
                #     box_size = color_box[1]
                # if len(color_box) == 1:
                #     temp = line.product_id.product_template_attribute_value_ids.mapped('attribute_id.name')
                #     if temp.find('color') or temp.find('colour'):
                #         color = color_box[0]
                #     else:
                #         box_size = color_box[0]

                # colour_attribute_line = line.product_id.valid_product_template_attribute_line_ids.filtered(
                #     lambda x: x.attribute_id.is_colour)
                # colour_name = [str(colour) for colour in set(colour_attribute_line.value_ids.mapped('name'))]
                # colour_string = ",".join(colour_name)
                #
                # size_attribute_line = line.product_id.valid_product_template_attribute_line_ids.filtered(
                #     lambda x: x.attribute_id.is_size)
                # size_name = [str(size) for size in set(size_attribute_line.value_ids.mapped('name'))]
                # size_string = ",".join(size_name)
                # product_template_attribute_value_ids

                sheet.write(row, 15, line.product_id.style_code or '', row_data_style)
                sheet.write(row, 16, color, row_data_style)
                sheet.write(row, 17, box_size, row_data_style)
                # available_qty = line.product_id.with_context({'location': self.warehouse_id.lot_stock_id.id}).qty_available
                # outgoing_qty = line.product_id.with_context({'location': self.warehouse_id.lot_stock_id.id}).outgoing_qty
                # qty_available = available_qty - outgoing_qty
                # available = 'No'
                # if qty_available > 0:
                #     available = 'Yes'
                # sheet.write(row, 11, available, row_data_style)
                sheet.write(row, 18, line.product_id.lst_price, row_data_style)
                sheet.write(row, 19, line.product_id.mrp_price, row_data_style)
                sheet.write(row, 20, rec.ref or '', row_data_style)
                # sheet.write(row, 19, rec.partner_shipping_id.name or '', row_data_style)
                state = 'Draft'
                if rec.state == 'draft':
                    state = 'Draft'
                elif rec.state == 'posted':
                    state = 'Posted'
                elif rec.state == 'cancel':
                    state = 'Cancel'
                sheet.write(row, 21, state, row_data_style)
                row += 1
            row += 2
        return sheet

    def prepare_invoice_xlsx_header(self, workbook, sheet):
        """
        Prepare XLSX header
        :param workbook:
        :param sheet:
        :return:
        """
        merge_super_col_style = workbook.add_format(
            {'font_name': 'Arial', 'font_size': 11, 'bold': True, 'align': 'center'})

        super_col_style = workbook.add_format(
            {'font_name': 'Arial', 'font_size': 12, 'font_color': '#FFA500', 'bold': True})
        main_header = 'Invoice Details'
        sheet.write(1, 0, 'Export : %s' % main_header, super_col_style)
        headers = ['Date','Number','Partner','UL Code','Spa Item Code','Upc Barcode','HSN','Product','Quantity','Unit Price',
                  'Discount (%)','Taxes','Tax Amount','Subtotal','Grand Total','Style Code','Colour Code','Box Size',
                   'WHP','SRP','Vendor Reference','Status']
        # ,'Delivery Address'
        row = 5
        col = 0
        for header in headers:
            sheet.write(row, col, header, merge_super_col_style)
            col += 1
        return sheet

    @api.constrains('name', 'journal_id', 'state')
    def _check_unique_sequence_number(self):
        self = self.filtered(lambda move: move.state == 'posted' and not move.is_amazon_contact)
        return super(AccountMove, self)._check_unique_sequence_number()

# class AccountMoveLine(models.Model):
#     _inherit = 'account.move.line'
#
#     picking_ids = fields.Many2many('stock.picking',string='Delivery Orders')
#       commented this field because now no longer connection required between the invoice lines and pickings.

