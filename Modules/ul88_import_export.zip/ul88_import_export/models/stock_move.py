# -*- coding: utf-8 -*-
from odoo import models, api
from odoo.osv import expression
import logging
_logger = logging.getLogger('ul88_import_export->stock_move')

class StockMoveInherit(models.Model):
    _inherit = 'stock.move'
    # currently not in use because we are assigning the amazon warehouse in sale order so don't need this
    def _get_new_picking_values(self):
        """
        Super call _get_new_picking_values this method for changing the rule operation type to the
        our operation type which was passed from the amazon selection while uploading sheet
        self._context.get('ecom_operation_type',False) and self._context.get('amazon_import_order',False)
        """
        res = super(StockMoveInherit, self)._get_new_picking_values()
        if res.get('origin',False):
            so = self.env['sale.order'].sudo().search([('name','=',res.get('origin',False))])
            if so and so.is_amazon_order and self._context.get('amazon_import_order',False) and self._context.get('ecom_operation_type',False):
                warehouse = so.warehouse_id
                res.update({
                    'picking_type_id': self._context.get('ecom_operation_type').id,
                    'location_id': self._context.get('ecom_operation_type').default_location_src_id.id,
                    'location_dest_id': self._context.get('ecom_operation_type').default_location_dest_id.id
                })
        return res

    # def _assign_picking_post_process(self, new=False):
    #     res = super(StockMoveInherit, self)._assign_picking_post_process(new=new)
    #     pickings = self.mapped('picking_id').filtered(lambda x:x.state not in ['assigned','done','cancel'] and x.sale_id
    #                                           and x.sale_id.is_amazon_order)
    #     if pickings:
    #         pickings.mapped('move_ids_without_package').write({'location_id':pickings.mapped('location_id')[0],
    #                                                            'location_dest_id':pickings.mapped('location_dest_id')[0]})
    #     return res

class ProcurementGroup(models.Model):
    _inherit = 'procurement.group'

    @api.model
    def _get_rule(self, product_id, location_id, values):
        """
        Super call this method for passing the sale order lines in the context to the next method
        """
        sol = False
        if values.get('sale_line_id',False):
            sol = self.env['sale.order.line'].sudo().browse(values.get('sale_line_id',False))
        return super(ProcurementGroup,self.with_context(sol=sol))._get_rule(product_id,location_id,values)

    @api.model
    def _search_rule(self, route_ids, product_id, warehouse_id, domain):
        """
        Ecommerce sheet update thing
        is_amazon_order and if 3 way delivery system then we will create the route and 1-step rule for that and then based
        on this condition changed the rule.
        """
        res = super(ProcurementGroup,self)._search_rule(route_ids,product_id,warehouse_id,domain)
        if res and self._context.get('sol',False):
            order = self._context.get('sol',False).order_id
            if order and order.is_amazon_order and self._context.get('amazon_import_order') \
                and order.warehouse_id.delivery_steps == 'pick_pack_ship' and self._context.get('ecom_operation_type',False):
                Rule = self.env['stock.rule']
                res = Rule.search(expression.AND([[('route_id', 'in', order.warehouse_id.route_ids.ids)], domain]),
                                  order='route_sequence desc, sequence', limit=1)
        return res
