from odoo import api, models, fields

class ResConfigSettingsInherit(models.TransientModel):
    _inherit = 'res.config.settings'

    amazon_warehouse_id = fields.Many2one('stock.warehouse', string='Amazon FBA Warehouse')

    def set_values(self):
        res = super(ResConfigSettingsInherit, self).set_values()
        self.env['ir.config_parameter'].sudo().set_param('ul88_import_export.amazon_warehouse_id', int(self.amazon_warehouse_id.id))
        return res

    @api.model
    def get_values(self):
        res = super(ResConfigSettingsInherit, self).get_values()
        res.update(amazon_warehouse_id=int(self.env['ir.config_parameter'].sudo().get_param('ul88_import_export.amazon_warehouse_id')))
        return res