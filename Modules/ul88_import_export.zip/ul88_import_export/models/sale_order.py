# -*- coding: utf-8 -*-
import io
import base64
from datetime import datetime
from odoo import api, fields, models, _
from odoo.tools.misc import xlsxwriter
import logging

_logger = logging.getLogger(__name__)

class SaleOrder(models.Model):
    _inherit = 'sale.order'

    detail_file = fields.Binary("File")
    is_backorder_xls_generated = fields.Char(string="Is backorder Generated?", default=False)
    amazon_order = fields.Char('Ecommerce Order Id', copy=False)
    is_amazon_order = fields.Boolean("Is Ecommerce Order", copy=False, default=False)
    def export_order_xlsx_report(self):
        """
        generate xlsx report
        :return:
        """
        output = io.BytesIO()
        workbook = xlsxwriter.Workbook(output, {'in_memory': True})
        sheet = workbook.add_worksheet("sales")
        self.prepare_order_xlsx_header(workbook, sheet)
        self.write_order_data_in_xlsx_sheet(sheet, workbook)
        workbook.close()
        output.seek(0)
        output = base64.encodestring(output.read())
        self.write({'detail_file': output})
        filename = "ul88_export_{}_{}.xlsx".format('sales', datetime.now().strftime('%d_%m_%y-%H:%M:%S'))
        return {
            'type': 'ir.actions.act_url',
            'url': 'web/content/?model=sale.order&field=detail_file&download=true&id=%s&filename=%s' % (self.id, filename),
            'target': 'new',
        }

    def write_order_data_in_xlsx_sheet(self, sheet, workbook):
        """
        Write Data in sheet
        :return:
        """
        row = 6
        row_data_style = workbook.add_format({'font_name': 'Arial'})
        order_invoice_bill_date = ''
        if self.date_order:
            order_invoice_bill_date = str(self.date_order.date())
        for line in self.order_line:
            sheet.write(row, 0, order_invoice_bill_date, row_data_style)
            sheet.write(row, 1, self.name or '/', row_data_style)
            sheet.write(row, 2, self.partner_id and self.partner_id.name or '', row_data_style)
            sheet.write(row, 3, line.product_id and line.product_id.default_code or '', row_data_style)
            sheet.write(row, 4, line.product_id and line.product_id.display_name or '', row_data_style)
            sheet.write(row, 5, round(line.price_unit, 2), row_data_style)
            sheet.write(row, 6, line.product_uom_qty, row_data_style)
            sheet.write(row, 7, line.discount, row_data_style)
            list_of_tax_name = [str(tax_name) for tax_name in set(line.tax_id.mapped('name'))]
            joined_string = ",".join(list_of_tax_name)

            sheet.write(row, 8, joined_string, row_data_style)
            sheet.write(row, 9, round(line.price_subtotal, 2), row_data_style)

            model_string = line.product_id.product_tmpl_id.style_code
            if not model_string:
                model_attribute_line = line.product_id.valid_product_template_attribute_line_ids.filtered(
                    lambda x: x.attribute_id.is_model)
                models_name = [str(model) for model in set(model_attribute_line.value_ids.mapped('name'))]
                model_string = ",".join(models_name)

            colour_string = size_string = colour_description_string = ''
            vendor_colour_string = ''
            colour_attribute_line = line.product_id.product_template_attribute_value_ids.filtered(lambda x: x.attribute_id.is_colour)
            vendor_colour_attribute_line = line.product_id.custom_attribute_line_ids.filtered(lambda x:x.custom_attribute_id and x.custom_attribute_id.is_vendor_color)
            if vendor_colour_attribute_line:
                vendor_colour_string = ','.join(vendor_colour_attribute_line.mapped('value_id.name'))
            if colour_attribute_line:
                colour_string = ','.join(colour_attribute_line.mapped('product_attribute_value_id.name'))
                colour_description_string = ','.join(colour_attribute_line.mapped('product_attribute_value_id.color_details_id.name'))
            if not colour_string:
                colour_attribute_line = line.product_id.valid_product_template_attribute_line_ids.filtered(
                    lambda x: x.attribute_id.is_colour)
                colour_name = [str(colour) for colour in set(colour_attribute_line.value_ids.mapped('name'))]
                colour_string = ",".join(colour_name)

            size_attribute_line = line.product_id.product_template_attribute_value_ids.filtered(lambda x: x.attribute_id.is_size)
            if size_attribute_line:
                size_string = size_attribute_line[0].product_attribute_value_id.name
            if not size_string:
                size_attribute_line = line.product_id.valid_product_template_attribute_line_ids.filtered(
                    lambda x: x.attribute_id.is_size)
                size_name = [str(size) for size in set(size_attribute_line.value_ids.mapped('name'))]
                size_string = ",".join(size_name)

            sheet.write(row, 10, model_string, row_data_style)
            sheet.write(row, 11, colour_string, row_data_style)
            sheet.write(row, 12, colour_description_string, row_data_style)
            sheet.write(row, 13, vendor_colour_string, row_data_style)
            sheet.write(row, 14, size_string, row_data_style)
            available_qty = line.product_id.with_context({'location': self.warehouse_id.lot_stock_id.id}).qty_available
            outgoing_qty = line.product_id.with_context({'location': self.warehouse_id.lot_stock_id.id}).outgoing_qty
            qty_available = available_qty - outgoing_qty
            available = 'No'
            if qty_available > 0:
                available = 'Yes'
            sheet.write(row, 15, available, row_data_style)
            sheet.write(row, 16, line.product_id.mrp_price, row_data_style)
            sheet.write(row, 17, self.client_order_ref or '', row_data_style)
            sheet.write(row, 18, self.partner_shipping_id.name or '', row_data_style)
            state = 'Quotation'
            if self.state == 'sent':
                state = 'Quotation Sent'
            elif self.state == 'sale':
                state = 'Sales Order'
            elif self.state == 'cancel':
                state = 'Cancel'
            elif self.state == 'done':
                state = 'Locked'
            sheet.write(row, 19, state, row_data_style)
            row += 1
        return sheet

    def prepare_order_xlsx_header(self, workbook, sheet):
        """
        Prepare XLSX header
        :param workbook:
        :param sheet:
        :return:
        """
        merge_super_col_style = workbook.add_format({'font_name': 'Arial', 'font_size': 11, 'bold': True, 'align': 'center'})

        super_col_style = workbook.add_format(
            {'font_name': 'Arial', 'font_size': 12, 'font_color': '#FFA500', 'bold': True})
        header = 'Sales Order'
        sheet.write(1, 0, 'Export : %s' % header, super_col_style)
        row = 5
        sheet.write(row, 0, 'Date', merge_super_col_style)
        sheet.write(row, 1, 'Number', merge_super_col_style)
        sheet.write(row, 2, 'Partner', merge_super_col_style)
        sheet.write(row, 3, 'Internal Reference', merge_super_col_style)
        sheet.write(row, 4, 'Product', merge_super_col_style)
        sheet.write(row, 5, 'Unit Price', merge_super_col_style)
        sheet.write(row, 6, 'Quantity', merge_super_col_style)
        sheet.write(row, 7, 'Discount (%)', merge_super_col_style)
        sheet.write(row, 8, 'Taxes', merge_super_col_style)
        sheet.write(row, 9, 'Subtotal', merge_super_col_style)
        sheet.write(row, 10, 'Model', merge_super_col_style)
        sheet.write(row, 11, 'Colour', merge_super_col_style)
        sheet.write(row, 12, 'Colour Description', merge_super_col_style)
        sheet.write(row, 13, 'Vendor Colour', merge_super_col_style)
        sheet.write(row, 14, 'Size', merge_super_col_style)
        sheet.write(row, 15, 'Available', merge_super_col_style)
        sheet.write(row, 16, 'SRP', merge_super_col_style)
        sheet.write(row, 17, 'customer reference', merge_super_col_style)
        sheet.write(row, 18, 'Delivery address', merge_super_col_style)
        sheet.write(row, 19, 'Status', merge_super_col_style)
        return sheet




    def export_backorder_xlsx_report(self):
        """
        generate xlsx report
        :return:
        """
        output = io.BytesIO()
        workbook = xlsxwriter.Workbook(output, {'in_memory': True})
        sheet = workbook.add_worksheet("Products")
        self.prepare_backorder_xlsx_header(workbook, sheet)
        self.write_backorder_data_in_xlsx_sheet(sheet, workbook)
        workbook.close()
        output.seek(0)
        output = base64.encodestring(output.read())
        self.write({'detail_file': output})
        filename = "ul88_export_{}_{}.xlsx".format('back_order_products', datetime.now().strftime('%d_%m_%y-%H:%M:%S'))
        return {
            'type': 'ir.actions.act_url',
            'url': 'web/content/?model=sale.order&field=detail_file&download=true&id=%s&filename=%s' % (self[0].id, filename),
            'target': 'new',
        }
    
    def write_backorder_data_in_xlsx_sheet(self, sheet, workbook):
        """
        Write Data in sheet
        :return:
        """
        # backorder domain = [('backorder_id', '!=', False), ('state', 'in', ('assigned', 'waiting', 'confirmed'))]
        # pickings = self.filtered(lambda x:x.backorder_id and x.state in ['assigned', 'waiting', 'confirmed'])
        row_data_style = workbook.add_format({'font_name': 'Arial'})
        row = 6
        products = {}
        sheet.set_column(0, 0, 50)


        for rec in self:
            for line in rec.order_line:
                qty = line.product_uom_qty - line.qty_delivered
                if line.product_id and qty > 0:
                    product_line = []
                    ul_code = line.product_id.default_code
                    product_line.append(line.product_id.display_name)
                    product_line.append(line.product_id.product_brand_id.name)
                    product_line.append(line.product_id.upc_barcode)
                    product_line.append(line.product_id.spa_item_code)
                    product_line.append(ul_code)
                    product_line.append(qty)
                    product_line.append(line.product_id.lst_price)
                    list_of_tax_name = [str(tax_name) for tax_name in set(line.product_id.supplier_taxes_id.mapped('name'))]
                    joined_string = ",".join(list_of_tax_name)
                    product_line.append(joined_string)
                    line_total = line.product_uom_qty*line.product_id.lst_price
                    product_line.append(line_total)
                    if products.get(ul_code):
                        product_detail = products.get(ul_code)
                        product_detail[5] += qty
                        product_detail[8] += line_total
                        products.update({ul_code:product_detail})
                    else:
                        products.update({ul_code: product_line})
                    rec.is_backorder_xls_generated = True
        if len(products):
            for product in products.values():
                # sheet.write(row, 0, str(datetime.now().date()), row_data_style)
                sheet.write(row, 0, product[0], row_data_style)
                sheet.write(row, 1, product[1], row_data_style)
                sheet.write(row, 2, product[2] or '', row_data_style)
                sheet.write(row, 3, product[3] or '', row_data_style)
                sheet.write(row, 4, product[4], row_data_style)
                sheet.write(row, 5, product[5], row_data_style)
                sheet.write(row, 6, product[6], row_data_style)
                # list_of_tax_name = [str(tax_name) for tax_name in set(product.supplier_taxes_id.mapped('name'))]
                # joined_string = ",".join(list_of_tax_name)
                sheet.write(row, 7, product[7], row_data_style)
                sheet.write(row, 8, product[8], row_data_style)
                row += 1
            row += 1
            sheet.write(row, 8, 'Total', row_data_style)
            sheet.write(row+1, 8, sum([x[-1] for x in products.values()]), row_data_style)
        return sheet

    def prepare_backorder_xlsx_header(self, workbook, sheet):
        """
        Prepare XLSX header
        :param workbook:
        :param sheet:
        :return:
        """
        merge_super_col_style = workbook.add_format(
            {'font_name': 'Arial', 'font_size': 11, 'bold': True, 'align': 'center'})
        super_col_style = workbook.add_format(
            {'font_name': 'Arial', 'font_size': 12, 'font_color': '#FFA500', 'bold': True})
        header = 'Back Orders Product Details'
        sheet.write(1, 0, 'Export : {}'.format(header), super_col_style)
        sheet.write(2, 0, 'Date : {}'.format(str(datetime.now())), super_col_style)
        row = 5
        # sheet.write(row, 0, 'Date', merge_super_col_style)
        sheet.write(row, 0, 'Product Name', merge_super_col_style)
        sheet.write(row, 1, 'Product Brand', merge_super_col_style)
        sheet.write(row, 2, 'Barcode', merge_super_col_style)
        sheet.write(row, 3, 'Spa Item Code', merge_super_col_style)
        sheet.write(row, 4, 'Internal Reference', merge_super_col_style)
        sheet.write(row, 5, 'Demand Qty', merge_super_col_style)
        sheet.write(row, 6, 'Wholesale Price', merge_super_col_style)
        sheet.write(row, 7, 'Taxes', merge_super_col_style)
        sheet.write(row, 8, 'Subtotal', merge_super_col_style)
        return sheet

    #   commented this field because now no longer connection required between the invoice lines and pickings.
    # def _create_invoices(self, grouped=False, final=False):
    #     res = super(SaleOrder, self)._create_invoices(grouped=grouped, final=final)
    #     try:
    #         old_invoices = self.invoice_ids.filtered(lambda x:x.invoice_line_ids.picking_ids)
    #         old_inv_picking = old_invoices.mapped('invoice_line_ids.picking_ids')
    #         new_picking_ids = self.picking_ids.filtered(lambda x:x.state == 'done' and x.picking_type_code == 'outgoing')
    #         final_pickings = new_picking_ids-old_inv_picking
    #         if res.invoice_line_ids.mapped('picking_ids') != final_pickings:
    #             res.invoice_line_ids.write({'picking_ids':[(6,0,final_pickings.ids)]})
    #     except Exception as e:
    #         _logger.info('Exception occured while performin calculation for mis report linking:{}'.format(e))
    #         return res
    #     return res