# -*- coding: utf-8 -*-
import io
import base64
from datetime import datetime, date
from odoo import api, fields, models, _
from odoo.tools.misc import xlsxwriter

class StockPickingInherit(models.Model):
    _inherit = 'stock.picking'

    detail_file = fields.Binary("File")

    def export_backorder_product_xlsx_report(self):
        """
        generate xlsx report
        :return:
        """
        output = io.BytesIO()
        workbook = xlsxwriter.Workbook(output, {'in_memory': True})
        sheet = workbook.add_worksheet("Products")
        self.prepare_backorder_xlsx_header(workbook, sheet)
        self.write_backorder_products_data_in_xlsx_sheet(sheet, workbook)
        workbook.close()
        output.seek(0)
        output = base64.encodestring(output.read())
        self.write({'detail_file': output})
        filename = "ul88_export_{}_{}.xlsx".format('back_order_products', datetime.now().strftime('%d_%m_%y-%H:%M:%S'))
        return {
            'type': 'ir.actions.act_url',
            'url': 'web/content/?model=stock.picking&field=detail_file&download=true&id=%s&filename=%s' % (self[0].id, filename),
            'target': 'new',
        }

    def write_backorder_products_data_in_xlsx_sheet(self, sheet, workbook):
        """
        Write Data in sheet
        :return:
        """
        # backorder domain = [('backorder_id', '!=', False), ('state', 'in', ('assigned', 'waiting', 'confirmed'))]
        # pickings = self.filtered(lambda x:x.backorder_id and x.state in ['assigned', 'waiting', 'confirmed'])
        row_data_style = workbook.add_format({'font_name': 'Arial'})
        row = 6
        products = {}
        sheet.set_column(0, 0, 50)

        for rec in self:
            for line in rec.move_ids_without_package:
                if line.product_id:
                    product_line = []
                    ul_code = line.product_id.default_code
                    product_line.append(line.product_id.display_name)
                    product_line.append(line.product_id.upc_barcode)
                    product_line.append(line.product_id.spa_item_code)
                    product_line.append(ul_code)
                    product_line.append(line.product_uom_qty)
                    product_line.append(line.product_id.lst_price)
                    list_of_tax_name = [str(tax_name) for tax_name in set(line.product_id.supplier_taxes_id.mapped('name'))]
                    joined_string = ",".join(list_of_tax_name)
                    product_line.append(joined_string)
                    line_total = line.product_uom_qty*line.product_id.lst_price
                    product_line.append(rec.date_so_order.strftime("%m/%d/%Y, %H:%M:%S"))
                    rec.is_xls_generated = True
                    product_line.append(line_total)
                    if products.get(ul_code):
                        product_detail = products.get(ul_code)
                        product_detail[4] += line.product_uom_qty
                        product_detail[7] += line_total
                        products.update({ul_code:product_detail})
                    else:
                        products.update({ul_code: product_line})
        if len(products):
            for product in products.values():
                # sheet.write(row, 0, str(datetime.now().date()), row_data_style)
                sheet.write(row, 0, product[0], row_data_style)
                sheet.write(row, 1, product[1] or '', row_data_style)
                sheet.write(row, 2, product[2] or '', row_data_style)
                sheet.write(row, 3, product[3], row_data_style)
                sheet.write(row, 4, product[4], row_data_style)
                sheet.write(row, 5, product[5], row_data_style)
                # list_of_tax_name = [str(tax_name) for tax_name in set(product.supplier_taxes_id.mapped('name'))]
                # joined_string = ",".join(list_of_tax_name)
                sheet.write(row, 6, product[6], row_data_style)
                sheet.write(row, 7, product[7], row_data_style)
                sheet.write(row, 8, product[8], row_data_style)
                row += 1
            row += 1
            sheet.write(row, 8, 'Total', row_data_style)
            sheet.write(row+1, 8, sum([x[-1] for x in products.values()]), row_data_style)
        return sheet


    def prepare_backorder_xlsx_header(self, workbook, sheet):
        """
        Prepare XLSX header
        :param workbook:
        :param sheet:
        :return:
        """
        merge_super_col_style = workbook.add_format(
            {'font_name': 'Arial', 'font_size': 11, 'bold': True, 'align': 'center'})
        super_col_style = workbook.add_format(
            {'font_name': 'Arial', 'font_size': 12, 'font_color': '#FFA500', 'bold': True})
        header = 'Back Orders Product Details'
        sheet.write(1, 0, 'Export : {}'.format(header), super_col_style)
        sheet.write(2, 0, 'Date : {}'.format(str(datetime.now())), super_col_style)
        row = 5
        # sheet.write(row, 0, 'Date', merge_super_col_style)
        sheet.write(row, 0, 'Product Name', merge_super_col_style)
        sheet.write(row, 1, 'Barcode', merge_super_col_style)
        sheet.write(row, 2, 'Spa Item Code', merge_super_col_style)
        sheet.write(row, 3, 'Internal Reference', merge_super_col_style)
        sheet.write(row, 4, 'Demand Qty', merge_super_col_style)
        sheet.write(row, 5, 'Wholesale Price', merge_super_col_style)
        sheet.write(row, 6, 'Taxes', merge_super_col_style)
        sheet.write(row, 7, 'Source Document Date', merge_super_col_style)
        sheet.write(row, 8, 'Subtotal', merge_super_col_style)
        return sheet
