# -*- coding: utf-8 -*-
from odoo import models, fields, api, _


class ProductTemplate(models.Model):
    _inherit = 'product.attribute'

    is_model = fields.Boolean(string='Is Model?')
    is_colour = fields.Boolean(string='Is Colour?')
    is_size = fields.Boolean(string='Is Size?')
    is_vendor_color = fields.Boolean(string='Is Vendor Color Attribute?')
