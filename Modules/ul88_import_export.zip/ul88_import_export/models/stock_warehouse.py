from odoo import models, fields

class StockWarehouseInherit(models.Model):
    _inherit = 'stock.warehouse'

    is_amazon_order_out_type_id = fields.Many2one('stock.picking.type', string='Ecommerce OUT Type')