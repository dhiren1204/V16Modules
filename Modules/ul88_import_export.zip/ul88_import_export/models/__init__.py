# -*- coding: utf-8 -*-
from . import product_attribute
from . import sale_order
from . import accout_move
from . import stock_picking
from . import res_config_settings
from . import stock_warehouse
from . import res_partner
from . import lens_pricelist
from . import stock_move
from . import stock_picking_type
