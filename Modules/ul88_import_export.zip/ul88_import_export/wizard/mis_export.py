import io
import base64
import re
from xlrd import open_workbook
from datetime import datetime
from odoo import api, fields, models, _
from odoo.tools.misc import xlsxwriter

TAG_RE = re.compile(r'<[^>]+>')

class MisExport(models.TransientModel):
    _name = "mis.export"

    from_date = fields.Date(string='From')
    to_date = fields.Date(string='To')
    # invoice_ids = fields.Many2many('account.move', string='Invoices')
    sale_order_ids = fields.Many2many('sale.order',string='Sale Orders')
    branch_id = fields.Many2one('res.company.branch',string="Branch")
    detail_file = fields.Binary("File")

    @api.onchange('branch_id','from_date','to_date')
    def get_records_based_on_branch(self):
        for rec in self:
            # sale order part
            if rec.from_date and rec.to_date and not rec.branch_id:
                sale_order_ids=self.env['sale.order'].search([('date_order', '>=', rec.from_date),('date_order', '<=', rec.to_date)])
                return {'domain': {'sale_order_ids': [('id', 'in', sale_order_ids.ids)]}}
            elif rec.from_date and rec.to_date and rec.branch_id:
                sale_order_ids = self.env['sale.order'].search(
                    [('date_order', '>=', rec.from_date),('date_order', '<=', rec.to_date),
                     ('company_branch_id', '=', rec.branch_id.id)])
                return {'domain': {'sale_order_ids': [('id', 'in', sale_order_ids.ids)]}}
            elif rec.branch_id:
                sale_order_ids = self.env['sale.order'].search([('company_branch_id', '=', rec.branch_id.id)])
                return {'domain': {'sale_order_ids': [('id', 'in', sale_order_ids.ids)]}}

            # invoice part commented
            # if rec.from_date and rec.to_date and not rec.branch_id:
            #     invoice_ids=self.env['account.move'].search([('type','=','out_invoice'),('invoice_date', '>=', rec.from_date),('invoice_date', '<=', rec.to_date)])
            #     return {'domain': {'invoice_ids': [('id', 'in', invoice_ids.ids)]}}
            # elif rec.from_date and rec.to_date and rec.branch_id:
            #     invoice_ids = self.env['account.move'].search(
            #         [('type','=','out_invoice'),('invoice_date', '>=', rec.from_date), ('invoice_date', '<=', rec.to_date),
            #          ('company_branch_id', '=', rec.branch_id.id)])
            #     return {'domain': {'invoice_ids': [('id', 'in', invoice_ids.ids)]}}
            # elif rec.branch_id:
            #     invoice_ids = self.env['account.move'].search([('type','=','out_invoice'),('company_branch_id', '=', rec.branch_id.id)])
            #     return {'domain': {'invoice_ids': [('id', 'in', invoice_ids.ids)]}}

    def mis_export_order_invoice_bill_xlsx_report(self):
        if self.from_date and self.to_date and self.from_date > self.to_date:
            raise Warning(_("To date must be greater then from date"))
        output = io.BytesIO()
        workbook = xlsxwriter.Workbook(output, {'in_memory': True})
        if self.from_date and self.to_date and not self.branch_id and not self.sale_order_ids:
            sale_order_ids = self.env['sale.order'].search([('date_order', '>=', self.from_date),('date_order', '<=', self.to_date)])
        elif self.from_date and self.to_date and self.branch_id and not self.sale_order_ids:
            sale_order_ids = self.env['sale.order'].search(
                [('date_order', '>=', self.from_date), ('date_order', '<=', self.to_date),
                 ('company_branch_id', '=', self.branch_id.id)])
        elif not self.from_date and not self.to_date and self.branch_id and not self.sale_order_ids:
            sale_order_ids = self.env['sale.order'].search([('company_branch_id', '=', self.branch_id.id)])
        elif self.sale_order_ids:
            sale_order_ids = self.sale_order_ids
        else:
            sale_order_ids = self.env['sale.order'].search([('date_order', '>=', self.from_date),('date_order', '<=', self.to_date),('company_branch_id', '=', self.branch_id.id)])
        sheet = workbook.add_worksheet('MIS Report')
        self.prepare_order_invoice_xlsx_header(workbook, sheet)
        self.write_data_in_xlsx_sheet(sale_order_ids, sheet, workbook)
        workbook.close()
        output.seek(0)
        output = base64.encodestring(output.read())
        self.write({'detail_file': output})
        filename = f"mis_export_invoice_{datetime.now().strftime('%d_%m_%y')}.xlsx"
        return {
            'type': 'ir.actions.act_url',
            'url': 'web/content/?model=mis.export&field=detail_file&download=true&id=%s&filename=%s' % (
                self.id, filename),
            'target': 'new',
        }

    def prepare_order_invoice_xlsx_header(self,workbook, sheet):
        merge_super_col_style = workbook.add_format(
            {'font_name': 'Arial', 'font_size': 11, 'bold': True, 'align': 'center','bg_color': '#FFFF00'})
        # headers = ['Sr.NO','INVOICE NO','INVOICE DATE','Invoice Amount (excl. tax)','Invoice Amount','WMS Order no', 'Party Name','Destination','Pincode','Channel','Total Cartons','Total Qty','Status','Packing Completion Date','Dispatch Date','Transport','LR No','Proof of Dispatch Uploaded','Remark','Reason','Days']
        headers = ['Sr.NO','SO Date','SO Number', 'Party Name','Destination','Total Qty','Total Cartons','Dispatch Date','Logistic Partner','LR No','Status','Remark']
        # col_width = [0,20, 15, 0, 0, 0, 40, 15, 0, 0, 0, 0, 0, 15, 15, 20, 20, 0, 0,0,0]
        col_width = [0,0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,0,0]
        row = 0
        col = 0
        for header in headers:
            sheet.set_column(col, col, col_width[col])
            sheet.write(row, col, header, merge_super_col_style)
            col+=1
        return sheet

    def write_data_in_xlsx_sheet(self,sale_order_ids, sheet, workbook):
        row_left_style = workbook.add_format({'font_name': 'Arial', 'font_size': 11, 'align': 'left'})
        row=1
        for rec in sale_order_ids:
            sheet.write(row, 0, row, row_left_style)
            sheet.write(row, 1, rec.date_order.strftime('%d/%m/%Y') if rec.date_order else '', row_left_style)
            sheet.write(row, 2, rec.name, row_left_style)
            sheet.write(row, 3, rec.partner_id.name , row_left_style)
            sheet.write(row, 4, rec.partner_id.state_id.name if rec.partner_id.state_id else '' , row_left_style)
            sheet.write(row, 5, sum(rec.order_line.filtered(lambda x:x.product_id).mapped('product_uom_qty')), row_left_style)
            sheet.write(row, 6, '', row_left_style)
            sheet.write(row, 7, ','.join([x.strftime('%d/%m/%Y') for x in rec.picking_ids.filtered(lambda x:x.state == 'done' and x.picking_type_code == 'outgoing').mapped('scheduled_date')]), row_left_style)
            # not mentioned how to take cartoon count and how we will manage in odoo -> that's why blank passed
            sheet.write(row, 8, ','.join([str(x) for x in rec.picking_ids.filtered(lambda x:x.state == 'done' and x.picking_type_code == 'outgoing').mapped('carrier_id.name')]), row_left_style)
            sheet.write(row, 9, ','.join([str(x) for x in rec.picking_ids.filtered(lambda x:x.state == 'done' and x.picking_type_code == 'outgoing').mapped('carrier_tracking_ref') if x]) , row_left_style)
            # status and remark
            picking_state_dict = dict(rec.picking_ids._fields['state'].selection)
            sheet.write(row, 10, ','.join([str(picking_state_dict.get(x)) for x in rec.picking_ids.filtered(lambda x:x.state == 'done' and x.picking_type_code == 'outgoing').mapped('state')]),
                        row_left_style)
            sheet.write(row, 11, ','.join([TAG_RE.sub('', x.body) for x in rec.picking_ids.filtered(lambda x:x.state == 'done' and x.picking_type_code == 'outgoing').message_ids if TAG_RE.sub('', x.body).lower().find('remark') >= 0]), row_left_style)
            # commmenting this unused code because now its shifeted to sale order
            # taken static text as mentioned in the given format -> 'OFFLINE'
            # sheet.write(row, 10, '', row_left_style)
            #
            # pickings = rec.invoice_line_ids.mapped('picking_ids')
            # sheet.write(row, 11, sum(rec.invoice_line_ids.filtered(lambda x:x.product_id).mapped('quantity')), row_left_style)
            # picking_state_dict = dict(pickings._fields['state'].selection)
            # sheet.write(row, 12, ','.join([str(picking_state_dict.get(x)) for x in pickings.mapped('state')]), row_left_style)
            # sheet.write(row, 13,','.join([x.strftime('%d/%m/%Y') for x in pickings.mapped('scheduled_date')]), row_left_style)
            # sheet.write(row, 14,','.join([x.strftime('%d/%m/%Y') for x in pickings.mapped('date_done')]), row_left_style)
            # sheet.write(row, 15,','.join([str(x) for x in pickings.mapped('carrier_id.name')]), row_left_style)
            # sheet.write(row, 16,','.join([str(x) for x in pickings.mapped('carrier_tracking_ref') if x ]), row_left_style)
            # # Proof of Dispatch Uploaded,Remark,Reason,Days -> not clear so passing blank
            # # pickings._name,
            # # [x for x in pickings.message_ids if TAG_RE.sub('', x.body).lower() == 'proof of dispatch' and x.attachment_ids]
            # sheet.write(row, 17, [x for x in pickings.message_ids if TAG_RE.sub('', x.body).lower() == 'proof of dispatch'and x.attachment_ids] and 'yes' or 'no', row_left_style)
            # sheet.write(row, 18, ','.join([TAG_RE.sub('', x.body) for x in pickings.message_ids if TAG_RE.sub('', x.body).lower().find('remark') >= 0]), row_left_style)
            # sheet.write(row, 19, ','.join([TAG_RE.sub('', x.body) for x in pickings.message_ids if TAG_RE.sub('', x.body).lower().find('reason') >= 0]), row_left_style)
            # sheet.write(row, 20, ','.join([TAG_RE.sub('', x.body) for x in pickings.message_ids if TAG_RE.sub('', x.body).lower().find('days') >= 0]), row_left_style)
            row+=1
        return sheet
