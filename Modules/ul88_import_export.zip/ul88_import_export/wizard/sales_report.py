# -*- coding: utf-8 -*-
import io
import base64
import logging
from xlrd import open_workbook
from datetime import datetime
from odoo import api, fields, models, _
from odoo.tools.misc import xlsxwriter

_logger = logging.getLogger("Sales Report")


class Ul88ImportExport(models.TransientModel):
    _name = "sales.report"

    # file_data = fields.Binary(string='Select File')
    # file_name = fields.Char(string='File Name')

    from_date = fields.Date(string='From', help="Date From")
    to_date = fields.Date(string='To', help="Date To")
    detail_file = fields.Binary("File")
    brand_id = fields.Many2one(comodel_name='product.brand', string='Brand')
    category_id = fields.Many2one('product.category', string='Product Category')
    type = fields.Selection([('10', 'Top 10'),
                             ('100', 'Top 100'),
                             ('200', 'Top 200'),
                             ('300', 'Top 300'),
                             ('500', 'Top 500'),
                             ('750', 'Top 750'),
                             ('1000', 'Top 1000'),
                             ('1500', 'Top 1500'),
                             ('2000', 'Top 2000'),
                             ('2500', 'Top 2500'),
                             ('3000', 'Top 3000'),
                             ('4000', 'Top 4000'),
                             ('5000', 'Top 5000'),
                             ('all', 'ALL'),], default='10',required=True, index=True)
    report_id = fields.Many2one(comodel_name="ir.actions.report",
                                domain="[('report_name','in',['ul88_import_product.template_product_data_design_one_limited_variants',])]",
                                string="Select Catalogue", required=False, )

    # brand_group_id = fields.Many2one('brand.group', string='Brand Group')

    def calculate_sales_report(self):
        if self.from_date and self.to_date and self.from_date > self.to_date:
            raise Warning(_("To date must be greater then from date"))

        output = io.BytesIO()
        workbook = xlsxwriter.Workbook(output, {'in_memory': True})
        # condition for the partner
        records = False
        sheet = workbook.add_worksheet("%s" % self.type)
        self.prepare_xlsx_header_for_sales_report(workbook, sheet)
        dict_result = self.prepare_query_and_return_result()
        self.write_data_in_xlsx_sheet_for_sales_report(dict_result, sheet, workbook)
        workbook.close()
        output.seek(0)
        output = base64.encodestring(output.read())
        self.write({'detail_file': output})
        filename = "sales_report_{}_{}.xlsx".format(self.type, datetime.now().strftime('%d_%m_%y-%H:%M:%S'))
        return {
            'type': 'ir.actions.act_url',
            'url': 'web/content/?model=sales.report&field=detail_file&download=true&id=%s&filename=%s' % (
                self.id, filename),
            'target': 'new',
        }

    def top_selling_generate_catalogue_pdf_report(self):
        if self.from_date and self.to_date and self.from_date > self.to_date:
            raise Warning(_("To date must be greater then from date"))
        dict_result = self.prepare_query_and_return_result()
        products = [data.get('product_id') for data in dict_result if data.get('product_id',False)]
        # numbering the products
        count = 1
        for subseq in dict_result:
            subseq.setdefault('number', count)
            count += 1
        products_as_per_seq = {}
        [products_as_per_seq.update({i.get('product_id'):i.get('number')}) for i in dict_result]
        # template wise dict preparing
        tmpl_dict = {}
        for i in dict_result:
            if i.get('product_template_id',False) and i.get('product_id',False):
                pt_id = i.get('product_template_id',False)
                if tmpl_dict.get(pt_id,False):
                    ls = tmpl_dict.get(pt_id, False)
                    ls.append(int(i.get('product_id',False)))
                    tmpl_dict.update({pt_id:ls})
                if not tmpl_dict.get(pt_id,False):
                    tmpl_dict.update({i.get('product_template_id', False): [i.get('product_id', False)]})
        # 5 limit variants binding in the template

        if products:
            products = self.env['product.product'].sudo().browse(products).mapped('product_tmpl_id').ids
        data = {'products':products,'top_selling':True,'products_as_per_seq':products_as_per_seq,'tmpl_dict':tmpl_dict}
        if self.report_id:
            xml_id = self.report_id.xml_id
        report_action = self.env.ref(xml_id).with_context({'for_url': True}).report_action(None, data=data)
        return report_action


    def prepare_xlsx_header_for_sales_report(self, workbook, sheet):
        """
        Prepare XLSX header
        :param workbook:
        :param sheet:
        :return:
        """
        merge_super_col_style = workbook.add_format({'font_name': 'Arial', 'font_size': 11, 'bold': True, 'align': 'center'})

        super_col_style = workbook.add_format(
            {'font_name': 'Arial', 'font_size': 12, 'font_color': '#FFA500', 'bold': True})

        header = 'Sales Report'
        date_from = str(self.from_date.strftime("%Y-%m-%d"))
        date_to = str(self.to_date.strftime("%Y-%m-%d"))
        dict_type = dict(self._fields['type'].selection)
        sheet.write(1, 0, '%s-%s' % (header,dict_type[self.type]), super_col_style)
        sheet.write(2, 0, 'From : %s' % date_from, super_col_style)
        sheet.write(3, 0, 'To : %s' % date_to, super_col_style)

        row = 5
        col = 0
        header_lst = ['UL Code','HSN/SAC Code','Sales Price','MRP','Name','Product Detail Description',
                      'Style Code','Material','Gender','Model No','Display Color','Lens Color','DBL',
                      'TEMPLE LENGTH (MM)','Box SIZE (MM)','EYE SHAPE DESCRIPTION',
                      'PRODUCT TYPE DESCRIPTION','Date of first release','Stock In Hand',
                      'Total Delivered Quantity','Total Ordered Quantity',]
        for header_value in header_lst:
            sheet.write(row, col, str(header_value).upper(), merge_super_col_style)
            col += 1

        # sheet.write(row, 0, 'UL Code', merge_super_col_style)
        # sheet.write(row, 1, 'Product Name', merge_super_col_style)
        # sheet.write(row, 2, 'Brand', merge_super_col_style)
        # sheet.write(row, 3, 'Brand Group', merge_super_col_style)
        # sheet.write(row, 4, 'Category', merge_super_col_style)
        # sheet.write(row, 5, 'Total Delivered Quantity', merge_super_col_style)
        # sheet.write(row, 6, 'Total Ordered Quantity', merge_super_col_style)
        # sheet.write(row, 7, 'Price Total (Incl. Taxes)', merge_super_col_style)
        # sheet.write(row, 8, 'Price Total (Excl. Taxes)', merge_super_col_style)
        return sheet

    def write_data_in_xlsx_sheet_for_sales_report(self,dict_result, sheet, workbook):
        row = 6
        row_data_style = workbook.add_format({'font_name': 'Arial'})
        row_total_style = workbook.add_format({'font_name': 'Arial', 'font_size': 11, 'bold': True, 'align': 'center'})
        warehouse_id = self.env['ir.config_parameter'].sudo().get_param('ul88_3pl_integration.website_warehouse_id')
        warehouse_id = self.env['stock.warehouse'].sudo().browse(int(warehouse_id))
        for result in dict_result:
            product = self.env['product.product'].sudo().search([('id','=',int(result['product_id'])),('active','in',[True,False])])
            if product:
                sheet.write(row, 0, product.default_code, row_data_style)
                sheet.write(row, 1, product.l10n_in_hsn_code, row_data_style)
                sheet.write(row, 2, product.lst_price, row_data_style)
                sheet.write(row, 3, product.mrp_price, row_data_style)
                sheet.write(row, 4, product.display_name, row_data_style)
                sheet.write(row, 5, product.product_details_description and product.product_details_description or '', row_data_style)
                sheet.write(row, 6, product.style_code, row_data_style)
                material_line = product.custom_attribute_line_ids.filtered(
                    lambda x: 'material' in str(x.custom_attribute_id.name).lower())
                if material_line:
                    sheet.write(row, 7, ','.join([line.value_id.name for line in material_line if line.value_id]),
                                row_data_style)
                gender_line = product.custom_attribute_line_ids.filtered(lambda x:'gender' in str(x.custom_attribute_id.name).lower())
                if gender_line:
                    sheet.write(row, 8, ','.join([line.value_id.name for line in gender_line if line.value_id]), row_data_style)
                sheet.write(row, 9, product.style_code, row_data_style)
                display_color_line = product.custom_attribute_line_ids.filtered(
                    lambda x: 'display color' in str(x.custom_attribute_id.name).lower())
                if display_color_line:
                    sheet.write(row, 10, ','.join([line.value_id.name for line in display_color_line if line.value_id]),
                                row_data_style)
                lens_color_line = product.custom_attribute_line_ids.filtered(
                    lambda x: 'lens color' in str(x.custom_attribute_id.name).lower())
                if lens_color_line:
                    sheet.write(row, 11, ','.join([line.value_id.name for line in lens_color_line if line.value_id]),
                                row_data_style)
                dbl_line = product.custom_attribute_line_ids.filtered(
                    lambda x: 'dbl' in str(x.custom_attribute_id.name).lower())
                if dbl_line:
                    sheet.write(row, 12, ','.join([line.value_id.name for line in dbl_line if line.value_id]),
                                row_data_style)
                temple_length_line = product.custom_attribute_line_ids.filtered(
                    lambda x: 'temple length' in str(x.custom_attribute_id.name).lower())
                if temple_length_line:
                    sheet.write(row, 13, ','.join([line.value_id.name for line in temple_length_line if line.value_id]),
                                row_data_style)

                box_size_line = product.product_template_attribute_value_ids.filtered(
                    lambda x: x.attribute_id.is_size)
                if box_size_line:
                    sheet.write(row, 14, ','.join([line.product_attribute_value_id.name for line in box_size_line if line.product_attribute_value_id]),
                                row_data_style)
                eye_shape_line = product.custom_attribute_line_ids.filtered(
                    lambda x: 'eye shape' in str(x.custom_attribute_id.name).lower())
                if eye_shape_line:
                    sheet.write(row, 15, ','.join([line.value_id.name for line in eye_shape_line if line.value_id]),
                                row_data_style)
                product_type_line = product.custom_attribute_line_ids.filtered(
                    lambda x: 'product type' in str(x.custom_attribute_id.name).lower())
                if product_type_line:
                    sheet.write(row, 16, ','.join([line.value_id.name for line in product_type_line if line.value_id]),
                                row_data_style)
                # date of first release like this we dont have any specific data to extract from system
                sheet.write(row, 17, '', row_data_style)
                sheet.write(row, 18, self.env['stock.quant']._get_available_quantity(product, warehouse_id.lot_stock_id), row_data_style)
                sheet.write(row, 19, result['quantity_delivered'], row_data_style)
                sheet.write(row, 20, result['quantity_ordered'], row_data_style)

                # sheet.write(row, 0, product.default_code, row_data_style)
                # sheet.write(row, 1, product.display_name, row_data_style)
                # sheet.write(row, 2, product.product_brand_id and product.product_brand_id.name or '', row_data_style)
                # sheet.write(row, 3, product.brand_group_id and product.brand_group_id.name or '', row_data_style)
                # sheet.write(row, 4, product.categ_id and product.categ_id.name or '', row_data_style)
                # sheet.write(row, 5, result['quantity_delivered'], row_data_style)
                # sheet.write(row, 6, result['quantity_ordered'], row_data_style)
                # sheet.write(row, 7, result['price_total'], row_data_style)
                # sheet.write(row, 8, result['price_subtotal'], row_data_style)
                row += 1
        return sheet


    def prepare_query_and_return_result(self,):
        """
        Write Data in sheet
        :return:
        """
        where_clause,limit = self.prepare_where_clause_for_filteration()
        query = """
                    select
                        sol.product_id as product_id,
                        pp.product_tmpl_id as product_template_id,
                        sum(sol.qty_delivered) as quantity_delivered,
                        sum(sol.product_uom_qty) as quantity_ordered,
                        sum(sol.price_total) as price_total,
                        sum(sol.price_subtotal) as price_subtotal
                    from sale_order_line as sol 
                    inner join sale_order as so on sol.order_id=so.id 
                    left join product_product as pp on sol.product_id=pp.id
                    left join product_template as pt on pp.product_tmpl_id=pt.id
                    left join product_category as pc on pt.categ_id=pc.id
                    left join product_brand as pb on pt.product_brand_id=pb.id
                    where %s 
                    group by product_id,product_template_id
                    order by quantity_delivered desc %s
                    ;
                """ %(where_clause,limit)
        _logger.info("==== Query ===\n",query)
        self.env.cr.execute(query)
        result = self.env.cr.dictfetchall()
        _logger.info('--------- result --------len:{}'.format(len(result)))
        return result

    def prepare_where_clause_for_filteration(self):
        # where
        # so.state = 'done' or so.state = 'sale' and sol.product_id is not NULL and so.company_id = 3
        # and so.date_order::date
        # between
        # '2020-02-21' and '2023-02-21'
        where_clause = "so.state in ('done','sale') and sol.product_id is not NULL and so.company_id = 3"
        limit = ""
        if self.category_id:
            where_clause = "{} and pc.id={}".format(where_clause,self.category_id.id)
        if self.brand_id:
            where_clause = "{} and pb.id={}".format(where_clause,self.brand_id.id)
        if self.from_date and self.to_date:
            where_clause = "{} and (so.date_order::date between '{}' and '{}')".format(where_clause,self.from_date.strftime("%Y-%m-%d"),self.to_date.strftime("%Y-%m-%d"))
        if self.type and self.type!='all':
            limit = " limit {}".format(self.type)
        return where_clause,limit
