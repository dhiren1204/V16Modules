from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError
import logging
import xlrd
import base64
from io import BytesIO

_logger = logging.getLogger("Import Lens Template")

class ImportLensTemplate(models.TransientModel):
    _name = 'import.lens.template'

    xls_file = fields.Binary(attachment=True, string='XLS File')
    filename = fields.Char(string='Filename')

    def read_xlx_file(self):
        file_data = self.xls_file
        if not file_data:
            raise UserError(_('Error!', "Please Select a File"))
        else:
            val = base64.decodestring(file_data)
            tempfile = BytesIO()
            tempfile.write(val)
            work_book = xlrd.open_workbook(file_contents=tempfile.getvalue())
        return work_book


    def import_lens_template_and_update_variants(self):
        work_book = self.read_xlx_file()
        for sheet in work_book._sheet_list:
            if work_book._sheet_list.index(sheet) != 0:
                continue
            sheet_values = sheet._cell_values
            if len(sheet_values):
                sheet_headers = sheet_values[0]
                sheet_headers_str = list(map(lambda x: x.lower(), sheet_headers))
                cell_values = list(filter(lambda x:x, sheet_values[1:]))
                for attr_header in range(7,len(sheet_headers)):
                    attr = self.env['product.attribute'].sudo().search([('name', '=', str(sheet_headers[attr_header]).strip().upper())])
                    if not attr:
                        raise ValidationError(
                            "This attribute not found in the system:{}".format(str(sheet_headers[attr_header]).strip().upper()))
                for value in cell_values:
                    brand = self.env['product.brand'].sudo().search([('brand_code', '=', value[5].strip())],
                                                                    limit=1)
                    category = self.env['product.category'].sudo().search([('name', '=', value[6].strip())],
                                                                          limit=1)
                    website_category = self.env['product.public.category'].sudo().search([('name','=',value[6].strip())],
                                                                                         limit=1)
                    uom_id = self.env['uom.uom'].sudo().search([('name','=',str(value[4]).strip())],limit=1)
                    if brand and category:
                        product = self.env['product.template'].sudo().search([('categ_id', '=', category.id),
                                                                              ('product_brand_id', '=', brand.id)],limit=1)
                        if not product:
                            customer_tax = self.env['account.tax'].sudo().search([
                                ('name','=',str(value[3]).strip().upper()),('type_tax_use','=','sale')],limit=1)
                            vendor_tax = self.env['account.tax'].sudo().search([
                                ('name', '=', str(value[3]).strip().upper()), ('type_tax_use', '=', 'purchase')],limit=1)
                            if not (customer_tax and vendor_tax and uom_id and website_category):
                                _logger.info("Skipping this row because tax or uom or category not found.:{}".format(value))
                                continue
                            product_vals = {
                                'name':value[0].strip(),
                                'categ_id':category.id,
                                'product_brand_id':brand.id,
                                'list_price':value[1],
                                'tracking':'none',
                                'type': 'product',
                                'public_categ_ids':[(6,0,website_category.ids)] if website_category else False,
                                'purchase_line_warn': 'no-message',
                                'sale_line_warn': 'no-message',
                                'uom_id': uom_id.id,
                                'uom_po_id': uom_id.id,
                                'taxes_id': [(6,0,customer_tax.ids)],
                                'supplier_taxes_id': [(6,0,vendor_tax.ids)],
                            }
                            if product_vals:
                                product = self.env['product.template'].sudo().create(product_vals)
                        if product:
                            # check attribute line exist or not -> create new line
                            # check attribute value in line -> create new value or add new value in value_ids
                            # check for variant exist or not -> create new variant for that combinations.
                            # start checking the attribute line from [5:]
                            combination_lst = []
                            for col_index in range(7,len(sheet_headers_str)):
                                attr = self.env['product.attribute'].sudo().search([('name','=',sheet_headers[col_index].strip().upper())])
                                if not attr:
                                    _logger.info("Attribute not found:{}".format(sheet_headers[col_index].strip().upper()))
                                if attr:
                #                     checking for attribute line in product
                                    attribute_line = product.attribute_line_ids.filtered(lambda x:x.attribute_id.id == attr.id)
                                    if not attribute_line:
                                        _logger.info("Attribute line not found in the product->{}:{}".format(product.id,attr.name))
                                        if not value[col_index]:
                                            value[col_index] = 'NULL'
                                        if value[col_index]:
                                            for attr_v in ('NULL',value[col_index]):
                                                attribute_line = product.attribute_line_ids.filtered(
                                                    lambda x: x.attribute_id.id == attr.id)
                                                attr_value = self.env['product.attribute.value'].sudo().search([
                                                    ('name','=',str(attr_v).strip()),
                                                    ('attribute_id','=',attr.id)
                                                ])
                                                if not attr_value:
                                                #     create attr_value in that attribute
                                                    _logger.info("Attribute value not found creating new value:{} in that attribute:{}".format(str(attr_v).strip(),attr.name))
                                                    attr_value = self.env['product.attribute.value'].sudo().create({'name':str(attr_v).strip(),
                                                                                                                    'attribute_id':attr.id})
                                                if attr_value:
                                        #             create attribute line in product
                                                    if not attribute_line:
                                                        product.attribute_line_ids = [(0,0,{'attribute_id':attr.id,'value_ids':[(6,0,[attr_value.id])]})]
                                                        _logger.info("Attribute line created in product")
                                                    if attribute_line:
                                                        attribute_line.write({'value_ids': [(4, attr_value.id)]})
                                                    self.env.cr.commit()
                                                    attribute_line = product.attribute_line_ids.filtered(lambda x: x.attribute_id.id == attr.id)
                                                    # combination ========
                                                    combination = self.env[
                                                        'product.template.attribute.value'].sudo().search([
                                                        ('attribute_line_id', '=', attribute_line.id),
                                                        ('attribute_id', '=', attribute_line.attribute_id.id),
                                                        ('product_attribute_value_id', '=', attr_value.id),
                                                        ('product_tmpl_id', '=', product.id)], limit=1)
                                                    if not combination:
                                                        combination = self.env[
                                                            'product.template.attribute.value'].sudo().create({
                                                            'attribute_line_id': attribute_line.id,
                                                            'attribute_id': attribute_line.attribute_id.id,
                                                            'product_attribute_value_id': attr_value.id,
                                                            'product_tmpl_id': product.id
                                                        })
                                                        _logger.info("New Combination created:{}".format(combination))
                                                    if combination:
                                                        combination_lst.append(combination.id)
                                    if attribute_line:
                                        #  check for value exist or not
                                        _logger.info("Attribute line **found** in the product->{}:{}".format(product.id,
                                                                                                           attr.name))
                                        if not value[col_index]:
                                            value[col_index] = 'NULL'
                                        if value[col_index]:
                                            attr_value = self.env['product.attribute.value'].sudo().search([
                                                ('name', '=', str(value[col_index]).strip()),
                                                ('attribute_id', '=', attr.id)
                                            ])
                                            if not attr_value:
                                                #     create attr_value in that attribute
                                                _logger.info(
                                                    "Attribute value not found creating new value:{} in that attribute:{}".format(
                                                        str(value[col_index]).strip(), attr.name))
                                                attr_value = self.env['product.attribute.value'].sudo().create(
                                                    {'name': str(value[col_index]).strip(),
                                                     'attribute_id': attr.id})
                                            if attr_value:
                                                # check for exist in that line or not, if not link that id in value_ids
                                                if attr_value.id not in attribute_line.value_ids.ids:
                                                    attribute_line.write({'value_ids':[(4,attr_value.id)]})
                                                    _logger.info(
                                                        "Linking the value:{} in the value_ids in the attribute line:{}".
                                                        format(attr_value.name, attr.name))
                                                # combination ========
                                                combination = self.env[
                                                    'product.template.attribute.value'].sudo().search([
                                                    ('attribute_line_id', '=', attribute_line.id),
                                                    ('attribute_id', '=', attribute_line.attribute_id.id),
                                                    ('product_attribute_value_id', '=', attr_value.id),
                                                    ('product_tmpl_id', '=', product.id)], limit=1)
                                                if not combination:
                                                    combination = self.env[
                                                        'product.template.attribute.value'].sudo().create({
                                                        'attribute_line_id': attribute_line.id,
                                                        'attribute_id': attribute_line.attribute_id.id,
                                                        'product_attribute_value_id': attr_value.id,
                                                        'product_tmpl_id': product.id
                                                    })
                                                    _logger.info("New Combination created:{}".format(combination))
                                                if combination:
                                                    combination_lst.append(combination.id)

                            if combination_lst:
                                # type combination: recordset of `product.template.attribute.value
                                combination = self.env['product.template.attribute.value'].sudo().search([
                                    ('id', 'in', combination_lst)])
                                _logger.info("Combinations:{}".format(combination))
                                product._create_product_variant(combination=combination)
                                self.env.cr.commit()
                                variant = False
                                for var in product.product_variant_ids:
                                    if set(var.product_template_attribute_value_ids) == set(combination):
                                        variant = var
                                        continue
                                if variant:
                                    if variant.mrp_price != value[2]:
                                        variant.mrp_price = value[2]


