from odoo import models, fields, _
from odoo.exceptions import ValidationError,UserError
import xlrd
import base64
from io import BytesIO
import logging
_logger = logging.getLogger('Lens Price List')

class ImportLensPricelist(models.TransientModel):
    _name = 'import.lens.pricelist'

    xls_file = fields.Binary(attachment=True, string='XLS File')
    filename = fields.Char()


    def read_xlx_file(self):
        '''
         cursereate Temp xlx file
        '''
        file_data = self.xls_file
        if not file_data:
            raise UserError(_('Error!', "Please Select a File"))
        else:
            val = base64.decodestring(file_data)
            tempfile = BytesIO()
            tempfile.write(val)
            work_book = xlrd.open_workbook(file_contents=tempfile.getvalue())
        return work_book

    def create_or_update_pricelist_for_lenses(self):
        work_book = self.read_xlx_file()
        try:
            for sheet in work_book._sheet_list:
                if work_book._sheet_list.index(sheet) >= 1:
                    continue
                header_values = sheet._cell_values[0]
                cell_values = sheet._cell_values[1:]
                # header_index_dict = {}
                # for header_value in header_values:
                #     header_index_dict.update({header_value:header_values.index(header_value)})
                line_no = 1
                for value in cell_values:
                    if not [value[0] and value[1]]:
                        _logger.info("Skipping this row, because data is not available in the mandatory columns.->{}".format(value))
                        continue
                    else:
                        brand = self.env['product.brand'].sudo().search([('name','=',str(value[0]).strip())],limit=1)
                        category = self.env['product.category'].sudo().search([('name','=',str(value[1]).strip())],limit=1)
                        if brand and category:
                            # saerch for the parent record with the brand and category
                            pricelist = self.env['lens.pricelist'].sudo().search([('brand_id','=',brand.id),
                                                                          ('category_id','=',category.id)],limit=1)
                            if not pricelist:
                                pricelist = self.env['lens.pricelist'].sudo().create({'brand_id':brand.id,'category_id':category.id})

                            #     search for all the many2one datq and then create new if not exist and update price if record exist
                            attr_value_lst = []
                            for value_no in range(2,len(value)-1):
                                attribute = self.env['product.attribute'].sudo().search([('name','=',str(header_values[value_no]).strip())],limit=1)
                                if attribute:
                                    attribute_value = self.env['product.attribute.value'].sudo().search([
                                        ('name','=',str(value[value_no]).strip()),('attribute_id','=',attribute.id)],limit=1)
                                    if not attribute_value:
                                #         create new attribute value in that attribute
                                        attribute_value = self.env['product.attribute.value'].sudo().create({'name':str(value[value_no]).strip(),'attribute_id':attribute.id})
                                    attr_value_lst.append(attribute_value.id)
                                if not attribute:
                                    _logger.info("Skipping the value, Attribute not Found with this name:{}".format(str(header_values[value_no]).strip()))
                            attribute_values = self.env['product.attribute.value'].sudo().browse(attr_value_lst)
                            vals = {
                                'lens_pricelist_id': pricelist.id,
                                'power_range_id': attribute_values.filtered(lambda x:x.attribute_id.name == str(header_values[2]).strip()).id if value[2] else False,
                                'material_id': attribute_values.filtered(lambda x:x.attribute_id.name == str(header_values[3]).strip()).id if value[3] else False,
                                'lens_color_id': attribute_values.filtered(lambda x:x.attribute_id.name == str(header_values[4]).strip()).id if value[4] else False,
                                'index_id': attribute_values.filtered(lambda x:x.attribute_id.name == str(header_values[5]).strip()).id if value[5] else False,
                                'diameter_id': attribute_values.filtered(lambda x:x.attribute_id.name == str(header_values[6]).strip()).id if value[6] else False,
                                'coating_id': attribute_values.filtered(lambda x:x.attribute_id.name == str(header_values[7]).strip()).id if value[7] else False,
                                'price':float(value[8]) if value[8] else 0
                            }
                            line = self.search_existing_pricelist_line(pricelist,attribute_values,header_values,value)
                            if line and value[8]:
                                _logger.info("Existing Pricelist line found in the data, line:{},existing_value:{}->new_value:{}"
                                             .format(line,line.price,float(value[8])))
                                line.update({'price':float(value[8])})
                            if not line:
                                self.env['lens.pricelist.line'].sudo().create(vals)
                                _logger.info("New Line created with this vals:{}".format(vals))
                                self.env.cr.commit()
                            if not [brand and category]:
                                _logger.info("Brand or Catgeory not found at the time of import of this line:{}".format(value))
        except Exception as e:
            _logger.info("Exception occurred while importing the pricelist for lens:{}".format(e))


    def search_existing_pricelist_line(self,pricelist,attribute_values,header_values,value):
        if pricelist and attribute_values:
            domain = [('power_range_id','=',attribute_values.filtered(lambda x:x.attribute_id.name == str(header_values[2]).strip()).id if value[2] else False),
                      ('material_id','=',attribute_values.filtered(lambda x:x.attribute_id.name == str(header_values[3]).strip()).id if value[3] else False),
                      ('lens_color_id','=',attribute_values.filtered(lambda x:x.attribute_id.name == str(header_values[4]).strip()).id if value[4] else False),
                      ('index_id','=',attribute_values.filtered(lambda x:x.attribute_id.name == str(header_values[5]).strip()).id if value[5] else False),
                      ('diameter_id','=',attribute_values.filtered(lambda x:x.attribute_id.name == str(header_values[6]).strip()).id if value[6] else False),
                      ('coating_id','=',attribute_values.filtered(lambda x:x.attribute_id.name == str(header_values[7]).strip()).id if value[7] else False),
                      ('lens_pricelist_id','=',pricelist.id)]
            line = self.env['lens.pricelist.line'].sudo().search(domain)
            if line:
                return line
        return False