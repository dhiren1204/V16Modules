from odoo import _,fields,models, api
import xlrd
import base64
from io import BytesIO
import logging
from odoo.exceptions import ValidationError
from datetime import datetime
from dateutil import parser
from itertools import groupby
_logger = logging.getLogger("Amazon FBA")

class AmazonFBAImport(models.TransientModel):
    _name = 'amazon.fba.import'
    _description = 'Amazon FBA Import'

    xls_file = fields.Binary(attachment=True, string='XLS File')
    is_b2c = fields.Boolean('Is B2C',default=False)
    warehouse_id = fields.Many2one(comodel_name="stock.warehouse", string="Warehouse")
    merchant_name = fields.Selection([('amazon','Amazon'),
                                      ('flipkart','Flipkart'),
                                      ('meesho','Meesho'),
                                      ('tata_cliq','Tata Cliq'),
                                      ('india_mart','India Mart'),
                                      ('jio_mart','Jio Mart')],string='Merchant' ,default='amazon')
    # operation_type_id = fields.Many2one('stock.picking.type',copy=False)

    @api.onchange('merchant_name')
    def onchange_merchant_name(self):
        if self.merchant_name != 'amazon':
            self.is_b2c = True
        # if self.merchant_name == 'amazon' and self.operation_type_id:
        #     self.operation_type_id = False

    def read_xlx_file(self):
        file_data = self.xls_file
        if not file_data:
            raise ValidationError(_('Error!', "Please Select a File"))
        else:
            val = base64.decodestring(file_data)
            tempfile = BytesIO()
            tempfile.write(val)
            work_book = xlrd.open_workbook(file_contents=tempfile.getvalue())
        return work_book

    def check_sheet(self):
        if self.xls_file and self.merchant_name == 'amazon':
            work_book = self.read_xlx_file()
            msg=['Sheet Data Analysis']
            _logger.info("============= Amazon FBA Import ================")
            for sheet in work_book._sheet_list:
                if work_book._sheet_list.index(sheet) != 0:
                    continue
                sheet_values = sheet._cell_values
                sheet_header = sheet_values[0]
                sheet_data = sheet_values[1:]
                upload_sheet_type = 'Sheet Type:{}'.format('B2C' if self.is_b2c else 'B2B')
                total_lines = len(sheet_data)
                blank_amazon_order = len(list(filter(lambda x: len(str(x[4]).strip()) == 0, sheet_data)))
                shipment_data = len(list(filter(lambda x: str(x[3]).strip().lower() == 'shipment', sheet_data)))
                cancel_data = len(list(filter(lambda x: str(x[3]).strip().lower() == 'cancel', sheet_data)))
                refund_data = len(list(filter(lambda x: str(x[3]).strip().lower() == 'refund', sheet_data)))
                total_unique_amazon_order_ids = len(list(set([x[4] for x in list(filter(lambda x: str(x[4]).strip(), sheet_data))])))
                total_products_in_sheet = len(list(set([x[13] for x in list(filter(lambda x: str(x[4]).strip(), sheet_data))])))
                products_found_in_odoo = len(self.env['product.product'].sudo().search([('default_code','in',list(set([x[13] for x in list(filter(lambda x: str(x[4]).strip(), sheet_data))])))]))
                msg.append("\n{}\nTotal Lines:{}\nBlank Amazon Orders:{}\nShipment Order lines:{}\nCancel Order Lines:{}\n"
                           "Refund Order Lines:{}\nTotal Unique Amazon Orders:{}\nTotal Products In Sheet:{}\nTotal Products Found in System:{}".format(
                    upload_sheet_type,total_lines,blank_amazon_order,shipment_data,cancel_data,refund_data,
                    total_unique_amazon_order_ids,total_products_in_sheet,products_found_in_odoo))
                if self.warehouse_id:
                    msg.append("\nWarehouse selected:{}".format(self.warehouse_id.name,))
                total_archived_products = total_not_found_products = 0
                total_archived_products_list = False
                if total_products_in_sheet != products_found_in_odoo:
                    total_archived_products_list = self.env['product.product'].sudo().search([
                        ('default_code','in',list(set([x[13] for x in list(filter(lambda x: str(x[4]).strip(), sheet_data))]))),
                        ('active','=',False)]).mapped('default_code')
                    total_archived_products = len(self.env['product.product'].sudo().search([
                        ('default_code','in',list(set([x[13] for x in list(filter(lambda x: str(x[4]).strip(), sheet_data))]))),
                        ('active','=',False),]))
                    msg.append("\nTotal Archived Products:{}\nTotal Archived Products List:{}".format(total_archived_products,total_archived_products_list,))
                    if (total_archived_products + products_found_in_odoo) != total_products_in_sheet:
                        total_not_found_products = total_products_in_sheet-(total_archived_products + products_found_in_odoo)
                        msg.append("\nTotal Products Not Found in System:{}".format(total_archived_products,total_not_found_products))

                if not self.is_b2c:
                    # not b2c state= 77 , b2c state= 24
                    state_names = [(x[24]).strip() for x in list(filter(lambda x: str(x[24]).strip() != False, sheet_data))]
                    total_state_names_in_sheet = len(state_names)
                    total_state_found_in_system = []
                    for state in state_names:
                        state_found = self.env['res.country.state'].sudo().search([('name','ilike',str(state).lower()),('country_id','=',104)])
                        if state_found:
                            total_state_found_in_system.append(state_found.id)
                    total_state_found_in_system = len(self.env['res.country.state'].sudo().browse(total_state_found_in_system))
                    msg.append("\nTotal States:{}->{}\n Total States Found in System:{}".format(total_state_names_in_sheet,list(set(state_names)),total_state_found_in_system))
                if self.is_b2c:
                    # not b2c state= 77 , b2c state= 24
                    state_names = [(x[24]).strip() for x in
                                   list(filter(lambda x: str(x[24]).strip() != False, sheet_data))]
                    total_state_names_in_sheet = len(list(set(state_names)))
                    total_state_found_in_system = []
                    for state in state_names:
                        state_found = self.env['res.country.state'].sudo().search(
                            [('name', 'ilike', str(state).lower()),('country_id','=',104)])
                        if state_found:
                            total_state_found_in_system.append(state_found.id)
                    total_state_found_in_system = len(self.env['res.country.state'].sudo().browse(list(set(total_state_found_in_system))))
                    msg.append("'\n'Total States in Sheet:{} ->{}\n Total States Found in System:{}".format(total_state_names_in_sheet,
                                                                                         list(set(state_names)),
                                                                                         total_state_found_in_system))
                # products -> location count and missing count
                products_qty_dict_in_sheet = {}
                products_qty_dict_in_sheet_refund = {}
                if self.warehouse_id and self.xls_file:
                    # taking shipment data only.
                    for line in list(filter(lambda x: str(x[3]).strip().lower() == 'shipment', sheet_data)):
                        if line[13]:
                            product = self.env['product.product'].sudo().search([('default_code','=',str(line[13]).strip())])
                            if product:
                                # stock_in_location = self.env['stock.quant']._get_available_quantity(line.product_id,self.warehouse_id.lot_stock_id)
                                if products_qty_dict_in_sheet.get(product.default_code,False):
                                    products_qty_dict_in_sheet.update({product.default_code: products_qty_dict_in_sheet.get(product.default_code,False) + float(line[9])})
                                    continue
                                if not products_qty_dict_in_sheet.get(product.default_code,False):
                                    products_qty_dict_in_sheet.update({product.default_code: float(line[9])})
                                    continue
                    for line in list(filter(lambda x: str(x[3]).strip().lower() == 'refund', sheet_data)):
                        if line[13]:
                            product = self.env['product.product'].sudo().search([('default_code','=',str(line[13]).strip())])
                            if product:
                                # stock_in_location = self.env['stock.quant']._get_available_quantity(line.product_id,self.warehouse_id.lot_stock_id)
                                if products_qty_dict_in_sheet_refund.get(product.default_code,False):
                                    products_qty_dict_in_sheet_refund.update({product.default_code: products_qty_dict_in_sheet_refund.get(product.default_code,False) + float(line[9])})
                                    continue
                                if not products_qty_dict_in_sheet_refund.get(product.default_code,False):
                                    products_qty_dict_in_sheet_refund.update({product.default_code: float(line[9])})
                                    continue


                    # for line in list(filter(lambda x: str(x[3]).strip().lower() == 'refund', sheet_data)):
                    #     if line[13]:
                    #         product = self.env['product.product'].sudo().search([('default_code','=',str(line[13]).strip())])
                    #         if product:
                    #             # stock_in_location = self.env['stock.quant']._get_available_quantity(line.product_id,self.warehouse_id.lot_stock_id)
                    #             if products_qty_dict_in_sheet.get(product.default_code,False):
                    #                 products_qty_dict_in_sheet.update({product.default_code: products_qty_dict_in_sheet.get(product.default_code,False) - float(line[9])})
                    #                 continue
                    #             if not products_qty_dict_in_sheet.get(product.default_code,False):
                    #                 products_qty_dict_in_sheet.update({product.default_code: -1*float(line[9])})
                    #                 continue
                    msg.append("\nShipment -> Products With total qty in sheet:{}\nRefund -> Products With total qty in sheet:{}".format(
                        products_qty_dict_in_sheet,products_qty_dict_in_sheet_refund))

                # ==== location stock not available ====
                # msg.append("\n\nMissing stock")
                # product_stock_not_available= {}
                # for ulcode in products_qty_dict_in_sheet.keys():
                #     product = self.env['product.product'].sudo().search(
                #         [('default_code', '=', ulcode)])
                #     if product:
                #         stock_in_location = self.env['stock.quant']._get_available_quantity(product,self.warehouse_id.lot_stock_id)
                #         if not (float(products_qty_dict_in_sheet.get(ulcode,False)) <= stock_in_location):
                #             product_stock_not_available.update({ulcode:float(products_qty_dict_in_sheet.get(ulcode,False)) - stock_in_location})
                #
                # msg.append("\nMissing stock count: {} ".format(product_stock_not_available))


            raise ValidationError(msg)

        if self.xls_file and self.merchant_name != 'amazon':
            work_book = self.read_xlx_file()
            msg = ['Sheet Data Analysis']
            _logger.info("============= Other Ecommerce Sheet Import ================")
            for sheet in work_book._sheet_list:
                if work_book._sheet_list.index(sheet) != 0:
                    continue
                sheet_values = sheet._cell_values
                sheet_header = sheet_values[0]
                sheet_data = sheet_values[1:]
                upload_sheet_type = 'Sheet Type:{}'.format('B2C' if self.is_b2c else 'B2B')
                total_lines = len(sheet_data)
                blank_amazon_order = len(list(filter(lambda x: len(str(x[3]).strip()) == 0, sheet_data)))
                shipment_data = len(list(filter(lambda x: str(x[2]).strip().lower() == 'shipment', sheet_data)))
                cancel_data = len(list(filter(lambda x: str(x[2]).strip().lower() == 'cancel', sheet_data)))
                refund_data = len(list(filter(lambda x: str(x[2]).strip().lower() == 'refund', sheet_data)))
                total_unique_amazon_order_ids = len(
                    list(set([x[3] for x in list(filter(lambda x: str(x[3]).strip(), sheet_data))])))
                total_products_in_sheet = len(
                    list(set([x[5] for x in list(filter(lambda x: str(x[3]).strip(), sheet_data))])))
                products_found_in_odoo = len(self.env['product.product'].sudo().search([('default_code', 'in', list(
                    set([x[5] for x in list(filter(lambda x: str(x[3]).strip(), sheet_data))])))]))
                msg.append(
                    "\n{}\nTotal Lines:{}\nBlank Amazon Orders:{}\nShipment Order lines:{}\nCancel Order Lines:{}\n"
                    "Refund Order Lines:{}\nTotal Unique Amazon Orders:{}\nTotal Products In Sheet:{}\nTotal Products Found in System:{}".format(
                        upload_sheet_type, total_lines, blank_amazon_order, shipment_data, cancel_data, refund_data,
                        total_unique_amazon_order_ids, total_products_in_sheet, products_found_in_odoo))
                if self.warehouse_id:
                    msg.append("\nWarehouse selected:{}".format(self.warehouse_id.name, ))
                total_archived_products = total_not_found_products = 0
                total_archived_products_list = False
                if total_products_in_sheet != products_found_in_odoo:
                    total_archived_products_list = self.env['product.product'].sudo().search([
                        ('default_code', 'in',
                         list(set([x[5] for x in list(filter(lambda x: str(x[3]).strip(), sheet_data))]))),
                        ('active', '=', False)]).mapped('default_code')
                    total_archived_products = len(self.env['product.product'].sudo().search([
                        ('default_code', 'in',
                         list(set([x[5] for x in list(filter(lambda x: str(x[3]).strip(), sheet_data))]))),
                        ('active', '=', False), ]))
                    msg.append(
                        "\nTotal Archived Products:{}\nTotal Archived Products List:{}".format(total_archived_products,
                                                                                               total_archived_products_list, ))
                    if (total_archived_products + products_found_in_odoo) != total_products_in_sheet:
                        total_not_found_products = total_products_in_sheet - (
                                    total_archived_products + products_found_in_odoo)
                        msg.append("\nTotal Products Not Found in System:{}".format(total_archived_products,
                                                                                    total_not_found_products))

                if not self.is_b2c:
                    # not b2c state= 77 , b2c state= 24
                    state_names = [(x[7]).strip() for x in
                                   list(filter(lambda x: str(x[7]).strip() != False, sheet_data))]
                    total_state_names_in_sheet = len(state_names)
                    total_state_found_in_system = []
                    for state in state_names:
                        state_found = self.env['res.country.state'].sudo().search(
                            [('name', 'ilike', str(state).lower()), ('country_id', '=', 104)])
                        if state_found:
                            total_state_found_in_system.append(state_found.id)
                    total_state_found_in_system = len(
                        self.env['res.country.state'].sudo().browse(total_state_found_in_system))
                    msg.append(
                        "\nTotal States:{}->{}\n Total States Found in System:{}".format(total_state_names_in_sheet,
                                                                                         list(set(state_names)),
                                                                                         total_state_found_in_system))
                if self.is_b2c:
                    # not b2c state= 77 , b2c state= 24
                    state_names = [(x[7]).strip() for x in
                                   list(filter(lambda x: str(x[7]).strip() != False, sheet_data))]
                    total_state_names_in_sheet = len(list(set(state_names)))
                    total_state_found_in_system = []
                    for state in state_names:
                        state_found = self.env['res.country.state'].sudo().search(
                            [('name', 'ilike', str(state).lower()), ('country_id', '=', 104)])
                        if state_found:
                            total_state_found_in_system.append(state_found.id)
                    total_state_found_in_system = len(
                        self.env['res.country.state'].sudo().browse(list(set(total_state_found_in_system))))
                    msg.append("'\n'Total States in Sheet:{} ->{}\n Total States Found in System:{}".format(
                        total_state_names_in_sheet,
                        list(set(state_names)),
                        total_state_found_in_system))
                # products -> location count and missing count
                products_qty_dict_in_sheet = {}
                products_qty_dict_in_sheet_refund = {}
                if self.warehouse_id and self.xls_file:
                    # taking shipment data only.
                    for line in list(filter(lambda x: str(x[2]).strip().lower() == 'shipment', sheet_data)):
                        if line[5]:
                            product = self.env['product.product'].sudo().search(
                                [('default_code', '=', str(line[5]).strip())])
                            if product:
                                # stock_in_location = self.env['stock.quant']._get_available_quantity(line.product_id,self.warehouse_id.lot_stock_id)
                                if products_qty_dict_in_sheet.get(product.default_code, False):
                                    products_qty_dict_in_sheet.update({
                                                                          product.default_code: products_qty_dict_in_sheet.get(
                                                                              product.default_code, False) + float(
                                                                              line[4])})
                                    continue
                                if not products_qty_dict_in_sheet.get(product.default_code, False):
                                    products_qty_dict_in_sheet.update({product.default_code: float(line[4])})
                                    continue
                    for line in list(filter(lambda x: str(x[2]).strip().lower() == 'refund', sheet_data)):
                        if line[5]:
                            product = self.env['product.product'].sudo().search(
                                [('default_code', '=', str(line[5]).strip())])
                            if product:
                                # stock_in_location = self.env['stock.quant']._get_available_quantity(line.product_id,self.warehouse_id.lot_stock_id)
                                if products_qty_dict_in_sheet_refund.get(product.default_code, False):
                                    products_qty_dict_in_sheet_refund.update({
                                                                                 product.default_code: products_qty_dict_in_sheet_refund.get(
                                                                                     product.default_code,
                                                                                     False) + float(line[4])})
                                    continue
                                if not products_qty_dict_in_sheet_refund.get(product.default_code, False):
                                    products_qty_dict_in_sheet_refund.update({product.default_code: float(line[4])})
                                    continue

                    # for line in list(filter(lambda x: str(x[3]).strip().lower() == 'refund', sheet_data)):
                    #     if line[13]:
                    #         product = self.env['product.product'].sudo().search([('default_code','=',str(line[13]).strip())])
                    #         if product:
                    #             # stock_in_location = self.env['stock.quant']._get_available_quantity(line.product_id,self.warehouse_id.lot_stock_id)
                    #             if products_qty_dict_in_sheet.get(product.default_code,False):
                    #                 products_qty_dict_in_sheet.update({product.default_code: products_qty_dict_in_sheet.get(product.default_code,False) - float(line[9])})
                    #                 continue
                    #             if not products_qty_dict_in_sheet.get(product.default_code,False):
                    #                 products_qty_dict_in_sheet.update({product.default_code: -1*float(line[9])})
                    #                 continue
                    msg.append(
                        "\nShipment -> Products With total qty in sheet:{}\nRefund -> Products With total qty in sheet:{}".format(
                            products_qty_dict_in_sheet, products_qty_dict_in_sheet_refund))

                # ==== location stock not available ====
                # msg.append("\n\nMissing stock")
                # product_stock_not_available= {}
                # for ulcode in products_qty_dict_in_sheet.keys():
                #     product = self.env['product.product'].sudo().search(
                #         [('default_code', '=', ulcode)])
                #     if product:
                #         stock_in_location = self.env['stock.quant']._get_available_quantity(product,self.warehouse_id.lot_stock_id)
                #         if not (float(products_qty_dict_in_sheet.get(ulcode,False)) <= stock_in_location):
                #             product_stock_not_available.update({ulcode:float(products_qty_dict_in_sheet.get(ulcode,False)) - stock_in_location})
                #
                # msg.append("\nMissing stock count: {} ".format(product_stock_not_available))

            raise ValidationError(msg)


    def create_customer_and_invoice_of_amazon(self):
        if self.xls_file:
            self = self.with_context(amazon_import_order=True)
            work_book = self.read_xlx_file()
            _logger.info("============= Amazon FBA Import ================")
            for sheet in work_book._sheet_list:
                if work_book._sheet_list.index(sheet) != 0:
                    continue
                sheet_values = sheet._cell_values
                sheet_header = sheet_values[0]
                sheet_data = sheet_values[1:]
                if self.merchant_name=='amazon':
                    if not self.is_b2c:
                        if str(sheet_header[76]).lower() != 'bill to city' or str(sheet_header[77]).lower() != 'bill to state'\
                                or str(sheet_header[78]).lower() != 'bill to country' or str(sheet_header[79]).lower() != 'bill to postalcode'\
                                or str(sheet_header[80]).lower() != 'customer bill to gstid' or str(sheet_header[82]).lower() != 'buyer name':
                            _logger.info("Sheet Header Not Matched with the selected field")
                            raise ValidationError(_("Sheet Header Not Matched with the selected field"))
                        self.update_customer_amazon_fba(sheet_data)
                        self.env.cr.commit()
                    self.create_invoice_from_amazon_fba_sheet(sheet_data)
                else:
                    self.create_invoice_for_other_ecommerce_sheet(sheet_data)



    # ================= other ecomm sheets START =========================
    def check_partner_exist_for_other_ecommerce_b2c(self,data):
        # now implemented state wise b2c customers
        _logger.info("===== check_partner_exist_for_other_ecommerce_b2c START =====")
        partner_name_vals = {'flipkart':'Flipkart','meesho':'Meesho','tata_cliq':'Tata Cliq', 'india_mart':'India Mart','jio_mart':'Jio Mart'}
        partner = False
        country = str(data[8]).strip() if data[8] else False
        state = str(data[7]).strip() if data[7] else False
        if country and partner_name_vals.get(self.merchant_name,False):
            country_id = self.env['res.country'].sudo().search([('code', '=', country)], limit=1)
            if country_id and state:
                if state:
                    state_id = self.env['res.country.state'].sudo().search([
                        ('name', 'ilike', state), ('country_id', '=', country_id.id)],limit=1)
                    if state_id:
                        partner = self.env['res.partner'].sudo().search([
                            ('is_amazon_contact','=',True),('is_amazon_b2c_customer','=',True),('state_id','=',state_id.id),
                            ('name','ilike',partner_name_vals.get(self.merchant_name))],limit=1)
                    if partner:
                        _logger.info("Existing partner found:{}->{}".format(partner.name,partner.id))
                        return partner
                    if not partner:
                        prozo_city = self.env['prozo.city'].sudo().search(
                            [('name', 'ilike', str(data[6]).strip() if data[6] else '')])
                        customer_category = self.env['user.type'].sudo().search([('name', '=', 'AMAZON E COMMERCE')],
                                                                                limit=1)
                        customer_category_lst = [1]
                        if customer_category:
                            customer_category_lst = [customer_category.id]
                        partner_vals = {
                            'name': '{} {}'.format(partner_name_vals.get(self.merchant_name),state_id.name),
                            'city': str(data[6]).strip() if data[6] else '',
                            'state_id': state_id.id,
                            'country_id': country_id.id,
                            'is_amazon_contact': True,
                            'is_amazon_b2c_customer': True,
                            # 'partner_type': 'B2B', # No option for amazon Fba B2C
                            'prozo_city_id': prozo_city.ids[0] if prozo_city else False,
                            'user_type_ids':[(6,0,customer_category_lst)]  # AMAZON E COMMERCE
                        }
                        partner = self.env['res.partner'].sudo().create(partner_vals)
                        _logger.info("New Partner Created:{}->{}".format(partner.name,partner.id))
                        return partner
        return partner


    # |============for the sheet sale order , refund , return, delivery , invoice and credit note will create===============|



    # def create_invoice_for_other_ecommerce_sheet(self,sheet_data):
    #     """
    #             For the sheet sale order will create based on amazon order id and then order confirms validate and create invoice for that
    #             """
    #     # type = ['Shipment','cancel','refund']
    #     _logger.info(" =========== create_invoice_for_other_ecommerce_sheet START ========== ")
    #     self = self.with_context(ecom_operation_type=self.operation_type_id)
    #     warehouse_id = self.warehouse_id
    #     if not warehouse_id:
    #         warehouse = int(self.env['ir.config_parameter'].sudo().get_param(
    #             'ul88_import_export.amazon_warehouse_id'))
    #         if warehouse:
    #             warehouse_id = self.env['stock.warehouse'].sudo().browse(warehouse)
    #     count = 0
    #     partner = False
    #     for correcting_data in sheet_data:
    #         correcting_data[3] = str(correcting_data[3]).strip().strip('.0') if str(correcting_data[3]).strip().find('.0') >= 0 else str(correcting_data[3]).strip()
    #     shipment_data = list(filter(lambda x: str(x[2]).strip().lower() == 'shipment' or 'cancel', sheet_data))
    #     for data in shipment_data:
    #         try:
    #             amazon_order = str(data[3]).strip().strip('.0') if str(data[3]).strip().find('.0') >= 0 else str(data[3]).strip()
    #             count += 1
    #             if str(data[2]).strip().lower() not in ['shipment', 'cancel']:
    #                 _logger.info(
    #                     "Skipping this row:{} because type doesn't match with this:{} ".format(count, 'shipment'))
    #                 continue
    #             # if str(data[80]).strip():
    #
    #             if self.is_b2c:
    #                 partner = self.check_partner_exist_for_other_ecommerce_b2c(data)
    #             if partner:
    #                 sale_order = self.env['sale.order'].sudo().search([('amazon_order', '=', str(data[3]).strip())],
    #                                                                   limit=1)
    #                 product = self.env['product.product'].sudo().search([('default_code', '=', str(data[5]).strip())])
    #                 if sale_order and product:
    #                     _logger.info("sale_order and Product = {}, {} ".format(sale_order, product))
    #                     line = sale_order.order_line.filtered(
    #                         lambda x: x.product_id.default_code == str(data[5]).strip())
    #                     if line:
    #                         _logger.info('Existing line found int the sale order with this sku:{}'.format(
    #                             str(data[5]).strip()))
    #                         if line.product_uom_qty < int(data[4]):
    #                             line.update({'product_uom_qty': line.product_uom_qty + int(data[4])})
    #                             self.env.cr.commit()
    #                     if not line:
    #                         self.update_order_line_for_other_ecom_sheets(data, sale_order, product)
    #                 # warehouse = self.env['stock.warehouse'].sudo().search([('id','=',14)])
    #                 order_date = datetime.now().date()
    #                 if type('') == type(data[1]):
    #                     order_date = parser.parse(data[1])
    #                 if type(1.00) == type(data[1]):
    #                     order_date = datetime.utcfromtimestamp((data[1] - 25569) * 86400.0)
    #                 # order_date = datetime.strptime(data[2],'%Y-%m-%d %H:%M:%S')
    #                 if partner and warehouse_id and not sale_order:
    #                     order_vals = {
    #                         'partner_id': partner.id,
    #                         'partner_invoice_id': partner.id,
    #                         'partner_shipping_id': partner.id,
    #                         'warehouse_id': warehouse_id.id,
    #                         'company_branch_id': warehouse_id.company_branch_id.id,
    #                         'company_id': self.env.user.company_id.id,
    #                         'team_id': self.env['crm.team'].sudo().search(
    #                             [('company_id', '=', self.env.user.company_id.id)], limit=1).id,
    #                         # 'team_id': self.env['website'].search([], limit=1).crm_default_team_id.id,
    #                         'date_order': order_date.date() if order_date else datetime.now(),
    #                         'origin': data[0],
    #                         # storing this invoice name in sale order bcoz easy to update in invoice later
    #                         'amazon_order': str(data[3]).strip(),
    #                         'is_amazon_order': True,
    #                         'l10n_in_journal_id': warehouse_id.l10n_in_sale_journal_id.id,
    #                     }
    #                     sale_order = self.env['sale.order'].sudo().create(order_vals)
    #                     if sale_order:
    #                         _logger.info("sale order created :{}".format(sale_order))
    #                         self.env.cr.commit()
    #                         if product:
    #                             self.update_order_line_for_other_ecom_sheets(data, sale_order, product)
    #         except Exception as e:
    #             _logger.info("Exception occured in this create_invoice_from_amazon_fba_sheet: {}".format(e))
    #             continue
    #     # ======== Cancelling the order ===============
    #     cancel_data = list(filter(lambda x: str(x[2]).strip().lower() == 'cancel', sheet_data))
    #     for data in cancel_data:
    #         sale_order_to_cancel = self.env['sale.order'].sudo().search(
    #             [('is_amazon_order', '=', True), ('amazon_order', '=', str(data[3]).strip())], limit=1)
    #         if sale_order_to_cancel and sale_order_to_cancel.state != 'cancel':
    #             sale_order_to_cancel.write({'state': 'cancel'})
    #             self.env.cr.commit()
    #             _logger.info("Sale Order Cancelled:{} with this amazon order id:{}".format(sale_order_to_cancel.name,
    #                                                                                        str(data[3]).strip()))
    #     # ==============================================
    #     # ===== Now Confirming the order and Validating and then create invoice =====
    #     amazon_order_ids = list(set([str(data[3]).strip() for data in shipment_data]))
    #     for amazon_order_id in amazon_order_ids:
    #         amazon_sale_order = self.env['sale.order'].sudo().search([('is_amazon_order', '=', True),
    #                                                                   ('amazon_order', '=', amazon_order_id)], limit=1)
    #         if amazon_sale_order:
    #             try:
    #                 if amazon_sale_order.state in ['draft', 'sent']:
    #                     amazon_sale_order.action_confirm()
    #                     self.env.cr.commit()
    #                     _logger.info("=== Amazon Sale Order Confirmed :{} ===".format(amazon_sale_order.name))
    #                 picking = amazon_sale_order.picking_ids.filtered(lambda x: x.state not in ['done', 'cancel'])
    #                 if picking:
    #                     picking.move_ids_without_package.sudo().write({'picking_type_id': picking.picking_type_id.id,
    #                                                                     'location_id': picking.location_id.id,
    #                                                                     'location_dest_id': picking.location_dest_id.id})
    #                     picking.action_confirm()
    #                     self.env.cr.commit()
    #                     picking.action_assign()
    #                     self.env.cr.commit()
    #                     picking.move_line_ids_without_package.write({
    #                         'location_id': picking.location_id.id,
    #                         'location_dest_id': picking.location_dest_id.id})
    #                     self.env.cr.commit()
    #                     wiz = self.env['stock.immediate.transfer'].create({'pick_ids': [(4, picking.id)]})
    #                     wiz.process()
    #                     self.env.cr.commit()
    #                     _logger.info("Picking Process:{} ,state:{}, sale:{}".format(picking.name, picking.state
    #                                                                                 , amazon_sale_order.name))
    #                 if picking.state == 'done':
    #                     invoice = picking.sale_id._create_invoices()
    #                     self.env.cr.commit()
    #                     _logger.info("Invoice Generated for this sale order:{} ".format(amazon_sale_order.name))
    #                     if invoice:
    #                         # invoice_date = amazon_sale_order.date_order
    #                         # if type('') == type(data[2]):
    #                         #     invoice_date = parser.parse(data[2])
    #                         # if type(1.00) == type(data[2]):
    #                         #     invoice_date = datetime.utcfromtimestamp((data[2] - 25569) * 86400.0)
    #                         invoice.update(
    #                             {'name': amazon_sale_order.origin, 'invoice_date': amazon_sale_order.date_order})
    #                         # invoice.with_context(check_move_validity=False)._onchange_invoice_date()
    #                         invoice.invoice_line_ids.with_context(check_move_validity=False).write(
    #                             {'date': amazon_sale_order.date_order})
    #                         invoice.action_post()
    #             except Exception as e:
    #                 _logger.info(
    #                     "Exception occured while confirming order, validating delivery or createing invoice :{}".format(
    #                         e))
    #                 continue
    #     # ====================================
    #     # =========== Refund =================
    #     refund_data = list(filter(lambda x: str(x[2]).strip().lower() == 'refund', sheet_data))
    #     refund_orders_lst = list(set([str(data[3]).strip() for data in refund_data]))
    #     for data in refund_orders_lst:
    #         refund_order_sheet_data = list(filter(lambda x: str(x[3]).strip() == data, refund_data))
    #         # for data in refund_order_sheet_data:
    #         try:
    #             sale_order = False
    #             if str(refund_order_sheet_data[0][2]).strip().lower() == 'refund':
    #                 sale_order = self.env['sale.order'].sudo().search(
    #                     [('amazon_order', '=', str(refund_order_sheet_data[0][3]).strip())],
    #                     limit=1)
    #                 product = self.env['product.product'].sudo().search(
    #                     [('default_code', '=', str(refund_order_sheet_data[0][5]).strip())],
    #                     limit=1)
    #                 return_picking = self.env['stock.picking'].sudo().search([('note', '=', '{}-{}'.format(
    #                     str(refund_order_sheet_data[0][3]).strip(), product.id))])
    #                 if sale_order and sale_order.picking_ids and sale_order.picking_ids.filtered(
    #                         lambda x: x.picking_type_code == 'outgoing')[
    #                     0].state == 'done' and product and not return_picking:
    #                     #  create return and create credit note for this order
    #                     return_wiz = self.env['stock.return.picking'].sudo().create({
    #                         'picking_id': sale_order.picking_ids.filtered(
    #                             lambda x: x.picking_type_code == 'outgoing')[0].id
    #                     })
    #                     return_wiz._onchange_picking_id()
    #                     self.env.cr.commit()
    #                     if return_wiz:
    #                         products = self.env['product.product'].sudo().search(
    #                             [('default_code', 'in', [str(data[5]).strip() for data in refund_order_sheet_data])])
    #                         if products:
    #                             lines = []
    #                             for product in products:
    #                                 line = return_wiz.product_return_moves.filtered(
    #                                     lambda x: x.product_id.id in products.ids)
    #                                 if line:
    #                                     lines.append(line.id)
    #                                     qty = list(filter(lambda x: str(x[5]).strip() == product.default_code,
    #                                                       refund_order_sheet_data))[0][4]
    #                                     line.write({'quantity': qty if qty else line.quantity})
    #                             # unlink other lines
    #                             for line in return_wiz.product_return_moves:
    #                                 if line.id not in lines:
    #                                     line.unlink()
    #                                     self.env.cr.commit()
    #                         return_created = return_wiz.create_returns()
    #                         if return_created and return_created.get('res_id', False):
    #                             return_picking = self.env['stock.picking'].sudo().browse(
    #                                 return_created.get('res_id', False))
    #                             if return_picking:
    #                                 return_picking.write({'note': '{}-{}'.format(data, product.id)})
    #                                 wiz = self.env['stock.immediate.transfer'].create(
    #                                     {'pick_ids': [(4, return_picking.id)]})
    #                                 wiz.process()
    #                                 self.env.cr.commit()
    #                                 _logger.info("Refund return transfer creating and validating transfer:{}".format(
    #                                     return_picking.name, return_picking.state))
    #                     self.env.cr.commit()
    #         except Exception as e:
    #             _logger.info("Exception occurs while creating refund transfer:{}".format(e))
    #             continue
    #     # =========== credit note =================
    #     credit_notes_record = list(filter(lambda x: str(x[2]).strip().lower() == 'refund', sheet_data))
    #     credit_notes_ids = []
    #     for data in credit_notes_record:
    #         try:
    #             partner = False
    #             if self.is_b2c:
    #                 partner = self.check_partner_exist_for_other_ecommerce_b2c(data)
    #             sale_order = self.env['sale.order'].sudo().search(
    #                 [('amazon_order', '=', str(data[3]).strip()), ('state', 'in', ['sale', 'done'])],
    #                 limit=1)
    #             return_pickings = sale_order.picking_ids.filtered(
    #                 lambda x: x.picking_type_code == 'incoming' and x.state in ['done'])
    #             product = self.env['product.product'].sudo().search([('default_code', '=', str(data[5]).strip())])
    #             if partner and sale_order and product and return_pickings:
    #                 credit_note = self.env['account.move'].sudo().search([('ref', '=', sale_order.amazon_order)],
    #                                                                      limit=1)
    #                 if not credit_note:
    #                     cdnr_date = sale_order.date_order
    #                     if type('') == type(data[1]):
    #                         cdnr_date = parser.parse(data[1])
    #                     if type(1.00) == type(data[1]):
    #                         cdnr_date = datetime.utcfromtimestamp((data[1] - 25569) * 86400.0)
    #                     invoice_vals = {
    #                         'partner_id': partner.id,
    #                         'date': cdnr_date,
    #                         'invoice_date': cdnr_date,
    #                         'invoice_date_due': cdnr_date,
    #                         'extract_state': 'no_extract_requested',
    #                         'journal_id': sale_order.warehouse_id.l10n_in_sale_journal_id.id,
    #                         'type': 'out_refund',
    #                         'l10n_in_export_type': 'regular',
    #                         'ref': sale_order.amazon_order,
    #                         'name': data[0] and str(data[0]).strip() or sale_order.origin,
    #                         'company_branch_id': sale_order.warehouse_id.company_branch_id.id,
    #                     }
    #                     credit_note = self.env['account.move'].sudo().create(invoice_vals)
    #                     self.env.cr.commit()
    #                 if credit_note:
    #                     # check it is posted or not if posted then do nthing and if not posted check for the product exist if not exist add a line
    #                     if credit_note.state == 'draft':
    #                         sale_line = sale_order.order_line.filtered(lambda x: x.product_id.id == product.id)
    #                         if sale_line and return_pickings[0].move_line_ids_without_package.filtered(
    #                                 lambda x: x.product_id.id == product.id and x.state == 'done') and not credit_note.invoice_line_ids.filtered(
    #                             lambda x: x.product_id == product):
    #                             line_vals = {
    #                                 'move_id': credit_note.id,
    #                                 'product_id': sale_line[0].product_id.id,
    #                                 'quantity': int(data[4]),
    #                                 'date': credit_note.invoice_date,
    #                                 'price_unit': sale_line[0].price_unit,
    #                                 'tax_ids': sale_line[0].tax_id.ids,
    #                                 'account_id': sale_order.l10n_in_journal_id.default_debit_account_id.id,
    #                             }
    #                             self.env['account.move.line'].sudo().with_context(check_move_validity=False).create(
    #                                 line_vals)
    #                             _logger.info(
    #                                 "===== line inserted  in credit note ======:{} in this credit note:{}".format(
    #                                     line_vals, credit_note.name))
    #                             self.env.cr.commit()
    #                     if credit_note.state in ['posted', 'cancel']:
    #                         _logger.info("Credit note already exist:{}".format(credit_note.name))
    #                     credit_notes_ids.append(credit_note.id)
    #         except Exception as e:
    #             _logger.info("Exception occurs while creating credit note:{}".format(e))
    #             continue
    #     # posting_credit_notes
    #     if credit_notes_ids:
    #         credit_notes = self.env['account.move'].sudo().browse(credit_notes_ids)
    #         for note in credit_notes:
    #             try:
    #                 note.sudo().with_context(check_move_validity=False)._recompute_tax_lines()
    #                 note.sudo().with_context(check_move_validity=False)._move_autocomplete_invoice_lines_values()
    #                 self.env.cr.commit()
    #                 note.with_context(check_move_validity=False).action_post()
    #                 _logger.info("Posting credit_note:{}".format(note.name))
    #             except Exception as e:
    #                 _logger.info("Exception occurs while posting credit note:{}".format(e))
    #                 continue

    # def update_order_line_for_other_ecom_sheets(self,data,sale_order,product):
    #     _logger.info("===== update_order_line START ======== {}".format(data))
    #     line_values = {
    #         'order_id': sale_order.id,
    #         'product_id': product.id,
    #         'product_uom_qty': int(data[4]),
    #         'price_unit': float(data[9]),
    #     }
    #     # if not self.is_b2c:
    #     #     line_values.update({'tax_id': tax})
    #     sale_order.write({'order_line': [(0, 0, line_values)]})
    #     self.env.cr.commit()
    #     _logger.info("===== update_order_line END ======== {}".format(line_values))

    # ================= other ecomm sheets END =========================

    # ================ Amazon flow without SO Start ========================
    def create_customer_and_invoice_of_amazon_without_so(self):
        if self.xls_file:
            self = self.with_context(amazon_import_order=True)
            work_book = self.read_xlx_file()
            _logger.info("============= Amazon FBA Import ================")
            for sheet in work_book._sheet_list:
                if work_book._sheet_list.index(sheet) != 0:
                    continue
                sheet_values = sheet._cell_values
                sheet_header = sheet_values[0]
                sheet_data = sheet_values[1:]
                if self.merchant_name=='amazon':
                    if not self.is_b2c:
                        if str(sheet_header[76]).lower() != 'bill to city' or str(sheet_header[77]).lower() != 'bill to state'\
                                or str(sheet_header[78]).lower() != 'bill to country' or str(sheet_header[79]).lower() != 'bill to postalcode'\
                                or str(sheet_header[80]).lower() != 'customer bill to gstid' or str(sheet_header[82]).lower() != 'buyer name':
                            _logger.info("Sheet Header Not Matched with the selected field")
                            raise ValidationError(_("Sheet Header Not Matched with the selected field"))
                        self.update_customer_amazon_fba(sheet_data)
                        self.env.cr.commit()
                    self.create_invoice_from_amazon_fba_sheet_without_so(sheet_data)
                else:
                    self.create_invoice_for_other_ecommerce_sheet_without_so(sheet_data)


    def create_invoice_for_other_ecommerce_sheet_without_so(self,sheet_data):
        """
                For the sheet invoice will create based on other ecommerce id and then order confirms validate and create credit note for that
        """
        _logger.info(" =========== create_invoice_for_other_ecommerce_sheet START ========== ")

        warehouse_id = self.warehouse_id
        if not warehouse_id:
            warehouse = int(self.env['ir.config_parameter'].sudo().get_param(
                'ul88_import_export.amazon_warehouse_id'))
            if warehouse:
                warehouse_id = self.env['stock.warehouse'].sudo().browse(warehouse)
        count = 0
        partner = False
        for correcting_data in sheet_data:
            if len(correcting_data) > 3:
                correcting_data[3] = str(correcting_data[3]).strip('.0') if str(correcting_data[3]).strip().find(
                    '.0') >= 0 else str(correcting_data[3]).strip()

        total_unique_other_ecommerce_order_ids = list(
            set([x[3] for x in list(filter(lambda x:str(x[3]).strip(), sheet_data))]))

        for othr_ecom_orders_id in total_unique_other_ecommerce_order_ids:
            shipment_orders = list(filter(lambda x:str(x[2]).strip().lower() == 'shipment' and str(
                x[3]).strip() == othr_ecom_orders_id, sheet_data))
            refund_orders = list(filter(lambda x:str(x[2]).strip().lower() == 'refund' and str(
                x[3]).strip() == othr_ecom_orders_id, sheet_data))

            for shipment_data in shipment_orders:
                try:
                    self.create_other_ecommerce_invoice_and_lines(shipment_data, warehouse_id, count)
                except Exception as e:
                    _logger.info("Exception occured in this create_other_ecommerce_invoice_and_lines: {}".format(e))

            for refund_data in refund_orders:
                try:
                    self.create_other_ecommerce_credit_note_and_lines(refund_data, warehouse_id, count)
                except Exception as e:
                    _logger.info("Exception occured in this create_other_ecommerce_credit_and_lines: {}".format(e))

            # call posting method to post inv and cred
            try:
                self.posting_invoice_and_credit_notes_other_ecommerce(othr_ecom_orders_id)
            except Exception as e:
                _logger.info("Some exception occurs while posting the inv or credit notes :{}".format(e))
                continue
    def posting_invoice_and_credit_notes_other_ecommerce(self, othr_ecom_orders_id):
        invoices = self.env['account.move'].sudo().search(
            [('type', '=', 'out_invoice'), ('amazon_order', '=', str(othr_ecom_orders_id).strip()),
             ('state', '=', 'draft')])
        credit_notes = self.env['account.move'].sudo().search(
            [('type', '=', 'out_refund'), ('amazon_order', '=', str(othr_ecom_orders_id).strip()),
             ('state', '=', 'draft')])
        # posting invoices
        for inv in invoices:
            try:
                inv.sudo().with_context(check_move_validity=False)._recompute_tax_lines()
                inv.sudo().with_context(check_move_validity=False)._move_autocomplete_invoice_lines_values()
                self.env.cr.commit()
                inv.with_context(check_move_validity=False).action_post()
                _logger.info("Posting invoice:{}".format(inv.name))
            except Exception as e:
                _logger.info("Exception occurs while posting invoice:{}".format(e))
                continue
        # posting_credit_notes
        for note in credit_notes:
            try:
                note.sudo().with_context(check_move_validity=False)._recompute_tax_lines()
                note.sudo().with_context(check_move_validity=False)._move_autocomplete_invoice_lines_values()
                self.env.cr.commit()
                note.with_context(check_move_validity=False).action_post()
                _logger.info("Posting credit note:{}".format(note.name))
            except Exception as e:
                _logger.info("Exception occurs while posting credit note:{}".format(e))
                continue
    def create_other_ecommerce_invoice_and_lines(self,data,warehouse_id,count):
        count += 1
        # if str(data[3]).strip().lower() not in ['shipment','cancel']:
        #     _logger.info("Skipping this row:{} because type doesn't match with this:{} ".format(count,'shipment'))
        #     continue
        # if str(data[80]).strip():
        if not self.is_b2c:
            partner = self.env['res.partner'].sudo().search([('vat','=',str(data[80]).strip())],limit=1)
        if self.is_b2c:
            partner = self.check_partner_exist_for_other_ecommerce_b2c(data)
        if partner:
            invoice = self.env['account.move'].sudo().search([('amazon_order','=',str(data[3]).strip()),('type','=','out_invoice')],limit=1)
            product = self.env['product.product'].sudo().search([('default_code','=',str(data[5]).strip())])
            # warehouse = self.env['stock.warehouse'].sudo().search([('id','=',14)])
            invoice_date = datetime.now().date()
            if type('') == type(data[1]):
                invoice_date = parser.parse(data[1])
            if type(1.00) == type(data[1]):
                invoice_date = datetime.utcfromtimestamp((data[1] - 25569) * 86400.0)
            if product and invoice:
                _logger.info("Invoice and Product = {}, {} ".format(invoice,product))
                line = invoice.invoice_line_ids.filtered(lambda x:x.product_id.default_code == str(data[5]).strip())
                if line:
                    _logger.info('Existing line found int the invoice with this sku:{}'.format(
                        str(data[5]).strip()))
                    if line.quantity < int(data[4]):
                        line.update({'quantity': line.quantity + int(data[4])})
                        self.env.cr.commit()
                if not line:
                    self.update_order_line_account_move_other_ecommerce(data, invoice, product,invoice_date)
            # order_date = datetime.strptime(data[2],'%Y-%m-%d %H:%M:%S')
            if partner and warehouse_id and not invoice:
                invoice_vals = {
                    # 'ref': self.client_order_ref or '',
                    'type': 'out_invoice',
                    'name': data[0] and str(data[0]).strip(),
                    'company_branch_id': warehouse_id.company_branch_id.id,
                    'date': invoice_date,
                    'invoice_date': invoice_date,
                    # 'narration': self.note,
                    # 'currency_id': self.pricelist_id.currency_id.id,
                    # 'campaign_id': self.campaign_id.id,
                    # 'medium_id': self.medium_id.id,
                    # 'source_id': self.source_id.id,
                    # 'user_id': self.user_id.id,
                    # 'invoice_user_id': self.user_id.id,
                    # 'team_id': self.team_id.id,
                    'partner_id': partner.id,
                    'amazon_order': str(data[3]).strip(),
                    'partner_shipping_id': partner.id,
                    # 'invoice_partner_bank_id': self.company_id.partner_id.bank_ids[:1].id,
                    # 'fiscal_position_id': self.fiscal_position_id.id or self.partner_invoice_id.property_account_position_id.id,
                    'journal_id': warehouse_id.l10n_in_sale_journal_id.id,  # company comes from the journal
                    # 'invoice_origin': self.name,
                    # 'invoice_payment_term_id': self.payment_term_id.id,
                    # 'invoice_payment_ref': self.reference,
                    # 'transaction_ids': [(6, 0, self.transaction_ids.ids)],
                    # 'invoice_line_ids': [],
                    # 'company_id': self.company_id.id,
                }
                invoice = self.env['account.move'].sudo().create(invoice_vals)
                if invoice:
                    _logger.info("Invoice created :{}".format(invoice))
                    self.env.cr.commit()
                    if product:
                        self.update_order_line_account_move_other_ecommerce(data, invoice, product, invoice_date)
                        invoice.invoice_line_ids.with_context(check_move_validity=False)._update_tax_id()
                        self.env.cr.commit()


    def create_other_ecommerce_credit_note_and_lines(self, data, warehouse_id, count):
        count += 1
        # if str(data[3]).strip().lower() not in ['shipment','cancel']:
        #     _logger.info("Skipping this row:{} because type doesn't match with this:{} ".format(count,'shipment'))
        #     continue
        # if str(data[80]).strip():
        if not self.is_b2c:
            partner = self.env['res.partner'].sudo().search([('vat', '=', str(data[80]).strip())],
                                                            limit=1)
        if self.is_b2c:
            partner = self.check_partner_exist_for_other_ecommerce_b2c(data)
        if partner:
            invoice = self.env['account.move'].sudo().search(
                [('amazon_order', '=', str(data[3]).strip()), ('type', '=', 'out_refund')],
                limit=1)
            product = self.env['product.product'].sudo().search(
                [('default_code', '=', str(data[5]).strip())])
            # warehouse = self.env['stock.warehouse'].sudo().search([('id','=',14)])
            invoice_date = datetime.now().date()
            if type('') == type(data[1]):
                invoice_date = parser.parse(data[1])
            if type(1.00) == type(data[1]):
                invoice_date = datetime.utcfromtimestamp((data[1] - 25569) * 86400.0)
            if product and invoice:
                _logger.info("Invoice and Product = {}, {} ".format(invoice, product))
                line = invoice.invoice_line_ids.filtered(
                    lambda x: x.product_id.default_code == str(data[5]).strip())
                if line:
                    _logger.info('Existing line found int the invoice with this sku:{}'.format(
                        str(data[5]).strip()))
                    if line.quantity < int(data[4]):
                        line.update({'quantity': line.quantity + int(data[4])})
                        self.env.cr.commit()
                if not line:
                    self.update_order_line_account_move_other_ecommerce(data, invoice, product, invoice_date)
            # order_date = datetime.strptime(data[2],'%Y-%m-%d %H:%M:%S')
            if partner and warehouse_id and not invoice:
                invoice_vals = {
                    # 'ref': self.client_order_ref or '',
                    'type': 'out_refund',
                    'name': data[0] and str(data[0]).strip(),
                    'company_branch_id': warehouse_id.company_branch_id.id,
                    'date': invoice_date,
                    'invoice_date': invoice_date,
                    # 'narration': self.note,
                    # 'currency_id': self.pricelist_id.currency_id.id,
                    # 'campaign_id': self.campaign_id.id,
                    # 'medium_id': self.medium_id.id,
                    # 'source_id': self.source_id.id,
                    # 'user_id': self.user_id.id,
                    # 'invoice_user_id': self.user_id.id,
                    # 'team_id': self.team_id.id,
                    'partner_id': partner.id,
                    'amazon_order': str(data[3]).strip(),
                    'partner_shipping_id': partner.id,
                    # 'invoice_partner_bank_id': self.company_id.partner_id.bank_ids[:1].id,
                    # 'fiscal_position_id': self.fiscal_position_id.id or self.partner_invoice_id.property_account_position_id.id,
                    'journal_id': warehouse_id.l10n_in_sale_journal_id.id,
                    # company comes from the journal
                    # 'invoice_origin': self.name,
                    # 'invoice_payment_term_id': self.payment_term_id.id,
                    # 'invoice_payment_ref': self.reference,
                    # 'transaction_ids': [(6, 0, self.transaction_ids.ids)],
                    # 'invoice_line_ids': [],
                    # 'company_id': self.company_id.id,
                }
                invoice = self.env['account.move'].sudo().create(invoice_vals)
                if invoice:
                    _logger.info("Invoice created :{}".format(invoice))
                    self.env.cr.commit()
                    if product:
                        self.update_order_line_account_move_other_ecommerce(data, invoice, product, invoice_date)
                        invoice.invoice_line_ids.with_context(
                            check_move_validity=False)._update_tax_id()
                        self.env.cr.commit()
    def update_order_line_account_move_other_ecommerce(self,data,invoice,product,invoice_date):
        _logger.info("===== update_order_line START ======== {}".format(data))
        line_values = {
            # 'display_type': self.display_type,
            # 'sequence': self.sequence,
            # 'name': self.name,
            'date': invoice_date,
            'product_id': product.id,
            'product_uom_id': product.uom_id.id,
            'quantity': int(data[4]),
            'move_id': invoice.id,
            # 'discount': self.discount,
            'price_unit': abs(float(data[9])),
            'company_branch_id': invoice.company_branch_id.id,
            'tax_ids': [(6, 0, product.taxes_id.filtered(lambda x:x.company_id.id == invoice.company_id.id).ids)],
            # 'analytic_account_id': self.order_id.analytic_account_id.id if not self.display_type else False,
            # 'analytic_tag_ids': [(6, 0, self.analytic_tag_ids.ids)],
            # 'sale_line_ids': [(4, self.id)],
        }
        # if not self.is_b2c:
        #     line_values.update({'tax_id': tax})
        invoice.write({'invoice_line_ids': [(0, 0, line_values)]})
        self.env.cr.commit()
        _logger.info("===== update_order_line END ======== {}".format(line_values))

    # ================ flipkart,meesho,tatacliq,indiamart,jiomart flow without SO End ========================



    def create_invoice_from_amazon_fba_sheet_without_so(self,sheet_data):
        """
        For the sheet sale order will create based on amazon order id and then order confirms validate and create invoice for that
        """
        # type = ['Shipment','cancel','refund']
        _logger.info(" =========== create_invoice_from_amazon_fba_sheet_without_so START ========== ")
        warehouse_id = self.warehouse_id
        if not warehouse_id:
            warehouse = int(self.env['ir.config_parameter'].sudo().get_param(
                'ul88_import_export.amazon_warehouse_id'))
            if warehouse:
                warehouse_id = self.env['stock.warehouse'].sudo().browse(warehouse)
        count = 0
        total_unique_amazon_order_ids = list(set([x[4] for x in list(filter(lambda x: str(x[4]).strip(), sheet_data))]))
        for amazon_order_id in total_unique_amazon_order_ids:
        #     shipment and refund lines for each amazon_order_id
            shipment_orders = list(filter(lambda x:str(x[3]).strip().lower() == 'shipment' and amazon_order_id == str(x[4]).strip(),sheet_data))
            refund_orders = list(filter(lambda x:str(x[3]).strip().lower() == 'refund' and amazon_order_id == str(x[4]).strip(),sheet_data))
            for shipment_data in shipment_orders:
                try:
                    self.create_amazon_invoice_and_lines(shipment_data,warehouse_id,count)
                except Exception as e:
                    _logger.info(
                        "Exception occured in this create_amazon_invoice_and_lines: {}".format(e))
                    continue
            for refund_data in refund_orders:
                try:
                    self.create_amazon_credit_note_and_lines(refund_data,warehouse_id,count)
                except Exception as e:
                    _logger.info(
                        "Exception occured in this create_amazon_credit_note_and_lines: {}".format(e))
                    continue
            # call posting method to post inv and cred
            try:
                self.posting_invoice_and_credit_notes(amazon_order_id)
            except Exception as e:
                _logger.info("Some exception occurs while posting the inv or credit notes :{}".format(e))
                continue

        # shipment_data = list(filter(lambda x: str(x[3]).strip().lower() == 'shipment', sheet_data))
        # for data in shipment_data:
    def create_amazon_invoice_and_lines(self,data,warehouse_id,count):
        count += 1
        # if str(data[3]).strip().lower() not in ['shipment','cancel']:
        #     _logger.info("Skipping this row:{} because type doesn't match with this:{} ".format(count,'shipment'))
        #     continue
        # if str(data[80]).strip():
        if not self.is_b2c:
            partner = self.env['res.partner'].sudo().search([('vat','=',str(data[80]).strip())],limit=1)
        if self.is_b2c:
            partner = self.check_partner_exist_for_amazon_b2c(data)
        if partner:
            invoice = self.env['account.move'].sudo().search([('amazon_order','=',str(data[4]).strip()),('type','=','out_invoice')],limit=1)
            product = self.env['product.product'].sudo().search([('default_code','=',str(data[13]).strip())])
            # warehouse = self.env['stock.warehouse'].sudo().search([('id','=',14)])
            invoice_date = datetime.now().date()
            if type('') == type(data[2]):
                invoice_date = parser.parse(data[2])
            if type(1.00) == type(data[2]):
                invoice_date = datetime.utcfromtimestamp((data[2] - 25569) * 86400.0)
            if product and invoice:
                _logger.info("Invoice and Product = {}, {} ".format(invoice,product))
                line = invoice.invoice_line_ids.filtered(lambda x:x.product_id.default_code == str(data[13]).strip())
                if line:
                    _logger.info('Existing line found int the invoice with this sku:{}'.format(
                        str(data[13]).strip()))
                    if line.quantity < int(data[9]):
                        line.update({'quantity': line.quantity + int(data[9])})
                        self.env.cr.commit()
                if not line:
                    self.update_order_line_account_move(data, invoice, product,invoice_date)
            # order_date = datetime.strptime(data[2],'%Y-%m-%d %H:%M:%S')
            if partner and warehouse_id and not invoice:
                invoice_vals = {
                    # 'ref': self.client_order_ref or '',
                    'type': 'out_invoice',
                    'name': data[1] and str(data[1]).strip(),
                    'company_branch_id': warehouse_id.company_branch_id.id,
                    'date': invoice_date,
                    'invoice_date': invoice_date,
                    # 'narration': self.note,
                    # 'currency_id': self.pricelist_id.currency_id.id,
                    # 'campaign_id': self.campaign_id.id,
                    # 'medium_id': self.medium_id.id,
                    # 'source_id': self.source_id.id,
                    # 'user_id': self.user_id.id,
                    # 'invoice_user_id': self.user_id.id,
                    # 'team_id': self.team_id.id,
                    'partner_id': partner.id,
                    'amazon_order': str(data[4]).strip(),
                    'partner_shipping_id': partner.id,
                    # 'invoice_partner_bank_id': self.company_id.partner_id.bank_ids[:1].id,
                    # 'fiscal_position_id': self.fiscal_position_id.id or self.partner_invoice_id.property_account_position_id.id,
                    'journal_id': warehouse_id.l10n_in_sale_journal_id.id,  # company comes from the journal
                    # 'invoice_origin': self.name,
                    # 'invoice_payment_term_id': self.payment_term_id.id,
                    # 'invoice_payment_ref': self.reference,
                    # 'transaction_ids': [(6, 0, self.transaction_ids.ids)],
                    # 'invoice_line_ids': [],
                    # 'company_id': self.company_id.id,
                }
                invoice = self.env['account.move'].sudo().create(invoice_vals)
                if invoice:
                    _logger.info("Invoice created :{}".format(invoice))
                    self.env.cr.commit()
                    if product:
                        self.update_order_line_account_move(data, invoice, product, invoice_date)
                        # invoice.invoice_line_ids.with_context(check_move_validity=False)._update_tax_id()
                        # self.env.cr.commit()

    def create_amazon_credit_note_and_lines(self, data, warehouse_id, count):
        count += 1
        # if str(data[3]).strip().lower() not in ['shipment','cancel']:
        #     _logger.info("Skipping this row:{} because type doesn't match with this:{} ".format(count,'shipment'))
        #     continue
        # if str(data[80]).strip():
        if not self.is_b2c:
            partner = self.env['res.partner'].sudo().search([('vat', '=', str(data[80]).strip())],
                                                            limit=1)
        if self.is_b2c:
            partner = self.check_partner_exist_for_amazon_b2c(data)
        if partner:
            invoice = self.env['account.move'].sudo().search(
                [('amazon_order', '=', str(data[4]).strip()), ('type', '=', 'out_refund')],
                limit=1)
            product = self.env['product.product'].sudo().search(
                [('default_code', '=', str(data[13]).strip())])
            # warehouse = self.env['stock.warehouse'].sudo().search([('id','=',14)])
            invoice_date = datetime.now().date()
            if type('') == type(data[2]):
                invoice_date = parser.parse(data[2])
            if type(1.00) == type(data[2]):
                invoice_date = datetime.utcfromtimestamp((data[2] - 25569) * 86400.0)
            if product and invoice:
                _logger.info("Invoice and Product = {}, {} ".format(invoice, product))
                line = invoice.invoice_line_ids.filtered(
                    lambda x: x.product_id.default_code == str(data[13]).strip())
                if line:
                    _logger.info('Existing line found int the invoice with this sku:{}'.format(
                        str(data[13]).strip()))
                    if line.quantity < int(data[9]):
                        line.update({'quantity': line.quantity + int(data[9])})
                        self.env.cr.commit()
                if not line:
                    self.update_order_line_account_move(data, invoice, product, invoice_date)
            # order_date = datetime.strptime(data[2],'%Y-%m-%d %H:%M:%S')
            if partner and warehouse_id and not invoice:
                invoice_vals = {
                    # 'ref': self.client_order_ref or '',
                    'type': 'out_refund',
                    'name': data[1] and str(data[1]).strip(),
                    'company_branch_id': warehouse_id.company_branch_id.id,
                    'date': invoice_date,
                    'invoice_date': invoice_date,
                    # 'narration': self.note,
                    # 'currency_id': self.pricelist_id.currency_id.id,
                    # 'campaign_id': self.campaign_id.id,
                    # 'medium_id': self.medium_id.id,
                    # 'source_id': self.source_id.id,
                    # 'user_id': self.user_id.id,
                    # 'invoice_user_id': self.user_id.id,
                    # 'team_id': self.team_id.id,
                    'partner_id': partner.id,
                    'amazon_order': str(data[4]).strip(),
                    'partner_shipping_id': partner.id,
                    # 'invoice_partner_bank_id': self.company_id.partner_id.bank_ids[:1].id,
                    # 'fiscal_position_id': self.fiscal_position_id.id or self.partner_invoice_id.property_account_position_id.id,
                    'journal_id': warehouse_id.l10n_in_sale_journal_id.id,
                    # company comes from the journal
                    # 'invoice_origin': self.name,
                    # 'invoice_payment_term_id': self.payment_term_id.id,
                    # 'invoice_payment_ref': self.reference,
                    # 'transaction_ids': [(6, 0, self.transaction_ids.ids)],
                    # 'invoice_line_ids': [],
                    # 'company_id': self.company_id.id,
                }
                invoice = self.env['account.move'].sudo().create(invoice_vals)
                if invoice:
                    _logger.info("Invoice created :{}".format(invoice))
                    self.env.cr.commit()
                    if product:
                        self.update_order_line_account_move(data, invoice, product, invoice_date)
                        invoice.invoice_line_ids.with_context(
                            check_move_validity=False)._update_tax_id()
                        self.env.cr.commit()

    def posting_invoice_and_credit_notes(self, amazon_order_id):
        invoices = self.env['account.move'].sudo().search(
            [('type', '=', 'out_invoice'), ('amazon_order', '=', str(amazon_order_id).strip()),
             ('state', '=', 'draft')])
        credit_notes = self.env['account.move'].sudo().search(
            [('type', '=', 'out_refund'), ('amazon_order', '=', str(amazon_order_id).strip()),
             ('state', '=', 'draft')])
        # posting invoices
        for inv in invoices:
            try:
                inv.sudo().with_context(check_move_validity=False)._recompute_tax_lines()
                inv.sudo().with_context(check_move_validity=False)._move_autocomplete_invoice_lines_values()
                self.env.cr.commit()
                inv.with_context(check_move_validity=False).action_post()
                _logger.info("Posting invoice:{}".format(inv.name))
            except Exception as e:
                _logger.info("Exception occurs while posting invoice:{}".format(e))
                continue
        # posting_credit_notes
        for note in credit_notes:
            try:
                note.sudo().with_context(check_move_validity=False)._recompute_tax_lines()
                note.sudo().with_context(check_move_validity=False)._move_autocomplete_invoice_lines_values()
                self.env.cr.commit()
                note.with_context(check_move_validity=False).action_post()
                _logger.info("Posting credit note:{}".format(note.name))
            except Exception as e:
                _logger.info("Exception occurs while posting credit note:{}".format(e))
                continue
    def update_order_line_account_move(self,data,invoice,product,invoice_date):
        _logger.info("===== update_order_line START ======== {}".format(data))
        line_values = {
            # 'display_type': self.display_type,
            # 'sequence': self.sequence,
            # 'name': self.name,
            'date': invoice_date,
            'product_id': product.id,
            'product_uom_id': product.uom_id.id,
            'quantity': int(data[9]),
            'move_id': invoice.id,
            # 'discount': self.discount,
            'price_unit': abs(float(data[28])),
            'company_branch_id': invoice.company_branch_id.id,
            'tax_ids': [(6, 0, product.taxes_id.filtered(lambda x:x.company_id.id == invoice.company_id.id).ids)],
            # 'analytic_account_id': self.order_id.analytic_account_id.id if not self.display_type else False,
            # 'analytic_tag_ids': [(6, 0, self.analytic_tag_ids.ids)],
            # 'sale_line_ids': [(4, self.id)],
        }
        # if not self.is_b2c:
        #     line_values.update({'tax_id': tax})
        invoice.write({'invoice_line_ids': [(0, 0, line_values)]})
        invoice.invoice_line_ids.with_context(check_move_validity=False)._update_tax_id()
        self.env.cr.commit()
        _logger.info("===== update_order_line END ======== {}".format(line_values))

    # ================ Amazon flow without SO End ========================

    def update_customer_amazon_fba(self,sheet_data):
        count = 0
        for data in sheet_data:
            try:
                count += 1
                if not data[80]:
                    _logger.info("Skipping this row:{} because Gst number not found at this row".format(count))
                    continue
                if data[80]:
                    partner = self.env['res.partner'].sudo().search([('vat','=',str(data[80]).strip())])
                    if partner:
                        if not partner.is_amazon_contact:
                            partner.is_amazon_contact = True
                        _logger.info("Row:{}, Partner found with this {} gst number:{}".format(count,partner.name,partner.vat))
                        continue
                    if not partner:
                        _logger.info("Row:{}, Partner not found with this {} gst number:{}".format(count,data[80],data[82]))
                        _logger.info("======== Creating new partner ==========")
                        state_id = False
                        country_id = False
                        if not data[82]:
                            _logger.info("Skipping this row {} because customer name not there".format(count))
                        if data[82]:
                            country = str(data[78]).strip() if data[78] else False
                            if country:
                                country_id = self.env['res.country'].sudo().search([('code','=',country)],limit=1).id
                                if country_id:
                                    state = str(data[77]).strip() if data[77] else False
                                    if state:
                                        state_id = self.env['res.country.state'].sudo().search([
                                            ('name','ilike',state),('country_id','=',country_id)]).id
                            # prozo_city = self.env['prozo.city'].sudo().search(
                            #     [('name', 'ilike', str(data[76]).strip() if data[76] else '')])
                            customer_category = self.env['user.type'].sudo().search([('name','=','AMAZON E COMMERCE')],limit=1)
                            customer_category_lst = [1]
                            if customer_category:
                                customer_category_lst = [customer_category.id]
                            partner_vals = {
                                'name':str(data[82]).strip(),
                                'vat': str(data[80]).strip(),
                                'city': str(data[76]).strip() if data[76] else '',
                                'zip': int(data[79]) if data[79] else '',
                                'state_id': state_id,
                                'country_id': country_id,
                                'is_amazon_contact': True,
                                'partner_type':'B2B',
                                # 'prozo_city_id':prozo_city.ids[0] if prozo_city else False,
                                'user_type_ids':[(6,0,customer_category_lst)]  # AMAZON E COMMERCE
                            }
                            partner = self.env['res.partner'].sudo().create(partner_vals)
                            _logger.info("Partner created at this row:{} with values:{}".format(count,partner_vals))
            except Exception as e:
                _logger.info("Exception occured while updating product details:{}".format(e))
                continue

    def check_partner_exist_for_amazon_b2c(self,data):
        # now implemented state wise b2c customers
        _logger.info("===== check_partner_exist_for_amazon_b2c START =====")
        partner = False
        country = str(data[25]).strip() if data[25] else False
        state = str(data[24]).strip() if data[24] else False
        if country:
            country_id = self.env['res.country'].sudo().search([('code', '=', country)], limit=1)
            if country_id and state:
                if state:
                    state_id = self.env['res.country.state'].sudo().search([
                        ('name', 'ilike', state), ('country_id', '=', country_id.id)],limit=1)
                    if state_id:
                        partner = self.env['res.partner'].sudo().search([
                            ('is_amazon_contact','=',True),('is_amazon_b2c_customer','=',True),('state_id','=',state_id.id)]
                            ,limit=1)
                    if partner:
                        _logger.info("Existing partner found:{}->{}".format(partner.name,partner.id))
                        return partner
                    if not partner:
                        prozo_city = self.env['prozo.city'].sudo().search(
                            [('name', 'ilike', str(data[23]).strip() if data[23] else '')])
                        customer_category = self.env['user.type'].sudo().search([('name', '=', 'AMAZON E COMMERCE')],
                                                                                limit=1)
                        customer_category_lst = [1]
                        if customer_category:
                            customer_category_lst = [customer_category.id]
                        partner_vals = {
                            'name': 'Amazon FBA B2C {}'.format(state_id.name),
                            'city': str(data[23]).strip() if data[23] else '',
                            'state_id': state_id.id,
                            'country_id': country_id.id,
                            'is_amazon_contact': True,
                            'is_amazon_b2c_customer': True,
                            # 'partner_type': 'B2B', # No option for amazon Fba B2C
                            'prozo_city_id': prozo_city.ids[0] if prozo_city else False,
                            'user_type_ids':[(6,0,customer_category_lst)]  # AMAZON E COMMERCE
                        }
                        partner = self.env['res.partner'].sudo().create(partner_vals)
                        _logger.info("New Partner Created:{}->{}".format(partner.name,partner.id))
                        return partner
        return partner

    def create_invoice_from_amazon_fba_sheet(self,sheet_data):
        """
        For the sheet sale order will create based on amazon order id and then order confirms validate and create invoice for that
        """
        # type = ['Shipment','cancel','refund']
        _logger.info(" =========== create_invoice_from_amazon_fba_sheet START ========== ")
        warehouse_id = self.warehouse_id
        if not warehouse_id:
            warehouse = int(self.env['ir.config_parameter'].sudo().get_param(
                'ul88_import_export.amazon_warehouse_id'))
            if warehouse:
                warehouse_id = self.env['stock.warehouse'].sudo().browse(warehouse)
        count = 0
        shipment_data = list(filter(lambda x: str(x[3]).strip().lower() == 'shipment' or 'cancel', sheet_data))
        for data in shipment_data:
            try:
                count += 1
                if str(data[3]).strip().lower() not in ['shipment','cancel']:
                    _logger.info("Skipping this row:{} because type doesn't match with this:{} ".format(count,'shipment'))
                    continue
                # if str(data[80]).strip():
                if not self.is_b2c:
                    partner = self.env['res.partner'].sudo().search([('vat','=',str(data[80]).strip())],limit=1)
                if self.is_b2c:
                    partner = self.check_partner_exist_for_amazon_b2c(data)
                if partner:
                    sale_order = self.env['sale.order'].sudo().search([('amazon_order','=',str(data[4]).strip())],limit=1)
                    product = self.env['product.product'].sudo().search([('default_code','=',str(data[13]).strip())])
                    if sale_order and product:
                        _logger.info("sale_order and Product = {}, {} ".format(sale_order,product))
                        line = sale_order.order_line.filtered(lambda x:x.product_id.default_code == str(data[13]).strip())
                        if line:
                            _logger.info('Existing line found int the sale order with this sku:{}'.format(
                                str(data[13]).strip()))
                            if line.product_uom_qty < int(data[9]):
                                line.update({'product_uom_qty': line.product_uom_qty + int(data[9])})
                                self.env.cr.commit()
                        if not line:
                            self.update_order_line(data, sale_order, product)
                    # warehouse = self.env['stock.warehouse'].sudo().search([('id','=',14)])
                    order_date = datetime.now().date()
                    if type('') == type(data[2]):
                        order_date = parser.parse(data[2])
                    if type(1.00) == type(data[2]):
                        order_date = datetime.utcfromtimestamp((data[2] - 25569) * 86400.0)
                    # order_date = datetime.strptime(data[2],'%Y-%m-%d %H:%M:%S')
                    if partner and warehouse_id and not sale_order:
                        order_vals = {
                            'partner_id': partner.id,
                            'partner_invoice_id': partner.id,
                            'partner_shipping_id': partner.id,
                            'warehouse_id': warehouse_id.id,
                            'company_branch_id': warehouse_id.company_branch_id.id,
                            'company_id': self.env.user.company_id.id,
                            'team_id': self.env['crm.team'].sudo().search([('company_id','=',self.env.user.company_id.id)],limit=1).id,
                            # 'team_id': self.env['website'].search([], limit=1).crm_default_team_id.id,
                            'date_order': order_date.date() if order_date else datetime.now(),
                            'origin':data[1], # storing this invoice name in sale order bcoz easy to update in invoice later
                            'amazon_order': str(data[4]).strip(),
                            'is_amazon_order': True,
                            'l10n_in_journal_id': warehouse_id.l10n_in_sale_journal_id.id,
                        }
                        sale_order = self.env['sale.order'].sudo().create(order_vals)
                        if sale_order:
                            _logger.info("sale order created :{}".format(sale_order))
                            self.env.cr.commit()
                            if product:
                                self.update_order_line(data, sale_order, product)
            except Exception as e:
                _logger.info("Exception occured in this create_invoice_from_amazon_fba_sheet: {}".format(e))
                continue
        # ======== Cancelling the order ===============
        cancel_data = list(filter(lambda x: str(x[3]).strip().lower() == 'cancel', sheet_data))
        for data in cancel_data:
            sale_order_to_cancel = self.env['sale.order'].sudo().search([('is_amazon_order','=',True),('amazon_order','=',str(data[4]).strip())],limit=1)
            if sale_order_to_cancel and sale_order_to_cancel.state != 'cancel':
                sale_order_to_cancel.write({'state':'cancel'})
                self.env.cr.commit()
                _logger.info("Sale Order Cancelled:{} with this amazon order id:{}".format(sale_order_to_cancel.name,str(data[4]).strip()))
        # ==============================================
        # ===== Now Confirming the order and Validating and then create invoice =====
        amazon_order_ids = list(set([str(data[4]).strip() for data in shipment_data]))
        for amazon_order_id in amazon_order_ids:
            amazon_sale_order = self.env['sale.order'].sudo().search([('is_amazon_order','=',True),
                                                                      ('amazon_order','=',amazon_order_id)],limit=1)
            if amazon_sale_order:
                try:
                    if amazon_sale_order.state in ['draft', 'sent']:
                        amazon_sale_order.action_confirm()
                        self.env.cr.commit()
                        _logger.info("=== Amazon Sale Order Confirmed :{} ===".format(amazon_sale_order.name))
                    picking = amazon_sale_order.picking_ids.filtered(lambda x:x.state not in ['done','cancel'])
                    if picking:
                        picking.action_assign()
                        wiz = self.env['stock.immediate.transfer'].create({'pick_ids': [(4, picking.id)]})
                        wiz.process()
                        self.env.cr.commit()
                        _logger.info("Picking Process:{} ,state:{}, sale:{}".format(picking.name,picking.state
                                                                                     ,amazon_sale_order.name))
                    if picking.state == 'done':
                        invoice = picking.sale_id._create_invoices()
                        self.env.cr.commit()
                        _logger.info("Invoice Generated for this sale order:{} ".format(amazon_sale_order.name))
                        if invoice:
                            # invoice_date = amazon_sale_order.date_order
                            # if type('') == type(data[2]):
                            #     invoice_date = parser.parse(data[2])
                            # if type(1.00) == type(data[2]):
                            #     invoice_date = datetime.utcfromtimestamp((data[2] - 25569) * 86400.0)
                            invoice.update({'name':amazon_sale_order.origin,'invoice_date':amazon_sale_order.date_order})
                            # invoice.with_context(check_move_validity=False)._onchange_invoice_date()
                            invoice.invoice_line_ids.with_context(check_move_validity=False).write(
                                {'date': amazon_sale_order.date_order})
                            invoice.action_post()
                except Exception as e:
                    _logger.info("Exception occured while confirming order, validating delivery or createing invoice :{}".format(e))
                    continue
        # ====================================
        # =========== Refund =================
        refund_data = list(filter(lambda x: str(x[3]).strip().lower() == 'refund', sheet_data))
        refund_orders_lst = list(set([str(data[4]).strip() for data in refund_data]))
        for data in refund_orders_lst:
            refund_order_sheet_data = list(filter(lambda x: str(x[4]).strip() == data, refund_data))
        # for data in refund_order_sheet_data:
            try:
                sale_order = False
                if str(refund_order_sheet_data[0][3]).strip().lower() == 'refund':
                    sale_order = self.env['sale.order'].sudo().search([('amazon_order', '=', str(refund_order_sheet_data[0][4]).strip())],
                                                                      limit=1)
                    product = self.env['product.product'].sudo().search([('default_code', '=', str(refund_order_sheet_data[0][13]).strip())],
                                                                        limit=1)
                    return_picking = self.env['stock.picking'].sudo().search([('note','=','{}-{}'.format(
                        str(refund_order_sheet_data[0][4]).strip(),product.id))])
                    if sale_order and sale_order.picking_ids and sale_order.picking_ids.filtered(
                            lambda x:x.picking_type_code == 'outgoing')[0].state == 'done' and product and not return_picking:
                    #  create return and create credit note for this order
                        return_wiz = self.env['stock.return.picking'].sudo().create({
                            'picking_id': sale_order.picking_ids.filtered(
                            lambda x:x.picking_type_code == 'outgoing')[0].id
                        })
                        return_wiz._onchange_picking_id()
                        self.env.cr.commit()
                        if return_wiz:
                            products = self.env['product.product'].sudo().search([('default_code','in',[str(data[13]).strip() for data in refund_order_sheet_data])],limit=1)
                            if products:
                                lines = []
                                for product in products:
                                    line = return_wiz.product_return_moves.filtered(lambda x:x.product_id.id in products.ids)
                                    if line:
                                        lines.append(line.id)
                                        qty = list(filter(lambda x: str(x[13]).strip() == product.default_code, refund_order_sheet_data))[0][9]
                                        line.write({'quantity':qty if qty else line.quantity})
                                # unlink other lines
                                for line in return_wiz.product_return_moves:
                                    if line.id not in lines:
                                        line.unlink()
                                        self.env.cr.commit()
                            return_created = return_wiz.create_returns()
                            if return_created and return_created.get('res_id',False):
                                return_picking = self.env['stock.picking'].sudo().browse(return_created.get('res_id',False))
                                if return_picking:
                                    return_picking.write({'note': '{}-{}'.format(data,product.id)})
                                    wiz = self.env['stock.immediate.transfer'].create({'pick_ids': [(4, return_picking.id)]})
                                    wiz.process()
                                    self.env.cr.commit()
                                    _logger.info("Refund return transfer creating and validating transfer:{}".format(return_picking.name,return_picking.state))
                        self.env.cr.commit()
            except Exception as e:
                _logger.info("Exception occurs while creating refund transfer:{}".format(e))
                continue
        # =========== credit note =================
        credit_notes_record = list(filter(lambda x: str(x[3]).strip().lower() == 'refund', sheet_data))
        credit_notes_ids = []
        for data in credit_notes_record:
            try:
                partner = False
                if not self.is_b2c:
                    partner = self.env['res.partner'].sudo().search([('vat', '=', str(data[80]).strip())])
                if self.is_b2c:
                    partner = self.check_partner_exist_for_amazon_b2c(data)
                sale_order = self.env['sale.order'].sudo().search([('amazon_order', '=', str(data[4]).strip()),('state','in',['sale','done'])],
                                                                  limit=1)
                return_pickings =sale_order.picking_ids.filtered(lambda x:x.picking_type_code == 'incoming' and x.state in ['done'])
                product = self.env['product.product'].sudo().search([('default_code', '=', str(data[13]).strip())])
                if partner and sale_order and product and return_pickings:
                    credit_note = self.env['account.move'].sudo().search([('ref', '=', sale_order.amazon_order)], limit=1)
                    if not credit_note:
                        cdnr_date = sale_order.date_order
                        if type('') == type(data[2]):
                            cdnr_date = parser.parse(data[2])
                        if type(1.00) == type(data[2]):
                            cdnr_date = datetime.utcfromtimestamp((data[2] - 25569) * 86400.0)
                        invoice_vals = {
                            'partner_id':partner.id,
                            'date': cdnr_date,
                            'invoice_date':cdnr_date,
                            'invoice_date_due':cdnr_date,
                            'extract_state': 'no_extract_requested',
                            'journal_id': sale_order.warehouse_id.l10n_in_sale_journal_id.id,
                            'type': 'out_refund',
                            'l10n_in_export_type': 'regular',
                            'ref':sale_order.amazon_order,
                            'name':data[1] and str(data[1]).strip() or sale_order.origin,
                            'company_branch_id': sale_order.warehouse_id.company_branch_id.id,
                        }
                        credit_note = self.env['account.move'].sudo().create(invoice_vals)
                        self.env.cr.commit()
                    if credit_note:
                        # check it is posted or not if posted then do nthing and if not posted check for the product exist if not exist add a line
                        if credit_note.state == 'draft':
                            sale_line = sale_order.order_line.filtered(lambda x:x.product_id.id == product.id)
                            if sale_line and return_pickings[0].move_line_ids_without_package.filtered(
                                lambda x:x.product_id.id == product.id and x.state=='done') and not credit_note.invoice_line_ids.filtered(
                                lambda x:x.product_id == product):
                                line_vals = {
                                    'move_id': credit_note.id,
                                    'product_id': sale_line[0].product_id.id,
                                    'quantity': int(data[9]),
                                    'date': credit_note.invoice_date,
                                    'price_unit': sale_line[0].price_unit,
                                    'tax_ids': sale_line[0].tax_id.ids,
                                    'account_id': sale_order.l10n_in_journal_id.default_debit_account_id.id,
                                }
                                self.env['account.move.line'].sudo().with_context(check_move_validity=False).create(line_vals)
                                _logger.info("===== line inserted  in credit note ======:{} in this credit note:{}".format(line_vals,credit_note.name))
                                self.env.cr.commit()
                        if credit_note.state in ['posted','cancel']:
                            _logger.info("Credit note already exist:{}".format(credit_note.name))
                        credit_notes_ids.append(credit_note.id)
            except Exception as e:
                _logger.info("Exception occurs while creating credit note:{}".format(e))
                continue
        # posting_credit_notes
        if credit_notes_ids:
            credit_notes = self.env['account.move'].sudo().browse(credit_notes_ids)
            for note in credit_notes:
                try:
                    note.sudo().with_context(check_move_validity=False)._recompute_tax_lines()
                    note.sudo().with_context(check_move_validity=False)._move_autocomplete_invoice_lines_values()
                    self.env.cr.commit()
                    note.with_context(check_move_validity=False).action_post()
                    _logger.info("Posting credit_note:{}".format(note.name))
                except Exception as e:
                    _logger.info("Exception occurs while posting credit note:{}".format(e))
                    continue

    def split_text(self,s):
        for k, g in groupby(s, str.isalpha):
            yield ''.join(g)


    def update_order_line(self,data,sale_order,product):
        _logger.info("===== update_order_line START ======== {}".format(data))
        # commenting tax part because not needed as it is added from the other code
        # tax = []
        # if float(data[37]) > 0 or float(data[38]) > 0:
        #     #     cgst and sgst
        #     tax = product.taxes_id
        # if float(data[40]) > 0:
        #     #     igst tax_type=igst and type_tax_use=sale amount = vendor
        #     if product.taxes_id:
        #         alpha_num_tax = list(self.split_text(product.taxes_id[0].name))
        #     tax = self.env['account.tax'].sudo().search([('tax_type', '=', 'igst'),
        #                                                  ('type_tax_use', '=', 'sale'),
        #                                                  ('amount', '=', float(alpha_num_tax[-1])),
        #                                                  ('company_id','=',self.env.company.id)
        #                                                  ])
        line_values = {
            'order_id': sale_order.id,
            'product_id': product.id,
            'product_uom_qty': int(data[9]),
            'price_unit': float(data[28]),
        }
        # if not self.is_b2c:
        #     line_values.update({'tax_id': tax})
        sale_order.write({'order_line': [(0, 0, line_values)]})
        self.env.cr.commit()
        _logger.info("===== update_order_line END ======== {}".format(line_values))
