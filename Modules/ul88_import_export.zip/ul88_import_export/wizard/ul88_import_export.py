# -*- coding: utf-8 -*-
import io
import base64
from xlrd import open_workbook
from datetime import datetime
from odoo import api, fields, models, _
from odoo.tools.misc import xlsxwriter


class Ul88ImportExport(models.TransientModel):
    _name = "ul88.import.export"

    file_data = fields.Binary(string='Select File')
    file_name = fields.Char(string='File Name')

    from_date = fields.Date(string='From', help="Credit Note Date from")
    to_date = fields.Date(string='To', help="Credit Note Date to")
    detail_file = fields.Binary("File")
    sale_order_ids = fields.Many2many('sale.order', string='Sales Order')

    operation = fields.Selection([('export', 'Export'),
                            ('import', 'Import')], default='export', string='Operation')

    type = fields.Selection([('purchase', 'Purchase Order'),
                                ('sales', 'Sales Order'),
                                ('invoice', 'Invoice'),
                                ('bill', 'Bill'),
                                ('transfers','Transfers')], default='purchase', string='Type')

    picking_ids = fields.Many2many('stock.picking', string='Transfers')
    purchase_order_ids = fields.Many2many('purchase.order', string='Purchase Orders')
    invoice_ids = fields.Many2many('account.move', string='Invoices')
    partner_id = fields.Many2one('res.partner',string='Customer')

    @api.onchange('partner_id')
    def get_records_based_on_partner(self):
        domain = [('partner_id','=',self.partner_id.id),('partner_id','!=',False)]
        if self.type == 'purchase' and self.partner_id:
            po = self.env['purchase.order'].sudo().search(domain).ids
            return {'domain': {'purchase_order_ids': [('id', 'in', po)]}}
        elif self.type == 'sales' and self.partner_id:
            so = self.env['sale.order'].sudo().search(domain).ids
            return {'domain': {'sale_order_ids': [('id', 'in', so)]}}
        elif self.type == 'invoice' and self.partner_id:
            inv = self.env['account.move'].sudo().search(domain).ids
            return {'domain': {'invoice_ids': [('id', 'in', inv)]}}
        elif self.type == 'bill' and self.partner_id:
            bill = self.env['account.move'].sudo().search(domain).ids
            return {'domain': {'invoice_ids': [('id', 'in', bill)]}}
        elif self.type == 'transfers' and self.partner_id:
            transfers = self.env['stock.picking'].sudo().search(domain).ids
            return {'domain': {'picking_ids': [('id', 'in', transfers)]}}

    def import_order_invoice_bill_xlsx(self):
        """
        Import Order, Invoice and bills from XLSX
        :return:
        """
        if not self.file_data and self.operation == 'import':
            raise Warning(_("File not selected."))

        wb = open_workbook(file_contents=base64.decodestring(self.file_data))
        sheet = wb.sheet_by_index(0)
        datas = [[sheet.cell_value(r, c) for c in range(sheet.ncols)] for r in range(sheet.nrows)]
        datas.pop(0)
        datas.pop(0)
        for data in datas:
            if not data or not data[0] or not data[1]:
                continue

        return True

    def export_order_invoice_bill_xlsx_report(self):
        """
        generate invoice xlsx report
        :return:
        """
        if self.from_date and self.to_date and self.from_date > self.to_date:
            raise Warning(_("To date must be greater then from date"))

        output = io.BytesIO()
        workbook = xlsxwriter.Workbook(output, {'in_memory': True})
        if self.type == 'sales' and self.sale_order_ids:
            order_invoice_bill = self.sale_order_ids
        if self.type == 'purchase' and self.purchase_order_ids:
            order_invoice_bill = self.purchase_order_ids
        if self.type == 'invoice' and self.invoice_ids:
            order_invoice_bill = self.invoice_ids.filtered(lambda x:x.type == 'out_invoice')
        if self.type == 'bill' and self.invoice_ids:
            order_invoice_bill = self.invoice_ids.filtered(lambda x:x.type == 'in_invoice')
        if not self.sale_order_ids and not self.purchase_order_ids and not self.invoice_ids:
            order_invoice_bill = self.get_export_order_invoice_bill()
        # condition for the partner
        if self.partner_id:
            order_invoice_bill = order_invoice_bill.filtered(lambda x:x.partner_id == self.partner_id)
        sheet = workbook.add_worksheet("%s" % self.type)
        self.prepare_order_invoice_bill_xlsx_header(workbook, sheet)
        self.write_data_in_xlsx_sheet(order_invoice_bill, sheet, workbook)
        workbook.close()
        output.seek(0)
        output = base64.encodestring(output.read())
        self.write({'detail_file': output})
        filename = "ul88_export_{}_{}.xlsx".format(self.type, datetime.now().strftime('%d_%m_%y-%H:%M:%S'))
        return {
            'type': 'ir.actions.act_url',
            'url': 'web/content/?model=ul88.import.export&field=detail_file&download=true&id=%s&filename=%s' % (
                self.id, filename),
            'target': 'new',
        }

    def get_export_order_invoice_bill(self):
        """
        Get order, invoice and bills according to the date range which is selected on wizard
        :return:
        """
        if self.type in ('invoice', 'bill'):
            domain = [('invoice_date', '>=', self.from_date),
                      ('invoice_date', '<=', self.to_date)]
            invoice_type = 'out_invoice'
            if self.type == 'bill':
                invoice_type = 'in_invoice'
            domain.append(('type', '=', invoice_type))
            order_invoice_bill = self.env['account.move'].search(domain)

        elif self.type == 'transfers':
            domain = ['|','&',('date_done', '>=', self.from_date),
                      ('date_done', '<=', self.to_date),('id','in',self.picking_ids.ids)]
            order_invoice_bill = self.env['stock.picking'].search(domain)
        else:
            domain = [('date_order', '>=', self.from_date),
                      ('date_order', '<=', self.to_date)]
            if self.type == 'sales':
                order_invoice_bill = self.env['sale.order'].search(domain)
            else:
                order_invoice_bill = self.env['purchase.order'].search(domain)
        return order_invoice_bill

    def write_data_in_xlsx_sheet(self, order_invoice_bill, sheet, workbook):
        """
        Write Data in sheet
        :return:
        """
        row = 6
        row_data_style = workbook.add_format({'font_name': 'Arial'})
        row_total_style = workbook.add_format({'font_name': 'Arial', 'font_size': 11, 'bold': True, 'align': 'center'})
        for oib in order_invoice_bill:
            order_invoice_bill_date = ''
            if self.type in ('invoice', 'bill'):
                order_invoice_bill_lines = oib.invoice_line_ids
                if oib.invoice_date:
                    order_invoice_bill_date = str(oib.invoice_date)
            elif self.type == 'transfers':
                order_invoice_bill_lines = oib.move_ids_without_package
                order_invoice_bill_date = oib.date_done
                if order_invoice_bill_date:
                    order_invoice_bill_date = str(oib.date_done.date())
            else:
                order_invoice_bill_lines = oib.order_line
                if oib.date_order:
                    order_invoice_bill_date = str(oib.date_order.date())
            for line in order_invoice_bill_lines:
                sheet.write(row, 0, order_invoice_bill_date, row_data_style)
                sheet.write(row, 1, oib.name or '/', row_data_style)
                sheet.write(row, 2, oib.partner_id and oib.partner_id.name or '', row_data_style)
                sheet.write(row, 3, line.product_id and line.product_id.name or '', row_data_style)
                sheet.write(row, 4, line.product_id and line.product_id.default_code or '', row_data_style)
                sheet.write(row, 5, line.product_id and line.product_id.spa_item_code or '', row_data_style)
                sheet.write(row, 6, line.product_id and line.product_id.upc_barcode or '', row_data_style)
                sheet.write(row, 7, round(line.sale_line_id.price_unit, 2) if self.type == 'transfers' else round(line.price_unit, 2), row_data_style)
                sheet.write(row, 8, line.sale_line_id.discount if self.type == 'transfers' else getattr(line,'discount', 0), row_data_style)
                if self.type in ('invoice', 'bill'):
                    list_of_tax_name = [str(tax_name) for tax_name in set(line.tax_ids.mapped('name'))]
                    joined_string = ",".join(list_of_tax_name)
                elif self.type == 'transfers':
                    list_of_tax_name = [str(tax_name) for tax_name in set(line.sale_line_id.tax_id.mapped('name'))]
                    joined_string = ",".join(list_of_tax_name)
                else:
                    if self.type == 'purchase':
                        list_of_tax_name = [str(tax_name) for tax_name in set(line.taxes_id.mapped('name'))]
                        joined_string = ",".join(list_of_tax_name)
                    else:
                        list_of_tax_name = [str(tax_name) for tax_name in set(line.tax_id.mapped('name'))]
                        joined_string = ",".join(list_of_tax_name)

                sheet.write(row, 9, joined_string, row_data_style)
                if self.type == 'transfers':
                    sheet.write(row, 10, line.product_uom_qty, row_data_style)
                    sheet.write(row, 11, line.sale_line_id.price_subtotal, row_data_style)
                if self.type == 'purchase':
                    sheet.write(row, 10, line.product_qty, row_data_style)
                    sheet.write(row, 11, round(getattr(line, 'price_subtotal'), 2), row_data_style)
                if self.type == 'invoice' or self.type == 'bill':
                    sheet.write(row, 10, line.quantity, row_data_style)
                    sheet.write(row, 11, line.price_subtotal, row_data_style)
                    sheet.write(row, 12, line.price_total, row_data_style)
                    sheet.write(row, 13, oib.invoice_payment_term_id.name if oib.invoice_payment_term_id else '', row_data_style)

                if self.type == 'sales':
                    colour_string = size_string = ''
                    model_string = line.product_id.product_tmpl_id.style_code
                    # model_attribute_line = line.product_id.valid_product_template_attribute_line_ids.filtered(
                    #     lambda x: x.attribute_id.is_model)
                    # models_name = [str(model) for model in set(model_attribute_line.value_ids.mapped('name'))]
                    # model_string = ",".join(models_name)

                    colour_attribute_line = line.product_id.product_template_attribute_value_ids.filtered(
                        lambda x: x.attribute_id.is_colour)
                    if colour_attribute_line:
                        colour_string = colour_attribute_line.product_attribute_value_id[0].name
                    # colour_name = [str(colour) for colour in set(colour_attribute_line.value_ids.mapped('name'))]
                    # colour_string = ",".join(colour_name)

                    size_attribute_line = line.product_id.product_template_attribute_value_ids.filtered(
                        lambda x: x.attribute_id.is_size)
                    if size_attribute_line:
                        size_string = size_attribute_line.product_attribute_value_id[0].name
                    # size_name = [str(size) for size in set(size_attribute_line.value_ids.mapped('name'))]
                    # size_string = ",".join(size_name)

                    sheet.write(row, 11, line.product_uom_qty, row_data_style)
                    sheet.write(row, 12, line.qty_delivered, row_data_style)
                    sheet.write(row, 13, model_string, row_data_style)
                    sheet.write(row, 14, colour_string, row_data_style)
                    sheet.write(row, 15, size_string, row_data_style)
                    available_qty = line.product_id.with_context({'location': oib.warehouse_id.lot_stock_id.id}).qty_available
                    outgoing_qty = line.product_id.with_context({'location': oib.warehouse_id.lot_stock_id.id}).outgoing_qty
                    qty_available = available_qty - outgoing_qty
                    available = 'No'
                    if qty_available > 0:
                        available = 'Yes'
                    sheet.write(row, 16, available, row_data_style)
                    sheet.write(row, 17, line.product_id.mrp_price, row_data_style)
                    sheet.write(row, 18, oib.client_order_ref or '', row_data_style)
                    sheet.write(row, 19, oib.partner_shipping_id.name or '', row_data_style)
                    state = 'Quotation'
                    if oib.state == 'sent':
                        state = 'Quotation Sent'
                    elif oib.state == 'sale':
                        state = 'Sales Order'
                    elif oib.state == 'cancel':
                        state = 'Cancel'
                    elif oib.state == 'done':
                        state = 'Locked'
                    sheet.write(row, 20, state, row_data_style)

                row += 1
            if self.type == 'invoice' or self.type == 'bill':
                sheet.write(row, 0, 'Total', row_total_style)
                sheet.write(row, 12, oib.amount_total, row_total_style)
                row += 1

        return sheet

    def prepare_order_invoice_bill_xlsx_header(self, workbook, sheet):
        """
        Prepare XLSX header
        :param workbook:
        :param sheet:
        :return:
        """
        merge_super_col_style = workbook.add_format({'font_name': 'Arial', 'font_size': 11, 'bold': True, 'align': 'center'})

        super_col_style = workbook.add_format(
            {'font_name': 'Arial', 'font_size': 12, 'font_color': '#FFA500', 'bold': True})

        header = 'Invoice'
        date_from = str(self.from_date)
        date_to = str(self.to_date)
        if self.type == 'sales':
            header = 'Sales Order'
        elif self.type == 'purchase':
            header = 'Purchase Order'
        elif self.type == 'bill':
            header = 'Bill'
        elif self.type == 'transfers':
            header = 'Transfers'
        sheet.write(1, 0, 'Export : %s' % header, super_col_style)
        sheet.write(2, 0, 'From : %s' % date_from, super_col_style)
        sheet.write(3, 0, 'To : %s' % date_to, super_col_style)

        row = 5
        sheet.write(row, 0, 'Date', merge_super_col_style)
        sheet.write(row, 1, 'Number', merge_super_col_style)
        sheet.write(row, 2, 'Partner', merge_super_col_style)
        sheet.write(row, 3, 'Product', merge_super_col_style)
        sheet.write(row, 4, 'Reference Code', merge_super_col_style)
        sheet.write(row, 5, 'Item Code', merge_super_col_style)
        sheet.write(row, 6, 'Barcode', merge_super_col_style)
        sheet.write(row, 7, 'Unit Price', merge_super_col_style)
        sheet.write(row, 8, 'Discount (%)', merge_super_col_style)
        sheet.write(row, 9, 'Taxes', merge_super_col_style)
        sheet.write(row, 10, 'Subtotal', merge_super_col_style)
        if self.type == 'purchase':
            sheet.write(row, 10, 'Quantity', merge_super_col_style)
            sheet.write(row, 11, 'Subtotal', merge_super_col_style)
        if self.type == 'transfers':
            sheet.write(row, 10, 'Quantity', merge_super_col_style)
            sheet.write(row, 11, 'Subtotal', merge_super_col_style)
        if self.type == 'invoice' or self.type == 'bill':
            sheet.write(row, 10, 'Quantity', merge_super_col_style)
            sheet.write(row, 11, 'Untaxed Amount', merge_super_col_style)
            sheet.write(row, 12, 'Subtotal', merge_super_col_style)
            sheet.write(row, 13, 'Payment Term', merge_super_col_style)
        if self.type == 'sales':
            sheet.write(row, 11, 'Quantity', merge_super_col_style)
            sheet.write(row, 12, 'Delivered Quantity', merge_super_col_style)
            sheet.write(row, 13, 'Model', merge_super_col_style)
            sheet.write(row, 14, 'Colour', merge_super_col_style)
            sheet.write(row, 15, 'Size', merge_super_col_style)
            sheet.write(row, 16, 'Available', merge_super_col_style)
            sheet.write(row, 17, 'SRP', merge_super_col_style)
            sheet.write(row, 18, 'customer reference', merge_super_col_style)
            sheet.write(row, 19, 'Delivery address', merge_super_col_style)
            sheet.write(row, 20, 'Status', merge_super_col_style)
        return sheet
