/** @odoo-module **/

import { BlockUI } from "@web/core/ui/block_ui";
import { Component, useState, xml } from "@odoo/owl";

BlockUI.template = xml``;