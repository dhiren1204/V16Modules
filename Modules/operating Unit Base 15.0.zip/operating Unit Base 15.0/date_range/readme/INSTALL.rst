The addon use the daterange method from postgres. This method is supported as of postgresql 9.2
