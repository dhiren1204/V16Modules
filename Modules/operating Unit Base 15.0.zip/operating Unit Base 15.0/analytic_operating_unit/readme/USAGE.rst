* Go to 'Accounting / Configuration / Analytic Accounting / Analytic
  Accounts' and add the accepted Operating Units to each analytic account.

Analytic accounts with no Operating Unit assigned to them will be accessible
by all users with access to analytic accounts.
