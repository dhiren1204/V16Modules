This module add filter by operating units for all reports.
