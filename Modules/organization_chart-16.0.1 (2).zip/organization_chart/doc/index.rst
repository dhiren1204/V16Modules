Organization Chart | OrgChart | Org Chart | Employee Hierarchy | Employee Chart
===============================================================================
- This module allows the hr users to quickly view the Employee Hierarchy using the existing Employee master, 
    also the HR Manager will get the options for drag and drop, create , edit and delete options from the chart itself.

Installation
============
- Copy organization_chart module to addons folder
- Install the module normally like other modules.
