# -*- coding: utf-8 -*-

from . import sale_order
from . import crm_lead
from . import account_move
from . import stock_picking
from . import pos_config
from . import pos_order
from . import pos_session
from . import ir_action_report
from . import stock_location
