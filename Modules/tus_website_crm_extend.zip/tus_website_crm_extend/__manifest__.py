{
    'name': 'TUS Website CRM Extended',
    'version': '15.0.1.11',
    'summary': 'This Module contains Website CRM Extended',
    'category': 'crm',
    'author': "Techultra Solutions",
    'website': "https://techutility.co.uk/",
    'depends': ['crm', 'website_crm_partner_assign', 'base', 'sale_subscription_extended'],
    'data': [
        'security/web_crm_report_groups.xml',
        'security/ir.model.access.csv',
        'security/report_groups.xml',
        'data/company_number_cron.xml',
        'views/opportunity_template.xml',
        'views/crm_lead_to_opportunity_views_custom.xml',
        'views/users_views.xml',
        'views/res_partner_views.xml',
        'views/crm_lead_inherit.xml',
    ],
    'assets': {
        'web.assets_frontend': [
            'tus_website_crm_extend/static/src/**/*',
        ],
    },
    'license': 'LGPL-3',
    'installable': True,
    'application': True,
    'auto_install': False,
}
