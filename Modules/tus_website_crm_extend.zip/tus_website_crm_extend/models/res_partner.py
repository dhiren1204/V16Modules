from odoo import api, fields, models, _, Command

class ResPartner(models.Model):
    _inherit = 'res.partner'

    company_number = fields.Char(string="Company Number")


    def create_company(self):
        self.ensure_one()
        if self.company_name:
            # Create parent company
            values = dict(name=self.company_name, is_company=True, vat=self.vat)
            values.update(self._update_fields_values(self._address_fields()))
            if self._context.get('create_partner'):
                values.update({'company_number':self.company_number,
                               'email':self.email,
                               'phone':self.phone})
            new_company = self.create(values)
            # Set new company as my parent
            self.write({
                'parent_id': new_company.id,
                'child_ids': [Command.update(partner_id, dict(parent_id=new_company.id)) for partner_id in self.child_ids.ids]
            })
        return True

    def _cron_get_company_number(self):
        for rec in self.env['res.partner'].sudo().search([('x_studio_company_number', '!=', False),
                                                          ('company_number', '=', False),
                                                          ]):
            rec.write({'company_number': rec.x_studio_company_number})
        return True