from odoo import api, fields, models


class ResUserCustome(models.Model):
    _inherit = 'res.users'

    create_opportunity = fields.Boolean(
        string='Create Opportunity',
        required=False)
    all_opportunity = fields.Boolean(
        string='All Opportunity',
        required=False)
    sales_team_id = fields.Many2one(
        comodel_name='crm.team',
        string='Sale Team',
        required=False)
    package_requirement_ids = fields.Many2many(
        comodel_name='package.requirement',
        string='Package Requirements')
