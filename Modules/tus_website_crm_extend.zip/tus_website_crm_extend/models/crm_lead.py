from odoo import fields, models, api, _
import base64
from odoo.fields import Command

class Lead(models.Model):
    _inherit = 'crm.lead'

    user_id = fields.Many2one(
        'res.users', string='Salesperson', default=lambda self: self.env.user,
        domain="[('company_ids', 'in', user_company_ids)]",
        check_company=True, index=True, tracking=True)
    supply_address = fields.Boolean(string='Is Supply Address ?', default=True)
    supply_partner_id = fields.Many2one(string="Supply Address", comodel_name="res.partner")
    is_referral = fields.Boolean(string="Is Referral")
    month_broker_paid_date = fields.Date(string='Month Broker Paid')
    commission_payment = fields.Boolean(string='Commission Payment')
    deferred_amount = fields.Float(string="Deferred Amount")
    deferred_amount_due_date = fields.Date(string="Deferred Amount Due Date")
    deferred_amount_paid_date = fields.Date(string="Deferred Amount Paid Date")

    def update_client_details_from_portal(self, values):
        self.check_access_rights('write')
        return self.sudo().write(values)

    @api.model
    def create_opp_portal(self, values):
        user = self.env.user
        self = self.sudo()
        # if not (values['contact_name']):
        #     return {
        #         'errors': _('Name field is required !')
        #     }
        # if not (values['package_requirement_id']):
        #     return {
        #         'errors': _('Package Requirement field is required !')
        #     }
        opportunity_fields = {
            'registered_company_name': 'Registered Company Name', 'company_phone_number': 'Company Number',
            'street': 'Street', 'street2': 'Street 2', 'city': 'Town', 'state_id': 'County', 'zip': 'Postcode',
            'contact_name': 'Contact name', 'contact_phone_number': 'Contact Phone Number',
            'contact_email': 'Contact Email', 'package_requirement_id': 'Package Requirement'}
        for field in opportunity_fields:
            if not values[field]:
                return {
                    'errors': _(f'{opportunity_fields.get(field)} field is Required !')
                }
        if not values['same_as_above']:
            opp_supply_add_fields = {
                'supply_street': 'Street', 'supply_street2': 'Street 2', 'supply_city': 'Town',
                'supply_state_id': 'County', 'supply_zip': 'Postcode',
                }
            for field in opp_supply_add_fields:
                if not values[field]:
                    return {
                        'errors': _(f'Supply {opp_supply_add_fields.get(field)} field is Required !')
                    }

        lead_lst = []
        for rec in values:
            if rec.startswith('referral_contact_name'):
                key_name = rec
                result = rec.rsplit('_', 1)
                if len(result) > 1:
                    if len(lead_lst) == int(result[1]) + 1:
                        lead_lst[int(result[1])].update({'name': values.get(key_name) or False})
                    else:
                        lead_lst.append({'name': values.get(key_name) or False})

            if rec.startswith('referral_business_name'):
                key_name = rec
                result = rec.rsplit('_', 1)
                if len(result) > 1:
                    if len(lead_lst) == int(result[1]) + 1:
                        lead_lst[int(result[1])].update({'partner_name': values.get(key_name) or False})
                    else:
                        lead_lst.append({'partner_name': values.get(key_name) or False})

            if rec.startswith('referral_zip'):
                key_name = rec
                result = rec.rsplit('_', 1)
                if len(result) > 1:
                    if len(lead_lst) == int(result[1]) + 1:
                        lead_lst[int(result[1])].update({'zip': values.get(key_name) or False})
                    else:
                        lead_lst.append({'zip': values.get(key_name) or False})

            if rec.startswith('referral_email'):
                key_name = rec
                result = rec.rsplit('_', 1)
                if len(result) > 1:
                    if len(lead_lst) == int(result[1]) + 1:
                        lead_lst[int(result[1])].update({'email_from': values.get(key_name) or False})
                    else:
                        lead_lst.append({'email_from': values.get(key_name) or False})

            if rec.startswith('referral_mobile'):
                key_name = rec
                result = rec.rsplit('_', 1)
                if len(result) > 1:
                    if len(lead_lst) == int(result[1]) + 1:
                        lead_lst[int(result[1])].update({'phone': values.get(key_name) or False})
                    else:
                        lead_lst.append({'phone': values.get(key_name) or False})

            if rec.startswith('electricity'):
                key_name = rec
                result = rec.rsplit('_', 1)
                if len(result) > 1:
                    if len(lead_lst) == int(result[1]) + 1:
                        lead_lst[int(result[1])].update({'electric_submit': True if values.get(key_name) == 'true' else False})
                    else:
                        lead_lst.append({'electric_submit': True if values.get(key_name) == 'true' else False})

            if rec.startswith('gas'):
                key_name = rec
                result = rec.rsplit('_', 1)
                if len(result) > 1:
                    if len(lead_lst) == int(result[1]) + 1:
                        lead_lst[int(result[1])].update({'gas_submit': True if values.get(key_name) == 'true' else False})
                    else:
                        lead_lst.append({'gas_submit': True if values.get(key_name) == 'true' else False})

            if rec.startswith('water'):
                key_name = rec
                result = rec.rsplit('_', 1)
                if len(result) > 1:
                    if len(lead_lst) == int(result[1]) + 1:
                        lead_lst[int(result[1])].update({'water_submit': True if values.get(key_name) == 'true' else False})
                    else:
                        lead_lst.append({'water_submit': True if values.get(key_name) == 'true' else False})

            if rec.startswith('insurance'):
                key_name = rec
                result = rec.rsplit('_', 1)
                if len(result) > 1:
                    if len(lead_lst) == int(result[1]) + 1:
                        lead_lst[int(result[1])].update({'insurance_submit': True if values.get(key_name) == 'true' else False})
                    else:
                        lead_lst.append({'insurance_submit': True if values.get(key_name) == 'true' else False})

            if rec.startswith('phone'):
                key_name = rec
                result = rec.rsplit('_', 1)
                if len(result) > 1:
                    if len(lead_lst) == int(result[1]) + 1:
                        lead_lst[int(result[1])].update({'telco_submit': True if values.get(key_name) == 'true' else False})
                    else:
                        lead_lst.append({'telco_submit': True if values.get(key_name) == 'true' else False})

            if rec.startswith('waste'):
                key_name = rec
                result = rec.rsplit('_', 1)
                if len(result) > 1:
                    if len(lead_lst) == int(result[1]) + 1:
                        lead_lst[int(result[1])].update({'waste_submit': True if values.get(key_name) == 'true' else False})
                    else:
                        lead_lst.append({'waste_submit': True if values.get(key_name) == 'true' else False})

            if rec.startswith('merchant_services'):
                key_name = rec
                result = rec.rsplit('_', 1)
                if len(result) > 1:
                    if len(lead_lst) == int(result[1]) + 1:
                        lead_lst[int(result[1])].update({'ms_submit': True if values.get(key_name) == 'true' else False})
                    else:
                        lead_lst.append({'ms_submit': True if values.get(key_name) == 'true' else False})

            if rec.startswith('outsourced_human_resources'):
                key_name = rec
                result = rec.rsplit('_', 1)
                if len(result) > 1:
                    if len(lead_lst) == int(result[1]) + 1:
                        lead_lst[int(result[1])].update({'hr_submit': True if values.get(key_name) == 'true' else False})
                    else:
                        lead_lst.append({'hr_submit': True if values.get(key_name) == 'true' else False})

            if rec.startswith('description'):
                key_name = rec
                result = rec.rsplit('_', 1)
                if len(result) > 1:
                    if len(lead_lst) == int(result[1]) + 1:
                        lead_lst[int(result[1])].update({'description': True if values.get(key_name) == 'true' else False})
                    else:
                        lead_lst.append({'description': True if values.get(key_name) == 'true' else False})

        tag_own = self.env.ref('website_crm_partner_assign.tag_portal_lead_own_opp', False)
        # partner2 = self.env['res.partner'].create({'name':values['registered_company_name'],'company_type':'company'})
        partner = self.env['res.partner'].create(
            {'name':values['contact_name'],
             'company_name':values['registered_company_name'],
             'street': values['street'],
             'street2': values['street2'],
             'city': values['city'],
             'state_id': int(values['state_id']) if values['state_id'] else False,
             'zip': values['zip'],
             'country_id': self.env['res.country'].sudo().search([('code', '=', 'GB')], limit=1).id,
             'company_number': values['company_phone_number'],
             'email': values['contact_email'],
             'phone': values['contact_phone_number'],
             })
        partner.with_context(create_partner=True).create_company()
        # supply_partner_id = False
        if not values['same_as_above']:
            partner.write(
                {
                    'type': 'delivery',
                    'street': values['supply_street'],
                    'street2': values['supply_street2'],
                    'city': values['supply_city'],
                    'state_id': int(values['supply_state_id']) if values['supply_state_id'] else False,
                    'zip': values['supply_zip'],
                    'country_id': self.env['res.country'].sudo().search([('code', '=', 'GB')], limit=1).id,
                    # 'email': values['supply_contact_email'],
                    # 'phone': values['supply_contact_phone_number'],
            })

        values = {
            'contact_name': values['contact_name'],
            'name': values['registered_company_name'],
            # 'description': values['description'],
            'priority': '2',
            'street': values['street'],
            'street2': values['street2'],
            'city': values['city'],
            'state_id': int(values['state_id']) if values['state_id'] else False,
            'zip': values['zip'],
            'country_id': self.env['res.country'].sudo().search([('code', '=', 'GB')], limit=1).id,
            'company_number': values['company_phone_number'],
            'email_from': values['contact_email'],
            'phone': values['contact_phone_number'],
            'partner_name': values['registered_company_name'],
            'partner_id': partner.id,
            # 'supply_partner_id': supply_partner_id and supply_partner_id.id or False,
            'package_requirement_id': int(values['package_requirement_id']) if values['package_requirement_id'] else False,
            'partner_assigned_id': user.commercial_partner_id.id,
            'user_id': user.id,
        }
        if tag_own:
            values['tag_ids'] = [(4, tag_own.id, False)]
        lead = self.create(values)
        # lead.assign_salesman_of_assigned_partner()
        lead.convert_opportunity(lead.partner_id.id)
        lead.action_new_quotation_auto()

        tag_list = ['Electric', 'Gas', 'Water', 'Insurance', 'Telco',
                    'Waste', 'Merchant Service', 'Outsourced Human Resources']
        # for tag in tag_list:
        #     if self.env['crm.tag'].sudo().search([('name', '!=', tag)], limit=1):
        #         self.env['crm.lead'].sudo().create({'name': tag})
        for lead_dict in lead_lst:
            lead_dict.update({
                'type': 'lead',
                })

            if 'electric_submit' in lead_dict and lead_dict.get('electric_submit'):
                tag = self.env['crm.tag'].sudo().search([('name', '=', 'Electric')], limit=1)
                lead_dict.update({'tag_ids': [(6, 0, [tag_own.id, tag.id])]})
                self.env['crm.lead'].sudo().create(lead_dict)

            if 'gas_submit' in lead_dict and lead_dict.get('gas_submit'):
                tag = self.env['crm.tag'].sudo().search([('name', '=', 'Gas')], limit=1)
                lead_dict.update({'tag_ids': [(6, 0, [tag_own.id, tag.id])]})
                self.env['crm.lead'].sudo().create(lead_dict)

            if 'water_submit' in lead_dict and lead_dict.get('water_submit'):
                tag = self.env['crm.tag'].sudo().search([('name', '=', 'Water')], limit=1)
                lead_dict.update({'tag_ids': [(6, 0, [tag_own.id, tag.id])]})
                self.env['crm.lead'].sudo().create(lead_dict)

            if 'insurance_submit' in lead_dict and lead_dict.get('insurance_submit'):
                tag = self.env['crm.tag'].sudo().search([('name', '=', 'Insurance')], limit=1)
                lead_dict.update({'tag_ids': [(6, 0, [tag_own.id, tag.id])]})
                self.env['crm.lead'].sudo().create(lead_dict)

            if 'telco_submit' in lead_dict and lead_dict.get('telco_submit'):
                tag = self.env['crm.tag'].sudo().search([('name', '=', 'Telco')], limit=1)
                lead_dict.update({'tag_ids': [(6, 0, [tag_own.id, tag.id])]})
                self.env['crm.lead'].sudo().create(lead_dict)

            if 'waste_submit' in lead_dict and lead_dict.get('waste_submit'):
                tag = self.env['crm.tag'].sudo().search([('name', '=', 'Waste')], limit=1)
                lead_dict.update({'tag_ids': [(6, 0, [tag_own.id, tag.id])]})
                self.env['crm.lead'].sudo().create(lead_dict)

            if 'ms_submit' in lead_dict and lead_dict.get('ms_submit'):
                tag = self.env['crm.tag'].sudo().search([('name', '=', 'Merchant Service')], limit=1)
                lead_dict.update({'tag_ids': [(6, 0, [tag_own.id, tag.id])]})
                self.env['crm.lead'].sudo().create(lead_dict)

            if 'hr_submit' in lead_dict and lead_dict.get('hr_submit'):
                tag = self.env['crm.tag'].sudo().search([('name', '=', 'Outsourced Human Resources')], limit=1)
                lead_dict.update({'tag_ids': [(6, 0, [tag_own.id, tag.id])]})
                self.env['crm.lead'].sudo().create(lead_dict)

        return {
            'id': lead.id
        }

    def create_referral_portal(self, values):
        """ Trigger this method when add new referral from the portal """
        user = self.env.user
        self = self.sudo()
        tag_own = self.env.ref('website_crm_partner_assign.tag_portal_lead_own_opp', False)
        vals = {
            'type': 'lead',
            'name': values['referral_business_name'],
            'contact_name': values['referral_contact_name'],
            'partner_name': values['referral_business_name'],
            'street': values['referral_street'],
            'street2': values['referral_street2'],
            'city': values['referral_city'],
            'state_id': int(values['state_id']) if values['state_id'] else False,
            'country_id': self.env['res.country'].sudo().search([('code', '=', 'GB')], limit=1).id,
            'zip': values['referral_zip'],
            'email_from': values['referral_email'],
            'phone': values['referral_mobile'],
            'description': values['description'],
            'tag_ids': [(6, 0, [tag_own.id])],
            'is_referral': True,
            'package_requirement_id': int(values['package_requirement_id']) if values[
                'package_requirement_id'] else False,
        }
        # tag_list = {'electricity': 'Electric', 'gas': 'Gas', 'water': 'Water',
        #             'insurance': 'Insurance', 'phone': 'Telco',
        #             'waste': 'Waste', 'merchant_services': 'Merchant Service',
        #             'outsourced_human_resources': 'Outsourced Human Resources'}
        # tag_own = self.env.ref('website_crm_partner_assign.tag_portal_lead_own_opp', False)
        # lead_id = False
        # for tag in tag_list:
        #     if values[tag]:
        #         tag_id = self.env['crm.tag'].sudo().search([('name', '=', tag_list[tag])], limit=1)
        #         vals.update({'tag_ids': [(6, 0, [tag_own.id, tag_id.id])]})
        #         lead_id = self.env['crm.lead'].sudo().create(vals)
        # if not all([values['electricity'], values['gas'], values['water'], values['insurance'],values['phone'], values['waste'], values['merchant_services'], values['outsourced_human_resources']]):
        #     vals.update({'tag_ids': [(6, 0, [tag_own.id])]})
        #     lead_id = self.env['crm.lead'].sudo().create(vals)
        lead_id = self.env['crm.lead'].sudo().create(vals)
        return {'id': lead_id and lead_id.id or False}

    def action_new_quotation_auto(self):
        vals = {
            'opportunity_id':self.id,
            'partner_id':self.partner_id.id,
            'campaign_id':self.campaign_id.id,
            'medium_id':self.medium_id.id,
            'source_id':self.source_id.id,
            'team_id':self.team_id.id,
            'user_id':self.user_id.id,
            'company_id':self.company_id.id or self.env.company.id,
            'origin':self.name,
            'tag_ids':[(6, 0, self.tag_ids.ids)],
            'package_requirement_id':self.package_requirement_id.id,
        }
        so = self.env['sale.order'].create(vals)

        sol_product = self.env['sale.order.line'].create({
            'name': self.package_requirement_id.product_id.name,
            'product_id': self.package_requirement_id.product_id.id,
            # 'product_uom_qty': 5,
            # 'product_uom': self.company_data['product_order_no'].uom_id.id,
            # 'price_unit': self.company_data['product_order_no'].list_price,
            'order_id': so.id,
            # 'tax_id': False,
        })
        if  self.package_requirement_id.route != False:
            if self.package_requirement_id.route != 'route_1':
                so.sudo().with_user(10).send_sign_template()
                stage_id = self.env['crm.stage'].sudo().search([('is_show_sign_button', '=', True)], limit=1)
                self.stage_id = stage_id.id
            else:
                if so.sudo().state in ('draft', 'sent'):
                    so.sudo().action_confirm()
                so.sudo().is_paperwork_received = True
                # self.action_confirm()
                invoice = so.sudo()._create_invoices()
                if invoice:
                    invoice.action_post()
                    res = invoice.action_invoice_sent()
                    pdf = self.env.ref('account.account_invoices').sudo()._render_qweb_pdf([invoice.id])[0]
                    attachment_id = self.env['ir.attachment'].create({
                        'name': invoice.name + ".pdf",
                        'type': 'binary',
                        'res_id': invoice.id,
                        'res_model': 'account.move',
                        'datas': base64.b64encode(pdf),
                        'mimetype': 'application/x-pdf',
                        'store_fname': invoice.name + ".pdf"
                    })

                    value = {
                        'composition_mode': res.get('context').get('default_composition_mode'),
                        'invoice_ids': [Command.link(invoice.id)],
                        # 'email_from': '"{}" <{}>'.format(self.user_id.name, self.user_id.email),
                        'email_from': '"Reduce My Bills" <{}>'.format(self.user_id.email),
                        'mail_server_id': False,
                        'is_print': False,
                        'snailmail_is_letter': False,
                        'partner_id': invoice.partner_id.id,
                        'is_email': True,
                        'partner_ids': [Command.link(invoice.partner_id.id)],
                        'subject': 'RMB Subscription Invoice',
                        # 'subject': 'My Company Invoice (Ref {})'.format(invoice--.name),
                        'body': '''<div style="box-sizing:border-box;font-size:13px;font-family:&quot;Lucida Grande&quot;, Helvetica, Verdana, Arial, sans-serif;margin:0px; padding:0px">\n
                                                    <p style="box-sizing:border-box;font-family:&quot;Lucida Grande&quot;, Helvetica, Verdana, Arial, sans-serif;margin:0px; padding:0px; font-size:13px">\n
                                                        Dear {},\n
                                                    <br style="box-sizing:border-box;"><br style="box-sizing:border-box;">\n
                                                        We are delighted to welcome you as a member of Reduce My Bills.\n
                                                    <br style="box-sizing:border-box;">\n
                                                        Please find attached your RMB Subscription invoice, reference <strong style="box-sizing:border-box;font-weight:500;">{}</strong>\n <br style="box-sizing:border-box;">
                                                    <br><p style="box-sizing:border-box;font-family:&quot;Lucida Grande&quot;, Helvetica, Verdana, Arial, sans-serif;margin:0px; padding:0px; font-size:13px" data-oe-t-group="5" data-oe-t-group-active="true">

                                                    <a href="{}/payment/pay?reference={}&amp;amount={}&amp;currency_id=142&amp;partner_id={}&amp;company_id={}&amp;invoice_id={}&amp;access_token={}" target="_blank" class="btn btn-fill-primary btn-lg" style="text-decoration:none;border-radius:0px;border-style:solid;padding:6px 12px 6px 12px;box-sizing:border-box;cursor:pointer;transition-property:none;transition-delay:0s;transition-timing-function:ease;transition-duration:0s;line-height:1.5;font-size:16.25px;border-left-color:#017e84;border-bottom-color:#017e84;border-right-color:#017e84;border-top-color:#017e84;border-left-width:1px;border-bottom-width:1px;border-right-width:1px;border-top-width:1px;user-select:none;vertical-align:middle;text-align:center;font-weight:500;display:inline-block;background-color:#017e84;color: #ffffff;" data-original-title="" title=""><!--[if mso]><i style="letter-spacing: 25px; mso-font-width: -100%; mso-text-raise: 30pt;">&nbsp;</i><![endif]--><!--[if mso]><i style="letter-spacing: 25px; mso-font-width: -100%; mso-text-raise: 30pt;">&nbsp;</i><![endif]--><!--[if mso]><i style="letter-spacing: 25px; mso-font-width: -100%; mso-text-raise: 30pt;">&nbsp;</i><![endif]--><!--[if mso]><i style="letter-spacing: 25px; mso-font-width: -100%; mso-text-raise: 30pt;">&nbsp;</i><![endif]--><!--[if mso]><i style="letter-spacing: 25px; mso-font-width: -100%; mso-text-raise: 30pt;">&nbsp;</i><![endif]--><!--[if mso]><i style="letter-spacing: 25px; mso-font-width: -100%; mso-text-raise: 30pt;">&nbsp;</i><![endif]-->Pay Now<!--[if mso]><i style="letter-spacing: 25px; mso-font-width: -100%;">&nbsp;</i><![endif]--><!--[if mso]><i style="letter-spacing: 25px; mso-font-width: -100%;">&nbsp;</i><![endif]--><!--[if mso]><i style="letter-spacing: 25px; mso-font-width: -100%;">&nbsp;</i><![endif]--><!--[if mso]><i style="letter-spacing: 25px; mso-font-width: -100%;">&nbsp;</i><![endif]--><!--[if mso]><i style="letter-spacing: 25px; mso-font-width: -100%;">&nbsp;</i><![endif]--><!--[if mso]><i style="letter-spacing: 25px; mso-font-width: -100%;">&nbsp;</i><![endif]--></a><br></p>
                                                    <br><br style="box-sizing:border-box;">\n
                                                        Any questions please contact us via email: myaccount@reducemybills.ltd\n
                                                    <br style="box-sizing:border-box;"><br style="box-sizing:border-box;">\n
                                                        Regards\n
                                                    <br style="box-sizing:border-box;"><br style="box-sizing:border-box;">\n
                                                        Reduce My Bills\n
                                                    <br style="box-sizing:border-box;">\n
                                                        myaccount@reducemybills.ltd \n
                                                    <br> <img src="/logo" alt="logo" width="170" height="180">\n    </p>\n</div>\n 
                                                    '''.format(invoice.partner_id.name, invoice.name,
                                                               invoice.get_base_url(),
                                                               invoice.name, invoice.amount_residual,
                                                               invoice.partner_id.id,
                                                               invoice.company_id.id, invoice.id,
                                                               invoice.get_email_pay_token()),
                        'template_id': res.get('context').get('default_template_id'),
                        'attachment_ids': [Command.link(attachment_id.id)],
                    }
                    inv_send = self.env['account.invoice.send'].with_context(active_ids=invoice.ids).sudo().with_user(10).create(value)
                    if inv_send:
                        inv_send.with_context(is_crm_lead=res.get('context').get('is_crm_lead'),
                                              is_crm_lead_stage=res.get('context').get(
                                                  'is_crm_lead_stage'), active_ids=invoice.ids).sudo().with_user(10).send_and_print_action()
                        message_id = invoice.message_post(
                            body='<div style="box-sizing:border-box;font-size:13px;font-family:&quot;Lucida Grande&quot;, Helvetica, Verdana, Arial, sans-serif;margin:0px; padding:0px">\n    <p style="box-sizing:border-box;font-family:&quot;Lucida Grande&quot;, Helvetica, Verdana, Arial, sans-serif;margin:0px; padding:0px; font-size:13px">\n        Dear\n            {},\n        <br style="box-sizing:border-box;"><br style="box-sizing:border-box;">\n    We are delighted to welcome you as a member of Reduce My Bills.\n<br style="box-sizing:border-box;">\n      Please find attached your RMB Subscription invoice, reference <strong style="box-sizing:border-box;font-weight:500;">{}</strong>\n <br style="box-sizing:border-box;"><br style="box-sizing:border-box;">\n       Any questions please contact us via email: myaccount@reducemybills.ltd\n <br style="box-sizing:border-box;"><br style="box-sizing:border-box;">\n           Regards\n                <br style="box-sizing:border-box;"><br style="box-sizing:border-box;">\n                Reduce My Bills\n        <br style="box-sizing:border-box;">\n        myaccount@reducemybills.ltd \n    </p>\n</div>\n            '.format(
                                invoice.partner_id.name, invoice.name))
                        message_id.write({
                            'attachment_ids': [Command.link(attachment_id.id)]
                        })

                return True
