odoo.define('tus_website_crm_extend.hide_show_section', function (require) {
    "use strict";

    var ajax = require('web.ajax');

    $(document).ready(function () {
        var myBooleanField = $('.checkbox');
        var myElement = $('#sub_section');

        myBooleanField.on('change', function () {
            var isChecked = $(this).prop('checked');
            if (isChecked) {
                myElement.hide();
            } else {
                myElement.show();
            }
        });
    });
});