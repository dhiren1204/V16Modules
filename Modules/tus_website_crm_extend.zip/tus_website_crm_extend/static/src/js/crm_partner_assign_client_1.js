odoo.define('tus_website_crm_extend.crm_partner_assign_client_1', function (require) {
    'use strict';

    var core = require('web.core');
    var publicWidget = require('web.public.widget');

    var _t = core._t;

    var ajax = require('web.ajax');
    var rpc = require('web.rpc');
    var qweb = core.qweb;

publicWidget.registry.crmPartnerAssign.include({

    create_vals_from_input: async function(){
        debugger
        var vals = {}
        await _.map($('.new_opp_form').find('input:not([type=radio]),select,input:radio:checked'),async function(inp){
            if(inp.type == 'radio'){
                vals[inp.name] = inp.checked
            }
            else if(inp.type == 'checkbox'){
                debugger
                vals[inp.name] = inp.checked
            }
            else{
                vals[inp.name] = inp.value
            }
        })
        return vals
    },

    _createOpportunity: async function () {
        var vals = await this.create_vals_from_input()
        return this._rpc({
            model: 'crm.lead',
            method: 'create_opp_portal',
            args: [vals],
        }).then(function (response) {
            if (response.errors) {
                $('#new-opp-dialog .alert').remove();
                $('#new-opp-dialog div:first').prepend('<div class="alert alert-danger">' + response.errors + '</div>');
                return Promise.reject(response);
            } else {
                window.location = '/my/opportunity/' + response.id;
            }
        });
    },

});

var count = 0
publicWidget.registry.ReferralPopup = publicWidget.Widget.extend({
        selector: '.add-referral-popup-cl',
        events: {
            'click .add-referral-btn': '_onClick',
            'click .referral-popup-close-btn': '_onClickReferralPopupCloseBtn',
            'click .create_referral_line': '_onClickCreateReferralLIne',
            'click .lead_delete_row_btn': '_onClickDeleteRow',

        },

        start: function () {
            $('.portal_referral_line_table_tbody').prepend(
                    '<tr>'+
                    '<td></td>'+
                    '<td></td>'+
                    '<td></td>'+
                    '<td></td>'+
                    '<td></td>'+
                    '<td style="display:none;"></td>'+
                    '<td style="display:none;"></td>'+
                    '<td style="display:none;"></td>'+
                    '<td style="display:none;"></td>'+
                    '<td style="display:none;"></td>'+
                    '<td style="display:none;"></td>'+
                    '<td style="display:none;"></td>'+
                    '<td style="display:none;"></td>'+
                    '<td></td>'+
                    '<td></td>'+
                    '</tr>'+
                    '<td></td>'+
                    '<td></td>'+
                    '<td></td>'+
                    '<td></td>'+
                    '<td></td>'+
                    '<td style="display:none;"></td>'+
                    '<td style="display:none;"></td>'+
                    '<td style="display:none;"></td>'+
                    '<td style="display:none;"></td>'+
                    '<td style="display:none;"></td>'+
                    '<td style="display:none;"></td>'+
                    '<td style="display:none;"></td>'+
                    '<td style="display:none;"></td>'+
                    '<td></td>'+
                    '<td></td>'+
                    '</tr>'+
                    '<tr>'+
                    '<td></td>'+
                    '<td></td>'+
                    '<td></td>'+
                    '<td></td>'+
                    '<td></td>'+
                    '<td style="display:none;"></td>'+
                    '<td style="display:none;"></td>'+
                    '<td style="display:none;"></td>'+
                    '<td style="display:none;"></td>'+
                    '<td style="display:none;"></td>'+
                    '<td style="display:none;"></td>'+
                    '<td style="display:none;"></td>'+
                    '<td style="display:none;"></td>'+
                    '<td></td>'+
                    '<td></td>'+
                    '</tr>'
                    )
            },

        _onClick: function (ev) {
            this._createReferral();
            $("#referral_contact_name").val('');
            $("#referral_business_name").val('');
            $("#referral_street").val('');
            $("#referral_street2").val('');
            $("#referral_city").val('');
            $("#state_id").val('');
            $("#referral_zip").val('');
            $("#referral_email").val('');
            $("#referral_mobile").val('');
            $("#description").val('');
            $("#package_requirement_id").val('');

//            $("#electricity").prop('checked',false);
//            $("#gas").prop('checked',false);
//            $("#water").prop('checked',false);
//            $("#insurance").prop('checked',false);
//            $("#phone").prop('checked',false);
//            $("#waste").prop('checked',false);
//            $("#merchant_services").prop('checked',false);
//            $("#outsourced_human_resources").prop('checked',false);
//            $('#ReferralModal').modal('toggle');
            $("#ReferralModal").modal();
        },

        _onClickReferralPopupCloseBtn: function (ev) {
            $('#ReferralModal').modal('hide');
        },

        _onClickCreateReferralLIne: function (ev) {
            var self = this;
            var dict = {}
            var referral_contact_name = $('#referral_contact_name').val();
            var referral_business_name = $('#referral_business_name').val();
            var referral_street = $('#referral_street').val();
            var referral_street2 = $('#referral_street2').val();
            var referral_city = $('#referral_city').val();
            var state_id = $('#state_id').val();
            var referral_zip = $('#referral_zip').val();
            var referral_email = $('#referral_email').val();
            var referral_mobile = $('#referral_mobile').val();
            var electricity = $('#electricity').is(':checked');
            var gas = $('#gas').is(':checked');
            var water = $('#water').is(':checked');
            var insurance = $('#insurance').is(':checked');
            var phone = $('#phone').is(':checked');
            var waste = $('#waste').is(':checked');
            var merchant_services = $('#merchant_services').is(':checked');
            var outsourced_human_resources = $('#outsourced_human_resources').is(':checked');
            var package_requirement_id = $('#package_requirement_id').val();
            var description = $('#description').val();

            if (!referral_contact_name){
                $('.referral_contact_name_div').text('Please Enter Contact Name').css('color', 'red')
            }else{
                $('.referral_contact_name_div').text('')
            }
            if (!referral_business_name){
                $('.referral_business_name_div').text('Please Enter Business Name').css('color', 'red')
            }else{
                $('.referral_business_name_div').text('')
            }
            if (!referral_street){
                $('.referral_street_div').text('Please Enter Street').css('color', 'red')
            }else{
                $('.referral_street_div').text('')
                }
            if (!referral_zip){
                $('.referral_zip_div').text('Please Enter Postcode').css('color', 'red')
            }else{
                $('.referral_zip_div').text('')
            }
            if (!referral_mobile){
                $('.referral_mobile_div').text('Please Enter Phone Number').css('color', 'red')
            }else{
                $('.referral_mobile_div').text('')
            }

            /*if (referral_contact_name && referral_business_name && referral_zip && referral_mobile){
                $('.portal_referral_line_table_tbody').prepend(
                    '<tr id="portal_referral_'+ count +'" data-counter_id="'+ count +'">'+
                    '<td>'+referral_contact_name+'</td>'+
                    '<td>'+referral_business_name+'</td>'+
                    '<td>'+referral_zip+'</td>'+
                    '<td>'+referral_email+'</td>'+
                    '<td>'+referral_mobile+'</td>'+
                    '<td style="display:none;">'+electricity+'</td>'+
                    '<td style="display:none;">'+gas+'</td>'+
                    '<td style="display:none;">'+water+'</td>'+
                    '<td style="display:none;">'+insurance+'</td>'+
                    '<td style="display:none;">'+phone+'</td>'+
                    '<td style="display:none;">'+waste+'</td>'+
                    '<td style="display:none;">'+merchant_services+'</td>'+
                    '<td style="display:none;">'+outsourced_human_resources+'</td>'+
                    '<td>'+description+'</td>'+
*//*                    '<td class="o_list_record_remove"><button class="fa fa-trash-o" name="delete" aria-label="Delete row 1"/></td>'+*//*
                    *//*'<td><i class="fa fa-trash" t-att-data-counter_id="'+ count +'" aria-hidden="true"/></td>'+*//*
                    '<td><button type="button" class="fa fa-trash-o lead_delete_row_btn" id="lead_delete_row_btn" style="background-color: red !important;" data-counter_id="'+ count +'"/></td>'+

                    '</tr>'
                    )
                $("<input type='hidden' id='referral_hidden_"+ count +"' value='"+referral_contact_name+"' name= 'referral_contact_name_"+count+"'/>").appendTo('form');
                $("<input type='hidden' id='referral_hidden_"+ count +"' value='"+referral_business_name+"' name= 'referral_business_name_"+count+"'/>").appendTo('form');
                $("<input type='hidden' id='referral_hidden_"+ count +"' value='"+referral_zip+"' name= 'referral_zip_"+count+"'/>").appendTo('form');
                $("<input type='hidden' id='referral_hidden_"+ count +"' value='"+referral_email+"' name= 'referral_email_"+count+"'/>").appendTo('form');
                $("<input type='hidden' id='referral_hidden_"+ count +"' value='"+referral_mobile+"' name= 'referral_mobile_"+count+"'/>").appendTo('form');
                $("<input type='hidden' id='referral_hidden_"+ count +"' value='"+electricity+"' name= 'electricity_"+count+"'/>").appendTo('form');
                $("<input type='hidden' id='referral_hidden_"+ count +"' value='"+gas+"' name= 'gas_"+count+"'/>").appendTo('form');
                $("<input type='hidden' id='referral_hidden_"+ count +"' value='"+water+"' name= 'water_"+count+"'/>").appendTo('form');
                $("<input type='hidden' id='referral_hidden_"+ count +"' value='"+insurance+"' name= 'insurance_"+count+"'/>").appendTo('form');
                $("<input type='hidden' id='referral_hidden_"+ count +"' value='"+phone+"' name= 'phone_"+count+"'/>").appendTo('form');
                $("<input type='hidden' id='referral_hidden_"+ count +"' value='"+waste+"' name= 'waste_"+count+"'/>").appendTo('form');
                $("<input type='hidden' id='referral_hidden_"+ count +"' value='"+merchant_services+"' name= 'merchant_services_"+count+"'/>").appendTo('form');
                $("<input type='hidden' id='referral_hidden_"+ count +"' value='"+outsourced_human_resources+"' name= 'outsourced_human_resources_"+count+"'/>").appendTo('form');
                $("<input type='hidden' id='referral_hidden_"+ count +"' value='"+description+"' name= 'description_"+count+"'/>").appendTo('form');
                count = count + 1

                $('#ReferralModal').modal('hide');

                }*/
            dict ={
                'referral_contact_name': referral_contact_name,
                'referral_business_name': referral_business_name,
                'referral_street': referral_street,
                'referral_street2': referral_street2,
                'referral_city': referral_city,
                'state_id': state_id,
                'referral_zip': referral_zip,
                'referral_email': referral_email,
                'referral_mobile': referral_mobile,
//                'electricity': electricity,
//                'gas': gas,
//                'water': water,
//                'insurance': insurance,
//                'phone': phone,
//                'waste': waste,
//                'merchant_services': merchant_services,
//                'outsourced_human_resources': outsourced_human_resources,
                'package_requirement_id': package_requirement_id,
                'description': description,
            }
            return dict
        },
        _createReferral: async function () {
            var vals = await this._onClickCreateReferralLIne()
            return this._rpc({
                model: 'crm.lead',
                method: 'create_referral_portal',
                args: [[], vals],
            }).then(function (response) {
                $('#ReferralModal').modal('hide');
                window.location.reload();
                });
        },

        _onClickDeleteRow: function (ev) {
//        This function used for delete table row and delete hidden input
        count = $(ev.currentTarget).data("counter_id")
        $("#portal_referral_"+ count).remove();
        $("#referral_hidden_"+ count).remove();

        $("input[id='referral_hidden_"+count+"' ").remove();


        },
    });

});
