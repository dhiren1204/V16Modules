
from odoo import models, fields

class Timesheet(models.Model):
    _inherit = 'account.analytic.line'

    approved = fields.Boolean(string="Approved", default=False)

    def action_approve_timesheets(self, timesheet_ids):
        timesheets = self.browse(timesheet_ids)
        for timesheet in timesheets:
            timesheet.approved = True
