
{
    'name': 'Portal Timesheet Approval',
    'version': '1.0',
    'summary': 'Allow timesheet approval from the portal',
    'description': """
        This module allows portal users to approve timesheets.
    """,
    'author': 'Your Name',
    'depends': ['base', 'portal', 'hr_timesheet'],
    'data': [
        'security/portal_timesheet_security.xml',
        'security/ir.model.access.csv',
        'views/portal_timesheet_templates.xml',
    ],
    'installable': True,
    'application': False,
}
