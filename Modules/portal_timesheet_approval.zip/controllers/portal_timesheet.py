
from odoo import http
from odoo.http import request

class PortalTimesheet(http.Controller):

    @http.route(['/my/timesheets'], type='http', auth="user", website=True)
    def portal_my_timesheets(self, **kw):
        timesheets = request.env['account.analytic.line'].sudo().search([('user_id', '=', request.env.user.id)])
        values = {
            'timesheets': timesheets,
        }
        return request.render("portal_timesheet_approval.portal_timesheet_page", values)

    @http.route(['/my/timesheet/approve'], type='http', auth="user", methods=['POST'], website=True)
    def portal_timesheet_approve(self, **kw):
        timesheet_ids = request.httprequest.form.getlist('timesheet_ids')
        if timesheet_ids:
            timesheet_ids = [int(t_id) for t_id in timesheet_ids]
            request.env['account.analytic.line'].sudo().action_approve_timesheets(timesheet_ids)
        return request.redirect('/my/timesheets')
