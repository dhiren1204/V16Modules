/** @odoo-module **/

import publicWidget from "@web/legacy/js/public/public_widget";
import { renderToElement } from "@web/core/utils/render";

publicWidget.registry.Invoiceslider = publicWidget.Widget.extend({
     selector: '.o_portal_invoice_sidebar',
    events: {
        'click .send_mail':'_sendMail',
    },
    init() {
        this._super(...arguments);
        this.rpc = this.bindService("rpc");
    },
    _sendMail(ev){
        var id = $(ev.currentTarget).data('id')
        $(ev.currentTarget).prop('disabled', true);
        this.rpc("/send/mail", {
                'invoice_id':parseInt(id)
                }).then(function (data) {
                    $(ev.currentTarget).prop('disabled', false);
                    if(data){
                        $('#confirmPopup').modal('show');
                    }
                    else{
                        $('#errorPopup').modal('show');
                    }
                });
    }
});

publicWidget.registry.InvoiceRequest = publicWidget.Widget.extend({
    selector: '.o_invoice_request',
    events: {
        'click .oncreate':'_oncreate',
        'click .edit':'_onedit',
        'click .delete':'_ondelete',
        'click .create_customer':'create_customer',
        'change .product_id':'onChnageProductId',
        'click .add_line':'onChnageAddLine',
    },
    init() {
        this._super(...arguments);
        $('#tax_ids').select2();
        this.rpc = this.bindService("rpc");
    },
    onChnageAddLine(ev){
        var code = $("#partner_id option:selected").data('country_code')
        var taxes = []
        const $taxesIdsElement = $('#tax_ids');
        $taxesIdsElement.val('').trigger('change')
        $('#product_id').val('')
        $('#description').val('')
        $('#price_unit').val(0)
        if(code == 'NL'){
            $('#tax_ids option').each(function() {
                console.log(">>>",$(this).data('amount'))
                if($(this).data('amount') == '21.0'){
                    taxes.push($(this).val())
                }
            });
            const $taxesIdsElement = $('#tax_ids');
            $taxesIdsElement.val(taxes).trigger('change')
        }
    },
    onChnageProductId(ev){
        var product_id = $(ev.currentTarget).val()
        const $taxesIdsElement = $('#tax_ids');
        $taxesIdsElement.val('').trigger('change')
        $('#description').val('')
        $('#price_unit').val(0)
        if(product_id != ''){
            this.rpc("/get/product_info", {
                'product_id':parseInt(product_id)
                }).then(function (data) {
                    if(data){
                        $('#description').val(data.display_name)
                        $('#price_unit').val(data.list_price)
                        var newTaxesIds = data.taxes_id
                        $taxesIdsElement.val(newTaxesIds).trigger('change');
                    }
                });
        }
    },
    create_customer(){
        var name = $('.new_customer').val()
        var address = $('.customer_address').val()
        var street = $('.customer_street').val()
        var city = $('.customer_city').val()
        var zip = $('.customer_zip').val()
        var vat = $('.new_customer_vat').val()
        var country = $('#new_customer_country_s').val()
        var state = $('#customer_state').val()
        var email = $('.new_customer_email').val()
        var mobile = $('.new_customer_number').val()

        if (mobile.trim() === '' || name.trim() === '' || email.trim() === ''){
            alert('Name, Email and Mobile are required!');
        }
        else{
            this.rpc("/customer/request", {'name': name,
            'email':email,'mobile':mobile,
            'street1':address,'street2': street, 'city': city,'state':state,'zip':zip,'country':country,'vat':vat,
            }).then(function (data) {
                $("#customermodal").modal('hide');
                $('.new_customer').val('')
                $('.new_customer_email').val('')
                $('.customer_address').val()
                $('.customer_street').val()
                $('.customer_city').val()
                $('.customer_zip').val()
                $('.new_customer_vat').val()
                $('#new_customer_country_s').val()
                $('#customer_state').val()
                location.reload()
           });
        }
    },
    _ondelete(ev){
         var line_id = $(ev.currentTarget).data('line_id');
         $(ev.currentTarget).closest('tr').remove();
         var remove_line_ids = $('#remove_line_id').val()
         if(remove_line_ids != ''){
            remove_line_ids = remove_line_ids+ ','+line_id
         }
         else{
            remove_line_ids = line_id
         }
         $('#remove_line_id').val(remove_line_ids)
         var amount_total = 0
          var currency_symbol = $('.currency_symbol').html()
             var currency_position = $('.currency_position').html().trim()
         $('.sub_total_line').each(function () {
            amount_total = amount_total + parseFloat($(this).html())
         });
         if(currency_position == 'before'){
            $('.final_total').html(currency_symbol + amount_total)
         }
         else{
            $('.final_total').html(amount_total +' ' +currency_symbol)
         }

    },
    _onedit(ev){
        var row_number = $(ev.currentTarget).data('row_number');
        var name1 = $('input[name="name_'+row_number+'"]').val()
        var product_uom_qty2 = $('input[name="product_uom_qty_'+row_number+'"]').val()
        var product_id2 = $('input[name="product_id_'+row_number+'"]').val()


        $('#solinepopup').find('input.name').val(name1);
        $('#solinepopup').find('#product_uom_qty').val(product_uom_qty2);
        $('#solinepopup').find('#product_id').val(product_id2);
        $('#row_number').val(row_number);
        $('#solinepopup').modal('show');
    },
    _oncreate(){
         var row = $('#row_number').val()
         if(row != ''){
            var value1 = $('input.name').val()
            var value2 = $("#product_uom_qty").val()
            var value3 = $("#product_id").val()

            var name1 = $('input[name="name_'+row+'"]').val(value1)
            var product_uom_qty2 = $('input[name="product_uom_qty_'+row+'"]').val(value2)

            $("#solinepopup").modal('hide');
            $("input.name").val('')
            $("#product_uom_qty").val('')
            $("#product_id").val('')
            $('#row_number').val('')
         }
         else{
             var value1 = $('input.name').val()
             var value2 = $("#product_uom_qty").val()
             var value3 = $("#product_id").val()
             var value5 = $("#price_unit").val()
             var value4 = $("#product_id").find(':selected').data('product_name')
             var value6 = $('#tax_ids option:selected')
                .toArray().map(item => $(item).val()).join(",");
             var value7 = $('#tax_ids option:selected')
                .toArray().map(item => $(item).data('tax_name'));
             var value8 = value7.join(",");
             var tax_amounts = $('#tax_ids option:selected')
                .toArray().map(item => $(item).data('amount'));
             var total_tax_amounts = 0;
                for (var i = 0; i < tax_amounts.length; i++) {
                    total_tax_amounts += tax_amounts[i] << 0;
                }
             var currency_symbol = $('.currency_symbol').html()
             var currency_position = $('.currency_position').html().trim()

    //         value9 = $('#purpose_transfer_operational').val()
              var fields = [
                {value: value1, name: 'Description'},
                {value: value2, name: 'Quantity'},
//                {value: value3, name: 'Product'},
                {value: value5, name: 'Price'},
            ];
            // Check if any field is empty
            var emptyFields = fields.filter(function(field) {
                return field.value === '';
            });

             if (emptyFields.length > 0) {
                var emptyFieldNames = emptyFields.map(function(field) {
                    return field.name;
                }).join(', ');

                alert('Please enter the following required fields: ' + emptyFieldNames);
            }else{
                var value_tax_exc = parseFloat(value2) * parseFloat(value5)
                var tax_amount = 0
                if(total_tax_amounts){
                    var tax_amount = value_tax_exc * (total_tax_amounts/100)
                }
                var sub_total = value_tax_exc + tax_amount

                var Solinerow = $(renderToElement("ss_quick_invoice_portal.soline_row", {'row_no': ($('.ipc_soline_row').length + 1),"name": value1,"product_uom_qty": value2,"product_id":value3,'product_name':value4,'price_unit':value5,'tax_ids':value6,'taxes':value8,'value_tax_exc':value_tax_exc,'sub_total':sub_total,'currency_symbol':currency_symbol}))

                 $(".form_detail").find("tbody").append(Solinerow);
                 var amount_total = 0
                 $(".form_detail").find("tbody").find('.sub_total_line').each(function () {
                    amount_total = amount_total + parseFloat($(this).html())
                 });
                 if(currency_position == 'before'){
                    $('.final_total').html(currency_symbol + amount_total)
                 }
                 else{
                    $('.final_total').html(amount_total +' ' +currency_symbol)
                 }
                                   $(Solinerow).on('click', '.edit', function() {
                                        var row_number = $(this).data('row_number');
                                        var name1 = $('input[name="name_'+row_number+'"]').val()
                                        var product_uom_qty2 = $('input[name="product_uom_qty_'+row_number+'"]').val()
                                        var product_id2 = $('input[name="product_id_'+row_number+'"]').val()
                                        var price_unit2 = $('input[name="price_unit_'+price_unit+'"]').val()


                                        $('#solinepopup').find('input.name').val(name1);
                                        $('#solinepopup').find('#product_uom_qty').val(product_uom_qty2);
                                        $('#solinepopup').find('#product_id').val(product_id2);
                                        $('#solinepopup').find('#price_unit').val(price_unit2);
                                        $('#row_number').val(row_number);
                                        $('#solinepopup').modal('show');


                                   });
                                   $(Solinerow).on('click', '.delete', function() {
                                        $(this).closest('tr').remove();
                                         var amount_total = 0
                                         $('.sub_total_line').each(function () {
                                            amount_total = amount_total + parseFloat($(this).html())
                                         });
                                         var currency_symbol = $('.currency_symbol').html()
                                         var currency_position = $('.currency_position').html().trim()
                                        if(currency_position == 'before'){
                                            $('.final_total').html(currency_symbol + amount_total)
                                         }
                                         else{
                                            $('.final_total').html(amount_total +' ' +currency_symbol)
                                         }
                                    });
                $("#solinepopup").modal('hide');;
                 $("input.name").val('')
                $("#product_uom_qty").val('')
                $("#product_id").val('')
                $("#price_unit").val('')
                $('#row_number').val('')
                 $("#tax_ids").val('').change();
            }
        }
     },


});
