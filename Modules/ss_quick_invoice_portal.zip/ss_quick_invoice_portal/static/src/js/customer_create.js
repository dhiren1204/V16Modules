//odoo.define('portal_hr_expense.portal_vendor', function (require){
//'use_strict';
//
//    var publicWidget = require('web.public.widget');
//    var ajax = require('web.ajax');
//    var core = require('web.core');
//    var _t = core._t;
//    var QWeb = core.qweb;
//    var session = require('web.session');
//
//    publicWidget.registry.PortalVendor =publicWidget.Widget.extend({
//        selector: '.o_vendor_request',
//        events: {
//           'click .create_vendor':'create_vendor',
//           'change .vendor_attachment':'_onChangeVendorAttachment',
//        },
//         willStart: function () {
//         return this._super.apply(this, arguments)
//         },
//         _onChangeVendorAttachment(){
//            if($('.vendor_attachment') && $('.vendor_attachment')[0].files.length > 0){
//                var url = $('.vendor_attachment')[0].files[0]
//                 var reader = new FileReader();
//                if (url){
//                    reader.readAsDataURL(url);
//                    reader.onload= function(e) {
//                        $('.vendor_attachment_binary_data').val(e.target.result);
//                        $('.vendor_attachment_file_name').val(url.name);
//                    };
//                }
//                else{
//                    $('.vendor_attachment_binary_data').val('');
//                        $('.vendor_attachment_file_name').val('');
//                }
//            }
//       },
//        create_vendor(){
//
//        if($('.vendor_attachment') && $('.vendor_attachment')[0].files.length == 0){
//
//        }
//        name = $('.new_vendor').val()
//        address = $('.vendor_address').val()
//        street = $('.vendor_street').val()
//        city = $('.vendor_city').val()
//        zip = $('.vendor_zip').val()
//        vat = $('.new_vendor_vat').val()
//        country = $('#new_vendor_country_s').val()
//        state = $('#vendor_state').val()
//        email = $('.new_vendor_email').val()
//        mobile = $('.new_vendor_number').val()
//        bank = $('#new_vendor_bank_name').val()
//        acc_num = $('.new_vendor_account').val()
//        payment = $('#new_vendor_payment_method').val()
//        branch = $('.bank_branch').val()
//        state_req = $('.state_req').val()
//        vendor_type = $('#vendor_type').val()
//        benificiary = $('.benificiary').val()
//        vendor_attachment_file_name = $('.vendor_attachment_file_name').val()
//        vendor_attachment_binary_data = $('.vendor_attachment_binary_data').val()
//        debugger;
//        if (address.trim() === '' || name.trim() === '' || email.trim() === '' || payment.trim() === '' || ($('.vendor_attachment') && $('.vendor_attachment')[0].files.length == 0)
//            || street.trim() === ''
//            || city.trim() === ''
//            || zip.trim() === ''
//            || country.trim() === ''
//            || mobile.trim() === ''
//        ) {
//        if(state_req == '1'){
//            alert('Name, Street, Street2, City, Zip / Postal Code, Country, State, Vat, Email, Mobile, Payment method and Attachment are required!');
//        }
//        else{
//            alert('Name, Street, Street2, City, Zip / Postal Code, Country, Vat, Email, Mobile, Payment method and Attachment are required!');
//        }
//      }else if($('#new_vendor_payment_method option:selected').data('payment_code') == 'manual' && (benificiary.trim() === '' || acc_num.trim() === '')){
//            alert('IBAN and Account Number are required!');
//      }
//      else{
//       ajax.jsonRpc("/vendor/request", 'call', {'name': name,
//       'email':email,'mobile':mobile,'bank':bank,'acc_num':acc_num,'payment':payment,'branch':branch,
//       'benificiary':benificiary,'vendor_type':vendor_type,
//        'street1':address,'street2': street, 'city': city,'state':state,'zip':zip,'country':country,'vat':vat,
//        'vendor_attachment_binary_data':vendor_attachment_binary_data,
//        'vendor_attachment_file_name':vendor_attachment_file_name,
//
//       }).then(function (data) {
//          $("#vendormodal").modal('hide');
//          })
//        $('.new_vendor').val('')
//        $('.new_vendor_email').val('')
//        $('.new_vendor_number').val('')
//        $('#new_vendor_bank_name').val('')
//        $('.new_vendor_account').val('')
//        $('#new_vendor_payment_method').val('')
//        $('.vendor_address').val()
//        $('.vendor_street').val()
//        $('.vendor_city').val()
//        $('.vendor_zip').val()
//        $('.new_vendor_vat').val()
//        $('#new_vendor_country_s').val()
//        $('#vendor_state').val()
//        $('.vendor_attachment_file_name').val('')
//        $('.vendor_attachment_binary_data').val('')
//        location.reload()
//      }
//
//        },
//        })
//    })