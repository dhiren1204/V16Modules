# -*- coding: utf-8 -*-
{
    'name': "Portal Quick Invoice Create",
    'summary': """ Portal Employee can create the invoices. """,
    'description': """Portal users can create their invoices by website portal without any interaction with backend side.""",
    'author': 'TechUltra Solution',
    'website': 'https://www.techultrasolutions.com',
    'category': 'Portal',
    'version': '1.2',
    'depends': ['portal', 'account'],
    'data': [
        "views/create_new_invoices.xml",
        "views/invoices_form_template.xml",
    ],
    'assets': {
        'web.assets_frontend': [
            "/ss_quick_invoice_portal/static/src/xml/table_template.xml",
            "/ss_quick_invoice_portal/static/src/js/portal_invoice_create.js",
            "/ss_quick_invoice_portal/static/src/js/customer_create.js",
        ],
    },
    'images': ['static/description/main_screen.png'],
    'license': 'OPL-1',
    'currency': 'EUR',
    'installable': True,
    'application': True,
    'auto_install': False,
}
