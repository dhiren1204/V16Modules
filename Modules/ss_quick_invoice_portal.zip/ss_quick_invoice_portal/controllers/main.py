# -*- coding: utf-8 -*-
# Part of Odoo. See COPYRIGHT & LICENSE files for full copyright and licensing details.

from odoo import http, tools, fields, _
from odoo.http import request
from odoo.addons.portal.controllers.portal import CustomerPortal, pager as portal_pager, get_records_pager
from odoo import Command
from odoo.addons.account.controllers.portal import PortalAccount
from collections import OrderedDict

from odoo import http, _
from odoo.osv import expression


class PortalAccount(PortalAccount):
    def _get_invoices_domain(self, m_type=None):
        if request.env.user.partner_id.parent_id:
            domain = [('partner_id', '=', request.env.user.partner_id.parent_id.id)]
        else:
            domain = [('partner_id', '=', request.env.user.partner_id.id)]
        company = request.env['res.company'].sudo().search(domain, limit=1)
        if m_type in ['in', 'out']:
            move_type = [m_type + move for move in ('_invoice', '_refund', '_receipt')]
        else:
            move_type = ('out_invoice', 'in_invoice')
            # move_type = ('out_invoice', 'out_refund', 'in_invoice', 'in_refund', 'out_receipt', 'in_receipt')
        return [('state', 'not in', ['cancel']), ('move_type', 'in', move_type), ('company_id', '=', company.id)]

    def _prepare_my_invoices_values(self, page, date_begin, date_end, sortby, filterby, domain=None,
                                    url="/my/invoices"):
        values = self._prepare_portal_layout_values()
        AccountInvoice = request.env['account.move']

        domain = expression.AND([
            domain or [],
            self._get_invoices_domain(),
        ])

        searchbar_sortings = self._get_account_searchbar_sortings()
        # default sort by order
        if not sortby:
            sortby = 'date'
        order = searchbar_sortings[sortby]['order']

        searchbar_filters = self._get_account_searchbar_filters()
        # default filter by value
        if not filterby:
            filterby = 'all'
        domain += searchbar_filters[filterby]['domain']

        if date_begin and date_end:
            domain += [('create_date', '>', date_begin), ('create_date', '<=', date_end)]

        values.update({
            'date': date_begin,
            # content according to pager and archive selected
            # lambda function to get the invoices recordset when the pager will be defined in the main method of a route
            'invoices': lambda pager_offset: (
                AccountInvoice.sudo().search(domain, order=order, limit=self._items_per_page, offset=pager_offset)
                if AccountInvoice.check_access_rights('read', raise_exception=False) else
                AccountInvoice
            ),
            'page_name': 'invoice',
            'pager': {  # vals to define the pager.
                "url": url,
                "url_args": {'date_begin': date_begin, 'date_end': date_end, 'sortby': sortby},
                "total": AccountInvoice.sudo().search_count(domain) if AccountInvoice.check_access_rights('read',
                                                                                                          raise_exception=False) else 0,
                "page": page,
                "step": self._items_per_page,
            },
            'default_url': url,
            'searchbar_sortings': searchbar_sortings,
            'sortby': sortby,
            'searchbar_filters': OrderedDict(sorted(searchbar_filters.items())),
            'filterby': filterby,
            'upload_bill_url': request.env.user.partner_id.vendor_bill,
            'upload_invoice_url': request.env.user.partner_id.customer_invoice
        })
        return values


class CustomController(CustomerPortal):
    def slicedict(self, d, s):
        return {k: v for k, v in d.items() if k.startswith(s)}

    @http.route('/send/mail', type='json', auth='public', website=True)
    def invoice_mail_send(self,  **post):
        res = False
        invoice = request.env['account.move'].sudo().browse(post.get('invoice_id'))
        if invoice.partner_id:
            template = request.env.ref(invoice._get_mail_template(), raise_if_not_found=False)
            template.sudo().send_mail(invoice.id, force_send=True)
            res = True
        return res

    @http.route('/get/product_info', type='json', auth='public', website=True)
    def get_product_info(self, **post):
        product = {}
        product_lst = request.env['product.product'].sudo().search_read([('id','=',post.get('product_id'))],['display_name','taxes_id','list_price'])
        if product_lst:
            product.update({
                'display_name': product_lst[0].get('display_name'),
                'taxes_id': product_lst[0].get('taxes_id'),
                'list_price': product_lst[0].get('list_price'),
            })
        return product

    @http.route('/customer/request', type='json', auth='public', website=True)
    def customer_request(self, **post):
        if len(post) > 0:
            vendor_id = request.env['res.partner'].with_user(request.env.uid).sudo()
            company = False
            if request.env.user.partner_id.parent_id:
                company = request.env['res.company'].sudo().search(
                    [('partner_id', '=', request.env.user.partner_id.parent_id.id)], limit=1)
            else:
                company = request.env['res.company'].sudo().search(
                    [('partner_id', '=', request.env.user.partner_id.id)], limit=1)
            vendor_id = vendor_id.create({
                'name': post.get('name'),
                'email': post.get('email'),
                "company_type": "person",
                "company_id": company.id if company else False,
                'customer_rank': 1,
            })
            vendor_id.write({
                'mobile': post.get('mobile'),
                "street": post.get('street1'),
                "street2": post.get('street2'),
                "city": post.get('city'),
                "state_id": int(post.get('state')) if post.get('state') else False,
                "zip": post.get('zip'),
                "vat": post.get('vat'),
                "country_id": int(post.get('country')) if post.get('country') else False,
            })
        return True

    @http.route(['/create/invoices', '/create/invoices/<int:invoice>'], type='http', auth="user", website=True)
    def quick_create_invoices(self, invoice=False, **kwargs):
        invoice_sudo = request.env['account.move'].sudo().search([('id', '=', invoice)])
        company = False
        if request.env.user.partner_id.parent_id:
            company = request.env['res.company'].sudo().search(
                [('partner_id', '=', request.env.user.partner_id.parent_id.id)], limit=1)
        else:
            company = request.env['res.company'].sudo().search(
                [('partner_id', '=', request.env.user.partner_id.id)], limit=1)
        if invoice_sudo:
            return http.request.render("ss_quick_invoice_portal.quick_update_invoices", {
                'page_name': 'invoice_update',
                'invoice_sudo': invoice_sudo,
                'state_id': request.env['res.country.state'].sudo().search([]),
                'country_id': request.env['res.country'].sudo().search([]),
            })
        return http.request.render("ss_quick_invoice_portal.quick_create_invoices", {
            'page_name': 'invoice_create',
            'invoice_sudo': invoice_sudo,
            'state_id': request.env['res.country.state'].sudo().search([]),
            'country_id': request.env['res.country'].sudo().search([]),
            'company_id': company if company else False,
        })

    def create_invoice(self, invoice):
        move_obj = request.env['account.move'].sudo()
        move_line = []
        company_id = request.env['res.company'].sudo().search(
            [('partner_id', '=', request.env.user.partner_id.parent_id.id)], limit=1)
        for item in self.slicedict(invoice, 'name_').keys():
            rec = int(item.split('_')[-1])
            move_line_dict = {}
            if invoice.get('tax_ids_{}'.format(rec)):
                move_line_dict.update({'tax_ids': [int(x) for x in invoice.get('tax_ids_{}'.format(rec)).split(',')]})
            if invoice.get('product_id_{}'.format(rec)):
                move_line_dict.update({'product_id': int(invoice.get('product_id_{}'.format(rec))) if invoice.get(
                    'product_id_{}'.format(rec)) else False})
            if invoice.get('price_unit_{}'.format(rec)):
                move_line_dict.update({'price_unit': float(invoice.get('price_unit_{}'.format(rec))) if invoice.get(
                    'price_unit_{}'.format(rec)) else 0})
            if invoice.get('name_{}'.format(rec)):
                move_line_dict.update({'name': invoice.get('name_{}'.format(rec))})
            if invoice.get('product_uom_qty_{}'.format(rec)):
                move_line_dict.update({'quantity': invoice.get('product_uom_qty_{}'.format(rec))})

            partner = request.env['res.partner'].sudo().browse(int(invoice.get("partner_id")))
            ProdProd = request.env['product.product'].sudo()
            product_id = False
            p_id = invoice.get('product_id_{}'.format(rec))
            if p_id:
                product_id = ProdProd.browse(int(invoice.get('product_id_{}'.format(rec))))
                if product_id:
                    fiscal_position_id = request.env['account.fiscal.position'].with_company(
                        company_id).sudo()._get_fiscal_position(
                        partner, delivery=False)
                    accounts = product_id \
                        .product_tmpl_id.sudo().get_product_accounts(fiscal_pos=fiscal_position_id)
                    # if line.move_id.is_sale_document(include_receipts=True):
                    #     line.account_id = accounts['income']
                    account_id = request.env['account.account'].sudo()._get_most_frequent_account_for_partner(
                        company_id=company_id.id,
                        partner_id=int(invoice.get("partner_id")),
                        move_type='out_invoice',
                    )
                    if account_id:
                        move_line_dict.update({'account_id': accounts['income'].id})
            if move_line_dict:
                move_line.append(Command.create(move_line_dict))

        move = move_obj.sudo().with_company(company_id.id).create(
            {'partner_id': int(invoice.get("partner_id")) if invoice.get("partner_id") else False,
             # 'partner_shipping_id': int(invoice.get("partner_shipping_id")) if invoice.get("partner_shipping_id") else False,
             'invoice_date': invoice.get("invoice_date"),
             'invoice_line_ids': move_line,
             'move_type': 'out_invoice',
             })
        move.action_post()
        return move

    def update_invoice(self, invoice):
        move_obj = request.env['account.move'].sudo()
        invoice_id = move_obj.browse(int(invoice['invoice']))

        if invoice.get('remove_line'):
            remove_so = invoice.get('remove_line').split(',')
            move_lines = request.env['account.move.line'].sudo().search([('id', 'in', remove_so)])
            move_lines.unlink()

        move_line = []
        for item in self.slicedict(invoice, 'name_').keys():
            rec = int(item.split('_')[-1])
            move_line_dict = {}
            if invoice.get('product_id_{}'.format(rec)):
                move_line_dict.update({'product_id': int(invoice.get('product_id_{}'.format(rec))) if invoice.get(
                    'product_id_{}'.format(rec)) else False})

            if invoice.get('name_{}'.format(rec)):
                move_line_dict.update({'name': invoice.get('name_{}'.format(rec))})
            if invoice.get('product_uom_qty_{}'.format(rec)):
                move_line_dict.update({'product_uom_qty': invoice.get('product_uom_qty_{}'.format(rec))})

            if invoice.get('move_line_id_{}'.format(rec)):
                order_line = request.env['account.move.line'].sudo().search(
                    [('id', '=', int(invoice.get('move_line_id_{}'.format(rec))))])
                order_line.write(move_line_dict)

            if move_line_dict and not invoice.get('move_line_id_{}'.format(rec)):
                move_line.append(Command.create(move_line_dict))

        invoice_id.write(
            {'partner_id': int(invoice.get("partner_id")) if invoice.get("partner_id") else False,
             # 'partner_invoice_id': int(invoice.get("partner_invoice_id")) if invoice.get(
             #     "partner_invoice_id") else False,
             # 'partner_shipping_id': int(invoice.get("partner_shipping_id")) if invoice.get(
             #     "partner_shipping_id") else False,
             'invoice_date': invoice.get("invoice_date"),
             'invoice_line_ids': move_line,
             })
        return invoice

    @http.route('/invoice/request', type='http', auth='public', website=True, csrf=False)
    def invoice_request(self, **post):
        invoice_id = False
        invoice_obj = request.env['account.move'].sudo()
        if post.get('invoice'):
            quotation_id = invoice_obj.browse(int(post['invoice']))
        if invoice_id:
            if len(post) > 1:
                post = self.update_invoice(post)
                return request.render("ss_quick_invoice_portal.thankyou_invoice")
        else:
            post = self.create_invoice(post)
            return request.render("ss_quick_invoice_portal.thankyou_invoice_submitted")
