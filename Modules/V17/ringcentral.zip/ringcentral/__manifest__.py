# See LICENSE file for full copyright and licensing details.
{
    # Module Info
    "name": "Odoo RingCentral Integration",
    "version": "1.0",
    "license": "LGPL-3",
    "category": "Customer Relationship Management, Industry",
    "summary": "This is the connector application for RingCentral integration",
    # Author
    "author": "Serpent Consulting Services Pvt. Ltd.",
    "website": "https://www.serpentcs.com",
    # Dependencies
    "depends": [
        "point_of_sale",
        "crm",
        "sales_team",
        "project",
        "web",
        "account",
        "point_of_sale",
    ],
    # Data
    "data": [
        "security/security.xml",
        "security/ir.model.access.csv",
        "views/crm_phonecall_view.xml",
        "views/res_users_view.xml",
        "views/company_view.xml",
        "wizard/synch_data_wiz.xml",
    ],
    "assets": {
        "web.assets_backend": [
            "/ringcentral/static/src/lib/sip.js",
            "/ringcentral/static/src/lib/fetch.js",
            "/ringcentral/static/src/lib/promise.js",
            "/ringcentral/static/src/lib/pubnub.js",
            "/ringcentral/static/src/lib/ringcentral.js",
            "/ringcentral/static/src/lib/ringcentral-web-phone.js",
            "/ringcentral/static/src/lib/jquery.slidemenu.js",
            "/ringcentral/static/src/lib/index.js",
            "/ringcentral/static/src/lib/audio_field.js",
            "/ringcentral/static/src/js/custom_ringcentral_owl.js",
            "/ringcentral/static/src/xml/call_logs_view.xml",
            "/ringcentral/static/src/js/call_logs_views.js",
            "/ringcentral/static/src/js/custom_ringcentral_panel_owl.js",
            "/ringcentral/static/src/js/panel_view_ringcentral.js",
            "/ringcentral/static/src/js/list_view.js",
            "/ringcentral/static/src/xml/list_view.xml",
            "/ringcentral/static/src/scss/slidemenu.scss",
            "/ringcentral/static/src/css/ringcentral.css",
            "/ringcentral/static/src/scss/custom_ringcentral.scss",
            "/ringcentral/static/src/xml/miss_logs_views.xml",
            "/ringcentral/static/src/js/miss_logs_views.js",
            "/ringcentral/static/src/xml/available_extensions.xml",
            "/ringcentral/static/src/js/available_extensions.js",
            "/ringcentral/static/src/xml/contacts_render.xml",
            "/ringcentral/static/src/js/contact_render.js",
            "/ringcentral/static/src/xml/incoming_call.xml",
            "/ringcentral/static/src/js/incoming_call.js",
            "/ringcentral/static/src/xml/active_call.xml",
            "/ringcentral/static/src/js/active_call.js",
            "/ringcentral/static/src/xml/outgoing_call.xml",
            "/ringcentral/static/src/js/outgoing_call.js",
            "/ringcentral/static/src/xml/message_partner.xml",
            "/ringcentral/static/src/js/message_partner.js",
            "/ringcentral/static/src/js/message_chatbox.js",
            "/ringcentral/static/src/xml/message_chatbox.xml",
            "/ringcentral/static/src/xml/ringcentral.xml",
            "/ringcentral/static/src/xml/widget.xml",
            "/ringcentral/static/src/js/phone_field.js",
        ],
    },
    # Odoo App Store Specific
    "images": ["static/description/Banner_Odoo_RingCentral_Integration01.png"],
    "live_test_url": """
                     https://www.youtube.com
                     /watch?v=P_UnbQwf_So&list=PL4Wugt3LKrSQTcPoOEONX0wtc16xtEB1b
                     """,
    # Technical
    "installable": True,
    "application": True,
    "price": 599,
    "currency": "EUR",
}
