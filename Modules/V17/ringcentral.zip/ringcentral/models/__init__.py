# See LICENSE file for full copyright and licensing details.

from . import crm_voip
from . import company
from . import project_project
from . import calendar_event
from . import res_partner
