/** @odoo-module **/

import {Component, onMounted, useState} from "@odoo/owl";
import {Dialog} from "@web/core/dialog/dialog";

export class MessageChatBoxDialogchatbox extends Component {
    setup() {
        super.setup();
        onMounted(async () => {
            const textInput = document.getElementById("popup_input");
            textInput.addEventListener("keydown", (event) => {
                if (event.key === "Enter") {
                    this.confirm(event);
                }
            });
            const element = $("#scroll_messge");
            element.animate(
                {
                    scrollTop: element.prop("scrollHeight"),
                },
                600
            );
            this.content = document.querySelector(".modal-content");
            this.content.setAttribute("style", "top: 22%;left: 74%; ");
        });
    }

    discardPopup() {
        this.props.close();
    }
    preventDrag(event) {
        event.preventDefault();
    }

    confirm(e) {
        this.props.widget.send_popup_msg(e, this.props.title);
    }
    Minimize() {
        var headerdialog = document.querySelector("#title_dialog").parentElement;
        document.querySelector("#minimize").classList.add("d-none");
        document.querySelector("#maximize").classList.remove("d-none");
        headerdialog.setAttribute("style", " background: #5b97d8;color: white; ");
        this.content.setAttribute(
            "style",
            "top: 102% !important;left: 74%; !important;"
        );
    }

    maximize() {
        var headerdialog = document.querySelector("#title_dialog").parentElement;
        document.querySelector("#maximize").classList.add("d-none");
        document.querySelector("#minimize").classList.remove("d-none");
        headerdialog.removeAttribute("style", "background: #5b97d8;color: white; ");
        this.content.setAttribute("style", "top: 45% !important;left: 74% !important;");
    }
}

MessageChatBoxDialogchatbox.template = "ringcentral.chatbox";
MessageChatBoxDialogchatbox.components = {Dialog};
MessageChatBoxDialogchatbox.props = {
    close: Function,
};
