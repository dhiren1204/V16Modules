/** @odoo-module **/
import {registry} from "@web/core/registry";
import {ListController} from "@web/views/list/list_controller";
import {listView} from "@web/views/list/list_view";
import {useService} from "@web/core/utils/hooks";
const {onWillStart} = owl;

export class RingcentralListController extends ListController {
    setup() {
        super.setup();
        this.action = useService("action");
        this.orm = useService("orm");
        this.user = useService("user");

        onWillStart(async () => {
            this.isRingCentralUser = await this.user.hasGroup(
                "ringcentral.ringcentral_user"
            );
        });
    }
    async onClickLogin() {
        const action = await this.orm.call("crm.phonecall", "get_service_uri", [], {});
        const loginUrl = action.split("/login/");
        this.action.doAction({
            type: "ir.actions.act_url",
            url: loginUrl[0],
        });
    }
    onClickSyncPhonecall() {
        this.action.doAction({
            type: "ir.actions.act_window",
            target: "new",
            res_model: "ringcentral.sync",
            views: [[false, "form"]],
        });
    }
    async onClickFetchAgents() {
        await this.orm.call("crm.phonecall", "fetch_agents", [], {});
    }
}

export const RingcentralListView = {
    ...listView,
    Controller: RingcentralListController,
    buttonTemplate: "ringcentral.ListView.Buttons",
};

registry.category("views").add("ringcentral_phonecall_tree", RingcentralListView);
