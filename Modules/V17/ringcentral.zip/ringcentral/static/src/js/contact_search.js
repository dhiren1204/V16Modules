/** @odoo-module **/

import {Component, useRef, useState} from "@odoo/owl";
export class ContactSearch extends Component {
    setup() {
        super.setup();
    }
}

ContactSearch.template = "ringcentral.contacts.search";
