/** @odoo-module **/

import {Component} from "@odoo/owl";

export class MissedCallLogsViews extends Component {
    setup() {
        super.setup();
    }

    onClickDial(ev, call) {
        var call_from = call.from;
        this.props.widget.dial_call_contact_detail(ev, call_from);
    }
}

MissedCallLogsViews.template = "ringcentral.miss_calllog";
