/** @odoo-module **/

import {Component, reactive} from "@odoo/owl";
import {_t} from "@web/core/l10n/translation";
import {registry} from "@web/core/registry";
import {session} from "@web/session";

export class ringcentralPanel extends Component {
    constructor(env, services) {
        super(...arguments);
        this.env = env;
        this.limit = 15;
        this.message_flag = false;
        this.a = 0;
        this.contacts = [];
        this.available_contacts = [];
        this.sdk = null;
        this.platform = null;
        this.webPhone = null;
        this.logLevel = 0;
        this.username = null;
        this.extension = null;
        this.appKey = null;
        this.rcsdk = null;
        this.sipInfo = null;
        this.loggedin = false;
        this.platform = null;
        this.phonecall_about_options = [];
        this.ringcentral_server = null;
        this.ringcentral_app_key = null;
        this.ringcentral_app_secret = null;
        this.ringcentral_redirect_uri = null;
        this.ringcentral_app_host = null;
        this.ringcentral_app_port = null;
        this.partner_search_string = "";
        this.contacts_partner = {};
        this.message_number = null;
        this.access_token = localStorage.getItem("access_token") || null;
        this.refresh_token = localStorage.getItem("refresh_token") || null;
        var nowDate = new Date();
        nowDate.setDate(nowDate.getDate() - 7);
        this.dateBefore2days =
            nowDate.getFullYear() +
            "-" +
            (nowDate.getMonth() + 1) +
            "-" +
            nowDate.getDate() +
            "T00:00:00.000Z";
        this.$el = $(".ringcentral_sidebar");
        this.$el.find(".nav-tabs a").click(function (ev) {
            ev.preventDefault();
            $(ev.currentTarget).tab("show");
        });
        const self = reactive(this);
        self.setup(env, services);
        return self;
    }

    setup(env, services) {
        if (services) {
            this.rpc = services.rpc;
            var data = this.rpc("/ringcentral_credentials", {
                company_id: session.user_companies.current_company,
                uid: session.uid,
            }).then(function (data) {
                if (
                    data.ringcentral_server &&
                    data.ringcentral_app_key &&
                    data.ringcentral_app_secret &&
                    data.ringcentral_redirect_uri &&
                    data.ringcentral_app_host &&
                    data.ringcentral_app_port
                ) {
                    self.ringcentral_server = data.ringcentral_server;
                    self.ringcentral_app_key = data.ringcentral_app_key;
                    self.ringcentral_app_secret = data.ringcentral_app_secret;
                    self.ringcentral_redirect_uri = data.ringcentral_redirect_uri;
                    self.ringcentral_app_host = data.ringcentral_app_host;
                    self.ringcentral_app_port = data.ringcentral_app_port;
                    self.ringcentral_service_uri = data.ringcentral_service_uri;
                    self.ringcentral_base_url = data.ringcentral_base_url;
                    self.contacts_action = data.contacts_action;

                    self.rcsdk = new RingCentral.SDK({
                        appKey: data.ringcentral_app_key,
                        appSecret: data.ringcentral_app_secret,
                        server: data.ringcentral_server,
                    });
                    self.platform = self.rcsdk.platform();
                }
            });
        }
    }
}

export const RingCentralService = {
    dependencies: ["rpc"],
    async start(env, services) {
        return new ringcentralPanel(env, services);
    },
};

ringcentralPanel.component = {ringcentralPanel};

registry.category("services").add("ringcentralPanel", RingCentralService);
