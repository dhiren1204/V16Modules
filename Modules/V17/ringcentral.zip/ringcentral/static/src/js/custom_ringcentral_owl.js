/** @odoo-module **/
import {session} from "@web/session";
// import { ringcentralPanel } from "./custom_ringcentral_panel_owl";
import {RingcentralPanelView} from "./panel_view_ringcentral";
import {View} from "@web/views/view";
import {useService} from "@web/core/utils/hooks";
import {patch} from "@web/core/utils/patch";

patch(View.prototype, {
    async setup() {
        super.setup();
        this.action = useService("action");
        this.orm = useService("orm");
        this.user = useService("user");
        this.isRingCentralUser = await this.user.hasGroup(
            "ringcentral.ringcentral_user"
        );
    },
    async loadView(props) {
        const columns = super.loadView(...arguments);
        var self = this;
        this.isRingCentralUser = await this.user.hasGroup(
            "ringcentral.ringcentral_user"
        );
        if (this.isRingCentralUser) {
            document
                .querySelector("#ring_central_panel_container")
                .classList.remove("d-none");
            await this.set_ringcentral_sidebar();
            if (this.ringcentralPanel) {
                $("#ringcentral_menu").slidemenu();
                $("#ring_central_panel_container").on("click", function () {
                    $("#ringcentral_menu").slideToggle("slow", "linear");
                });
            }
        }
        return columns;
    },
    set_ringcentral_sidebar() {
        var self = this;
        $(".nav-tabs a").on("click", function (ev) {
            ev.preventDefault();
            $(ev.currentTarget).tab("show");
        });
        this.ringcentralPanel = new RingcentralPanelView(self);
        session.ringcentralPanel = this.ringcentralPanel;
    },
});
