/** @odoo-module **/

import {Component} from "@odoo/owl";

export class ActiveCall extends Component {
    static template = "ringcentral.active.call";
    setup() {
        super.setup();
    }
    render_active_calls() {
        document.querySelector(".active-call").classList.add("d-none");
        document.querySelector(".active-call-header").classList.add("d-none");
        document.querySelector(".fetching-header-active").classList.remove("d-none");
        this.props.widget.render_active_calls();
        setTimeout(this.fetchingCalls, 2000);
    }

    fetchingCalls() {
        document.querySelector(".active-call").classList.remove("d-none");
        document.querySelector(".active-call-header").classList.remove("d-none");
        document.querySelector(".fetching-header-active").classList.add("d-none");
    }
}
