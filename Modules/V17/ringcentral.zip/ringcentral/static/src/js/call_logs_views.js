/** @odoo-module **/

import {Component} from "@odoo/owl";

export class CallLogsViews extends Component {
    setup() {}

    onClickCallDial(ev, call) {
        var call_from = call.from;
        this.props.widget.dial_call_contact_detail(ev, call_from);
    }
}

CallLogsViews.template = "ringcentral.all_calllog";
