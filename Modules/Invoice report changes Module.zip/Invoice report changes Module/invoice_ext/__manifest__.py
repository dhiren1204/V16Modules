{
    'name': 'Invoice Report',
    'version': '16.0,1',
    'summary': '',
    'description': '',
    'depends': ['web', 'account'],
    'data': [
        'views/report_templates.xml'
    ],
    'installable': True,
    'auto_install': False,
}
