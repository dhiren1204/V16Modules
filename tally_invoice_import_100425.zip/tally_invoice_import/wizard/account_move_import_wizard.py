# -*- coding: utf-8 -*-

from odoo import models, fields, api, _
from odoo.exceptions import UserError
import base64
import xlrd
import logging
from datetime import datetime
from dateutil.parser import parse

_logger = logging.getLogger(__name__)


class AccountMoveImportWizard(models.TransientModel):
    _name = 'account.move.import.wizard'
    _description = 'Import Invoices from Excel'

    import_file = fields.Binary(string='Import Excel File', required=True)
    file_name = fields.Char(string='File Name')
    journal_id = fields.Many2one('account.journal', string='Journal', required=True,)

    def _prepare_invoice_header(self, invoice_data):
        """Prepare invoice header values from parsed data"""
        partner = self.env['res.partner'].search([('name', '=', invoice_data.get('partner'))], limit=1)
        if not partner:
            raise UserError(_("Partner '%s' not found in the system.") % invoice_data.get('partner'))

        date_value = invoice_data.get('date')
        if isinstance(date_value, str):
            try:
                # Try to parse string date into datetime
                invoice_date = parse(date_value).date()
            except:
                raise UserError(_("Invalid date format: %s") % date_value)
        else:
            # Handle Excel date format
            invoice_date = datetime(*xlrd.xldate_as_tuple(date_value, 0)).date()

        move_type = 'out_invoice'
        if self.journal_id.type == 'purchase':
            move_type = 'in_invoice'

        return {
            'partner_id': partner.id,
            'invoice_date': invoice_date,
            'ref': invoice_data.get('voucher_no'),
            'move_type': move_type,
            'journal_id': self.journal_id.id,
            'invoice_payment_term_id': partner.property_supplier_payment_term_id.id,
        }

    def _prepare_invoice_line(self, line_data, invoice_id):
        """Prepare invoice line values from parsed data"""
        product_name = line_data.get('product_name')
        product = self.env['product.product'].search([('name', '=', product_name)], limit=1)
        if not product:
            # Create a fallback search with partial name matching
            product = self.env['product.product'].search([('name', 'ilike', product_name)], limit=1)
        # internal reference code search
        if not product:
            product = self.env['product.product'].search([('default_code', '=', product_name.split(' ')[0])], limit=1)
        # todo: product advanced search

        if not product:
            raise UserError(_("Product '%s' not found in the system.") % product_name)

        quantity = line_data.get('quantity', 0)
        price_unit = line_data.get('rate', 0)

        return {
            'product_id': product.id,
            'name': product_name,
            'quantity': quantity,
            'price_unit': price_unit,
            'move_id': invoice_id,
            'account_id': product.property_account_expense_id.id or product.categ_id.property_account_expense_categ_id.id,
        }

    def import_invoice_data(self):
        """Process the uploaded Excel file and create invoice records"""
        if not self.import_file:
            raise UserError(_("Please select a file to import."))

        # Decode and read Excel file
        try:
            file_data = base64.b64decode(self.import_file)
            book = xlrd.open_workbook(file_contents=file_data)
            sheet = book.sheet_by_index(0)
        except Exception as e:
            raise UserError(_("Error reading Excel file: %s") % str(e))

        # Define columns mapping (adjust according to your Excel file structure)
        col_mapping = {
            'date': 0,  # Column A
            'partner': 1,  # Column B - Buyer (In this case, using Africa Distributors, Ltd)
            'voucher_no': 3,  # Column D - Voucher No.
            'product_name': 1,  # Column B- Product Description
            'quantity': 9,  # Column J - Quantity
            'rate': 11,  # Column L - Rate
            'value': 12,  # Column M - Value
        }

        # Variables to track current invoice
        current_invoice = None
        current_invoice_data = None
        invoice_count = 0
        line_count = 0
        invoices_created = []

        # Loop through all rows (skip header rows)
        for row_idx in range(1, sheet.nrows):  # Assuming data starts after header rows
            row = sheet.row(row_idx)

            # Check if this row is a new invoice header (has date)
            date_cell = row[col_mapping['date']]
            is_header_row = date_cell.ctype != xlrd.XL_CELL_EMPTY and date_cell.value

            try:
                if is_header_row:
                    # Process previous invoice if exists
                    if current_invoice:
                        invoices_created.append(current_invoice.id)
                        self.env.cr.commit()
                        _logger.info('Successfully Generated this invoice:{}'.format(current_invoice))

                    # Extract invoice header data
                    invoice_data = {
                        'date': date_cell.value,
                        'partner': row[col_mapping['partner']].value if row[col_mapping[
                            'partner']].ctype != xlrd.XL_CELL_EMPTY else False,
                        'voucher_no': row[col_mapping['voucher_no']].value if row[col_mapping[
                            'voucher_no']].ctype != xlrd.XL_CELL_EMPTY else False,
                    }

                    # # Create new invoice
                    # if not invoice_data['partner']:
                    #     # For the specific case in the image - use the company name as partner
                    #     invoice_data['partner'] = 'Africa Distributors, Ltd'

                    invoice_vals = self._prepare_invoice_header(invoice_data)
                    # for the 2nd time if same sheet run
                    current_invoice = self.env['account.move'].sudo().search([
                        ('move_type','=',invoice_vals.get('move_type')),
                        ('ref','=',invoice_vals.get('ref')),
                        ('journal_id','=',invoice_vals.get('journal_id')),
                        ('state','in',['draft']),
                        # ('amount_untaxed','!=',row[col_mapping['value']].value),
                    ])
                    if not current_invoice:
                        current_invoice = self.env['account.move'].create(invoice_vals)
                        current_invoice_data = invoice_data
                        invoice_count += 1
                        _logger.info(f"Created invoice header: {current_invoice.name}, invoice_count: {invoice_count}")
                    # for the 2nd time if same sheet run
                    # if current_invoice and current_invoice.amount_untaxed != row[col_mapping['value']].value:
                    #     current_invoice = current_invoice
                    if current_invoice and current_invoice.amount_untaxed == row[col_mapping['value']].value:
                        current_invoice = False
                    continue

                # Process invoice line
                if current_invoice:
                    product_name_cell = row[col_mapping['product_name']]
                    if product_name_cell.ctype != xlrd.XL_CELL_EMPTY and product_name_cell.value:
                        line_data = {
                            'product_name': product_name_cell.value,
                            'quantity': float(row[col_mapping['quantity']].value) if row[col_mapping[
                                'quantity']].ctype != xlrd.XL_CELL_EMPTY else 0,
                            'rate': float(row[col_mapping['rate']].value) if row[col_mapping[
                                'rate']].ctype != xlrd.XL_CELL_EMPTY else 0,
                            'value': float(row[col_mapping['value']].value) if row[col_mapping[
                                'value']].ctype != xlrd.XL_CELL_EMPTY else 0,
                        }

                        line_vals = self._prepare_invoice_line(line_data, current_invoice.id)
                        self.env['account.move.line'].with_context(check_move_validity=False).create(line_vals)
                        line_count += 1
            except Exception as e:
                _logger.info('Exception:{} at row:{}'.format(e, row))
                continue


        # # Process the last invoice if exists
        # if current_invoice:
        #     invoices_created.append(current_invoice.id)

        # Show success message
        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': _('Import Successful'),
                'message': _('%s invoices with %s lines created successfully.') % (invoice_count, line_count),
                'sticky': False,
            }
        }