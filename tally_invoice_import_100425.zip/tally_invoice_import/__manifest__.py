{
    'name': 'Invoice Import Wizard',
    'version': '1.0',
    'summary': 'Import invoices from Excel files with hierarchical data',
    'description': """
        This module allows you to import vendor bills from Excel files
        where multiple invoice lines belong to a single invoice header.
        The wizard recognizes new invoices by the presence of a date in the Date column.
    """,
    'category': 'Accounting',
    'author': 'Your Company',
    'website': 'https://www.yourcompany.com',
    'depends': ['account'],
    'data': [
        'security/ir.model.access.csv',

        'wizard/account_move_import_wizard_view.xml',
    ],
    'installable': True,
    'application': False,
    'auto_install': False,
}