# -*- coding: utf-8 -*-
##############################################################################
#                                                                            #
# Part of Caret IT Solutions Pvt. Ltd. (Website: www.caretit.com).           #
# See LICENSE file for full copyright and licensing details.                 #
#                                                                            #
##############################################################################

{
    'name': 'Portal Login as User/Customer',
    'version': '16.0.1.0',
    'license': 'OPL-1',
    'category': 'Extra Tools',
    'summary': '''
        Portal login, Login as Portal User, Login as impersonate another user, Login As Other Users,
        Admin Users, Administrator, Super User, Impersonate Portal User,.
    ''',
    'description': '''
        This module allows you to change user quickly and test or do your steps
        as the user and come back to your original user role. So it eliminates
        login procedure. You can allow this feature to specific user in your team.
    ''',
    'company': 'Caret IT Solutions Pvt. Ltd.',
    'author': 'Caret IT Solutions Pvt. Ltd.',
    'maintainer': 'Caret IT Solutions Pvt. Ltd.',
    'website': 'https://www.caretit.com',
    'depends': ['portal', 'impersonate_user', 'website'],
    'data': [
        'views/impersonate_templates.xml',
    ],
    'images': ['static/description/banner.jpg'],
    'price': 19.00,
    'currency': 'EUR',
}
